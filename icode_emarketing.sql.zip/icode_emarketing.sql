-- phpMyAdmin SQL Dump
-- version 2.11.9.5
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Sep 10, 2009 at 03:43 AM
-- Server version: 5.0.81
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `icode_emarketing`
--

-- --------------------------------------------------------

--
-- Table structure for table `jos_banner`
--

CREATE TABLE IF NOT EXISTS `jos_banner` (
  `bid` int(11) NOT NULL auto_increment,
  `cid` int(11) NOT NULL default '0',
  `type` varchar(90) NOT NULL default 'banner',
  `name` text NOT NULL,
  `alias` varchar(255) NOT NULL default '',
  `imptotal` int(11) NOT NULL default '0',
  `impmade` int(11) NOT NULL default '0',
  `clicks` int(11) NOT NULL default '0',
  `imageurl` varchar(100) NOT NULL default '',
  `clickurl` varchar(200) NOT NULL default '',
  `date` datetime default NULL,
  `showBanner` tinyint(1) NOT NULL default '0',
  `checked_out` tinyint(1) NOT NULL default '0',
  `checked_out_time` datetime NOT NULL default '0000-00-00 00:00:00',
  `editor` varchar(150) default NULL,
  `custombannercode` text,
  `catid` int(10) unsigned NOT NULL default '0',
  `description` text NOT NULL,
  `sticky` tinyint(1) unsigned NOT NULL default '0',
  `ordering` int(11) NOT NULL default '0',
  `publish_up` datetime NOT NULL default '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL default '0000-00-00 00:00:00',
  `tags` text NOT NULL,
  `params` text NOT NULL,
  PRIMARY KEY  (`bid`),
  KEY `viewbanner` (`showBanner`),
  KEY `idx_banner_catid` (`catid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `jos_banner`
--

INSERT INTO `jos_banner` (`bid`, `cid`, `type`, `name`, `alias`, `imptotal`, `impmade`, `clicks`, `imageurl`, `clickurl`, `date`, `showBanner`, `checked_out`, `checked_out_time`, `editor`, `custombannercode`, `catid`, `description`, `sticky`, `ordering`, `publish_up`, `publish_down`, `tags`, `params`) VALUES
(1, 1, 'banner', 'OSM 1', 'osm-1', 0, 194, 0, 'osmbanner1.png', 'http://www.opensourcematters.org', '2004-07-07 15:31:29', 1, 0, '0000-00-00 00:00:00', '', '', 13, '', 0, 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', ''),
(2, 1, 'banner', 'OSM 2', 'osm-2', 0, 49, 0, 'osmbanner2.png', 'http://www.opensourcematters.org', '2004-07-07 15:31:29', 1, 0, '0000-00-00 00:00:00', '', '', 13, '', 0, 2, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', ''),
(3, 1, '', 'Joomla!', 'joomla', 0, 11, 0, '', 'http://www.joomla.org', '2006-05-29 14:21:28', 1, 0, '0000-00-00 00:00:00', '', '<a href="{CLICKURL}" target="_blank">{NAME}</a>\r\n<br/>\r\nJoomla! The most popular and widely used Open Source CMS Project in the world.', 14, '', 0, 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', ''),
(4, 1, '', 'Joomla! Forge', 'joomla-forge', 0, 11, 0, '', 'http://forge.joomla.org', '2006-05-29 14:19:26', 1, 0, '0000-00-00 00:00:00', '', '<a href="{CLICKURL}" target="_blank">{NAME}</a>\r\n<br/>\r\nJoomla! Forge, development and distribution made easy.', 14, '', 0, 2, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', ''),
(5, 1, '', 'Joomla! Extensions', 'joomla-extensions', 0, 6, 0, '', 'http://extensions.joomla.org', '2006-05-29 14:23:21', 1, 0, '0000-00-00 00:00:00', '', '<a href="{CLICKURL}" target="_blank">{NAME}</a>\r\n<br/>\r\nJoomla! components, modules, plugins and languages by the bucket load.', 14, '', 0, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `jos_bannerclient`
--

CREATE TABLE IF NOT EXISTS `jos_bannerclient` (
  `cid` int(11) NOT NULL auto_increment,
  `name` text NOT NULL,
  `contact` text NOT NULL,
  `email` varchar(255) NOT NULL default '',
  `extrainfo` text NOT NULL,
  `checked_out` tinyint(1) NOT NULL default '0',
  `checked_out_time` time default NULL,
  `editor` varchar(150) default NULL,
  PRIMARY KEY  (`cid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `jos_bannerclient`
--

INSERT INTO `jos_bannerclient` (`cid`, `name`, `contact`, `email`, `extrainfo`, `checked_out`, `checked_out_time`, `editor`) VALUES
(1, 'Open Source Matters', 'Administrator', 'admin@opensourcematters.org', '', 0, '00:00:00', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `jos_bannertrack`
--

CREATE TABLE IF NOT EXISTS `jos_bannertrack` (
  `track_date` date NOT NULL,
  `track_type` int(10) unsigned NOT NULL,
  `banner_id` int(10) unsigned NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `jos_bannertrack`
--


-- --------------------------------------------------------

--
-- Table structure for table `jos_categories`
--

CREATE TABLE IF NOT EXISTS `jos_categories` (
  `id` int(11) NOT NULL auto_increment,
  `parent_id` int(11) NOT NULL default '0',
  `title` text NOT NULL,
  `name` text NOT NULL,
  `alias` varchar(255) NOT NULL default '',
  `image` varchar(255) NOT NULL default '',
  `section` varchar(150) NOT NULL default '',
  `image_position` varchar(90) NOT NULL default '',
  `description` text NOT NULL,
  `published` tinyint(1) NOT NULL default '0',
  `checked_out` int(11) unsigned NOT NULL default '0',
  `checked_out_time` datetime NOT NULL default '0000-00-00 00:00:00',
  `editor` varchar(150) default NULL,
  `ordering` int(11) NOT NULL default '0',
  `access` tinyint(3) unsigned NOT NULL default '0',
  `count` int(11) NOT NULL default '0',
  `params` text NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `cat_idx` (`section`,`published`,`access`),
  KEY `idx_section` (`section`),
  KEY `idx_access` (`access`),
  KEY `idx_checkout` (`checked_out`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=35 ;

--
-- Dumping data for table `jos_categories`
--

INSERT INTO `jos_categories` (`id`, `parent_id`, `title`, `name`, `alias`, `image`, `section`, `image_position`, `description`, `published`, `checked_out`, `checked_out_time`, `editor`, `ordering`, `access`, `count`, `params`) VALUES
(1, 0, 'Latest', '', 'latest-news', 'taking_notes.jpg', '1', 'left', 'The latest news from the Joomla! Team', 1, 0, '0000-00-00 00:00:00', '', 1, 0, 1, ''),
(2, 0, 'Joomla! Specific Links', '', 'joomla-specific-links', 'clock.jpg', 'com_weblinks', 'left', 'A selection of links that are all related to the Joomla! Project.', 1, 0, '0000-00-00 00:00:00', NULL, 1, 0, 0, ''),
(3, 0, 'Newsflash', '', 'newsflash', '', '1', 'left', '', 1, 0, '0000-00-00 00:00:00', '', 2, 0, 0, ''),
(4, 0, 'Joomla!', '', 'joomla', '', 'com_newsfeeds', 'left', '', 1, 0, '0000-00-00 00:00:00', NULL, 2, 0, 0, ''),
(5, 0, 'Business: general', '', 'business-general', '', 'com_newsfeeds', 'left', '', 1, 0, '0000-00-00 00:00:00', NULL, 1, 0, 0, ''),
(6, 0, 'Linux', '', 'linux', '', 'com_newsfeeds', 'left', '', 1, 0, '0000-00-00 00:00:00', NULL, 6, 0, 0, ''),
(7, 0, 'Internet', '', 'internet', '', 'com_newsfeeds', 'left', '', 1, 0, '0000-00-00 00:00:00', NULL, 7, 0, 0, ''),
(12, 0, 'Contacts', '', 'contacts', '', 'com_contact_details', 'left', 'Contact Details for this website', 1, 0, '0000-00-00 00:00:00', NULL, 0, 0, 0, ''),
(13, 0, 'Joomla', '', 'joomla', '', 'com_banner', 'left', '', 1, 0, '0000-00-00 00:00:00', NULL, 0, 0, 0, ''),
(14, 0, 'Text Ads', '', 'text-ads', '', 'com_banner', 'left', '', 1, 0, '0000-00-00 00:00:00', NULL, 0, 0, 0, ''),
(15, 0, 'Features', '', 'features', '', 'com_content', 'left', '', 0, 0, '0000-00-00 00:00:00', NULL, 6, 0, 0, ''),
(17, 0, 'Benefits', '', 'benefits', '', 'com_content', 'left', '', 0, 0, '0000-00-00 00:00:00', NULL, 4, 0, 0, ''),
(18, 0, 'Platforms', '', 'platforms', '', 'com_content', 'left', '', 0, 0, '0000-00-00 00:00:00', NULL, 3, 0, 0, ''),
(19, 0, 'Other Resources', '', 'other-resources', '', 'com_weblinks', 'left', '', 1, 0, '0000-00-00 00:00:00', NULL, 2, 0, 0, ''),
(29, 0, 'The CMS', '', 'the-cms', '', '4', 'left', 'Information about the software behind Joomla!<br />', 1, 0, '0000-00-00 00:00:00', NULL, 2, 0, 0, ''),
(28, 0, 'Current Users', '', 'current-users', '', '3', 'left', 'Questions that users migrating to Joomla! 1.5 are likely to raise<br />', 1, 0, '0000-00-00 00:00:00', NULL, 2, 0, 0, ''),
(25, 0, 'The Project', '', 'the-project', '', '4', 'left', 'General facts about Joomla!<br />', 1, 0, '0000-00-00 00:00:00', NULL, 1, 0, 0, ''),
(27, 0, 'New to Joomla', '', 'new-to-joomla', '', '3', 'left', 'Questions for new users of Joomla!<br />', 1, 0, '0000-00-00 00:00:00', NULL, 3, 0, 0, ''),
(30, 0, 'The Community', '', 'the-community', '', '4', 'left', 'About the millions of Joomla! users and websites<br />', 1, 0, '0000-00-00 00:00:00', NULL, 3, 0, 0, ''),
(31, 0, 'General', '', 'general', '', '3', 'left', 'General questions about the Joomla! CMS', 1, 0, '0000-00-00 00:00:00', NULL, 1, 0, 0, ''),
(32, 0, 'Languages', '', 'languages', '', '3', 'left', 'Questions related to localisation and languages', 1, 0, '0000-00-00 00:00:00', NULL, 4, 0, 0, ''),
(33, 0, ' YOOslider Vertical', '', '-yooslider-vertical', '', '5', 'left', '', 1, 0, '0000-00-00 00:00:00', NULL, 4, 0, 0, ''),
(34, 0, 'YOOslider Horizontal', '', 'yooslider-horizontal', '', '5', 'left', '', 1, 0, '0000-00-00 00:00:00', NULL, 1, 0, 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `jos_components`
--

CREATE TABLE IF NOT EXISTS `jos_components` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(150) NOT NULL default '',
  `link` varchar(255) NOT NULL default '',
  `menuid` int(11) unsigned NOT NULL default '0',
  `parent` int(11) unsigned NOT NULL default '0',
  `admin_menu_link` varchar(255) NOT NULL default '',
  `admin_menu_alt` text NOT NULL,
  `option` varchar(50) NOT NULL default '',
  `ordering` int(11) NOT NULL default '0',
  `admin_menu_img` varchar(255) NOT NULL default '',
  `iscore` tinyint(4) NOT NULL default '0',
  `params` text NOT NULL,
  `enabled` tinyint(4) NOT NULL default '1',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=34 ;

--
-- Dumping data for table `jos_components`
--

INSERT INTO `jos_components` (`id`, `name`, `link`, `menuid`, `parent`, `admin_menu_link`, `admin_menu_alt`, `option`, `ordering`, `admin_menu_img`, `iscore`, `params`, `enabled`) VALUES
(1, 'Banners', '', 0, 0, '', 'Banner Management', 'com_banners', 0, 'js/ThemeOffice/component.png', 0, 'track_impressions=0\ntrack_clicks=0\ntag_prefix=\n\n', 1),
(2, 'Banners', '', 0, 1, 'option=com_banners', 'Active Banners', 'com_banners', 1, 'js/ThemeOffice/edit.png', 0, '', 1),
(3, 'Clients', '', 0, 1, 'option=com_banners&c=client', 'Manage Clients', 'com_banners', 2, 'js/ThemeOffice/categories.png', 0, '', 1),
(4, 'Web Links', 'option=com_weblinks', 0, 0, '', 'Manage Weblinks', 'com_weblinks', 0, 'js/ThemeOffice/component.png', 0, 'show_comp_description=1\ncomp_description=\nshow_link_hits=1\nshow_link_description=1\nshow_other_cats=1\nshow_headings=1\nshow_page_title=1\nlink_target=0\nlink_icons=\n\n', 1),
(5, 'Links', '', 0, 4, 'option=com_weblinks', 'View existing weblinks', 'com_weblinks', 1, 'js/ThemeOffice/edit.png', 0, '', 1),
(6, 'Categories', '', 0, 4, 'option=com_categories&section=com_weblinks', 'Manage weblink categories', '', 2, 'js/ThemeOffice/categories.png', 0, '', 1),
(7, 'Contacts', 'option=com_contact', 0, 0, '', 'Edit contact details', 'com_contact', 0, 'js/ThemeOffice/component.png', 1, 'contact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_fax=\nicon_misc=\nshow_headings=1\nshow_position=1\nshow_email=0\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nbannedEmail=\nbannedSubject=\nbannedText=\nsession=1\ncustomReply=0\n\n', 1),
(8, 'Contacts', '', 0, 7, 'option=com_contact', 'Edit contact details', 'com_contact', 0, 'js/ThemeOffice/edit.png', 1, '', 1),
(9, 'Categories', '', 0, 7, 'option=com_categories&section=com_contact_details', 'Manage contact categories', '', 2, 'js/ThemeOffice/categories.png', 1, '', 1),
(10, 'Polls', 'option=com_poll', 0, 0, 'option=com_poll', 'Manage Polls', 'com_poll', 0, 'js/ThemeOffice/component.png', 0, '', 1),
(11, 'News Feeds', 'option=com_newsfeeds', 0, 0, '', 'News Feeds Management', 'com_newsfeeds', 0, 'js/ThemeOffice/component.png', 0, '', 1),
(12, 'Feeds', '', 0, 11, 'option=com_newsfeeds', 'Manage News Feeds', 'com_newsfeeds', 1, 'js/ThemeOffice/edit.png', 0, '', 1),
(13, 'Categories', '', 0, 11, 'option=com_categories&section=com_newsfeeds', 'Manage Categories', '', 2, 'js/ThemeOffice/categories.png', 0, '', 1),
(14, 'User', 'option=com_user', 0, 0, '', '', 'com_user', 0, '', 1, '', 1),
(15, 'Search', 'option=com_search', 0, 0, 'option=com_search', 'Search Statistics', 'com_search', 0, 'js/ThemeOffice/component.png', 1, 'enabled=0\n\n', 1),
(16, 'Categories', '', 0, 1, 'option=com_categories&section=com_banner', 'Categories', '', 3, '', 1, '', 1),
(17, 'Wrapper', 'option=com_wrapper', 0, 0, '', 'Wrapper', 'com_wrapper', 0, '', 1, '', 1),
(18, 'Mail To', '', 0, 0, '', '', 'com_mailto', 0, '', 1, '', 1),
(19, 'Media Manager', '', 0, 0, 'option=com_media', 'Media Manager', 'com_media', 0, '', 1, 'upload_extensions=bmp,csv,doc,epg,gif,ico,jpg,odg,odp,ods,odt,pdf,png,ppt,swf,txt,xcf,xls,BMP,CSV,DOC,EPG,GIF,ICO,JPG,ODG,ODP,ODS,ODT,PDF,PNG,PPT,SWF,TXT,XCF,XLS\nupload_maxsize=10000000\n\n', 1),
(20, 'Articles', 'option=com_content', 0, 0, '', '', 'com_content', 0, '', 1, 'show_noauth=0\nlink_titles=0\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_author=1\nshow_create_date=1\nshow_modify_date=1\nshow_item_navigation=0\nshow_readmore=1\nshow_vote=0\nshow_icons=1\nshow_pdf_icon=1\nshow_print_icon=1\nshow_email_icon=1\nshow_hits=1\n\n', 1),
(21, 'Configuration Manager', '', 0, 0, '', 'Configuration', 'com_config', 0, '', 1, '', 1),
(22, 'Installation Manager', '', 0, 0, '', 'Installer', 'com_installer', 0, '', 1, '', 1),
(23, 'Language Manager', '', 0, 0, '', 'Languages', 'com_languages', 0, '', 1, '', 1),
(24, 'Mass mail', '', 0, 0, '', 'Mass Mail', 'com_massmail', 0, '', 1, 'mailSubjectPrefix=\nmailBodySuffix=\n\n', 1),
(25, 'Menu Editor', '', 0, 0, '', 'Menu Editor', 'com_menus', 0, '', 1, '', 1),
(26, 'Menu Manager', '', 0, 0, '', 'Menu Manager', 'com_menumanager', 0, '', 1, '', 1),
(27, 'Messaging', '', 0, 0, '', 'Messages', 'com_messages', 0, '', 1, '', 1),
(28, 'Modules Manager', '', 0, 0, '', 'Modules', 'com_modules', 0, '', 1, '', 1),
(29, 'Plugin Manager', '', 0, 0, '', 'Plugins', 'com_plugins', 0, '', 1, '', 1),
(30, 'Template Manager', '', 0, 0, '', 'Templates', 'com_templates', 0, '', 1, '', 1),
(31, 'User Manager', '', 0, 0, '', 'Users', 'com_users', 0, '', 1, 'allowUserRegistration=1\nnew_usertype=Registered\nuseractivation=1\nfrontend_userparams=1\n\n', 1),
(32, 'Cache Manager', '', 0, 0, '', 'Cache', 'com_cache', 0, '', 1, '', 1),
(33, 'Control Panel', '', 0, 0, '', 'Control Panel', 'com_cpanel', 0, '', 1, '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `jos_contact_details`
--

CREATE TABLE IF NOT EXISTS `jos_contact_details` (
  `id` int(11) NOT NULL auto_increment,
  `name` text NOT NULL,
  `alias` varchar(255) NOT NULL default '',
  `con_position` text,
  `address` text,
  `suburb` text,
  `state` text,
  `country` text,
  `postcode` varchar(255) default NULL,
  `telephone` varchar(255) default NULL,
  `fax` varchar(255) default NULL,
  `misc` mediumtext,
  `image` varchar(255) default NULL,
  `imagepos` varchar(60) default NULL,
  `email_to` varchar(255) default NULL,
  `default_con` tinyint(1) unsigned NOT NULL default '0',
  `published` tinyint(1) unsigned NOT NULL default '0',
  `checked_out` int(11) unsigned NOT NULL default '0',
  `checked_out_time` datetime NOT NULL default '0000-00-00 00:00:00',
  `ordering` int(11) NOT NULL default '0',
  `params` text NOT NULL,
  `user_id` int(11) NOT NULL default '0',
  `catid` int(11) NOT NULL default '0',
  `access` tinyint(3) unsigned NOT NULL default '0',
  `mobile` varchar(255) NOT NULL default '',
  `webpage` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `jos_contact_details`
--

INSERT INTO `jos_contact_details` (`id`, `name`, `alias`, `con_position`, `address`, `suburb`, `state`, `country`, `postcode`, `telephone`, `fax`, `misc`, `image`, `imagepos`, `email_to`, `default_con`, `published`, `checked_out`, `checked_out_time`, `ordering`, `params`, `user_id`, `catid`, `access`, `mobile`, `webpage`) VALUES
(1, 'Name', 'name', 'Position', 'Street', 'Suburb', 'State', 'Country', 'Zip Code', 'Telephone', 'Fax', 'Miscellanous info', 'powered_by.png', 'top', 'email@email.com', 1, 1, 0, '0000-00-00 00:00:00', 1, 'menu_image=-1\r\npageclass_sfx=\r\nprint=\r\nname=1\r\nposition=1\r\nemail=0\r\nstreet_address=1\r\nsuburb=1\r\nstate=1\r\ncountry=1\r\npostcode=1\r\ntelephone=1\r\nfax=1\r\nmisc=1\r\nimage=1\r\nvcard=0\r\nemail_description=1\r\nemail_description_text=\r\nemail_form=1\r\nemail_copy=1\r\ndrop_down=0\r\ncontact_icons=0\r\nicon_address=\r\nicon_email=\r\nicon_telephone=\r\nicon_fax=\r\nicon_misc=', 0, 12, 0, '', '');

-- --------------------------------------------------------

--
-- Table structure for table `jos_content`
--

CREATE TABLE IF NOT EXISTS `jos_content` (
  `id` int(11) unsigned NOT NULL auto_increment,
  `title` text NOT NULL,
  `alias` varchar(255) NOT NULL default '',
  `title_alias` text NOT NULL,
  `introtext` mediumtext NOT NULL,
  `fulltext` mediumtext NOT NULL,
  `state` tinyint(3) NOT NULL default '0',
  `sectionid` int(11) unsigned NOT NULL default '0',
  `mask` int(11) unsigned NOT NULL default '0',
  `catid` int(11) unsigned NOT NULL default '0',
  `created` datetime NOT NULL default '0000-00-00 00:00:00',
  `created_by` int(11) unsigned NOT NULL default '0',
  `created_by_alias` text NOT NULL,
  `modified` datetime NOT NULL default '0000-00-00 00:00:00',
  `modified_by` int(11) unsigned NOT NULL default '0',
  `checked_out` int(11) unsigned NOT NULL default '0',
  `checked_out_time` datetime NOT NULL default '0000-00-00 00:00:00',
  `publish_up` datetime NOT NULL default '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL default '0000-00-00 00:00:00',
  `images` text NOT NULL,
  `urls` text NOT NULL,
  `attribs` text NOT NULL,
  `version` int(11) unsigned NOT NULL default '1',
  `parentid` int(11) unsigned NOT NULL default '0',
  `ordering` int(11) NOT NULL default '0',
  `metakey` text NOT NULL,
  `metadesc` text NOT NULL,
  `access` int(11) unsigned NOT NULL default '0',
  `hits` int(11) unsigned NOT NULL default '0',
  `metadata` text NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `idx_section` (`sectionid`),
  KEY `idx_access` (`access`),
  KEY `idx_checkout` (`checked_out`),
  KEY `idx_state` (`state`),
  KEY `idx_catid` (`catid`),
  KEY `idx_mask` (`mask`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=77 ;

--
-- Dumping data for table `jos_content`
--

INSERT INTO `jos_content` (`id`, `title`, `alias`, `title_alias`, `introtext`, `fulltext`, `state`, `sectionid`, `mask`, `catid`, `created`, `created_by`, `created_by_alias`, `modified`, `modified_by`, `checked_out`, `checked_out_time`, `publish_up`, `publish_down`, `images`, `urls`, `attribs`, `version`, `parentid`, `ordering`, `metakey`, `metadesc`, `access`, `hits`, `metadata`) VALUES
(1, 'Welcome to Joomla!', 'welcome-to-joomla', '', '<div align="center"><font color="#ff0000"><strong>** Joomla! 1.5.0 Beta should NOT to be used for `live` or `production` sites. **</strong></font></div><p><strong>Joomla! is a free open source framework and content publishing system designed for quickly creating highly interactive multi-language Web sites, online communities, media portals, blogs and eCommerce applications. <br /><br /></strong><img class="caption" src="images/stories/powered_by.png" alt="Joomla! Logo" title="Example Caption" align="left" />Joomla! provides an easy-to-use graphical user interface that simplifies the management and publishing of large volumes of content including HTML, documents, and rich media.  Joomla! is used by organisations of all sizes for Public Websites, Intranets and Extranets and is supported by a community of thousands of users. </p>', 'With fully documented library of developer resources, Joomla! allows the customisation of every aspect of a Website including presentation, layout, administration and rapid integration with third-party applications.<p>Joomla! has a rich heritage and has been crowned CMS king many times over.  Now with more power under the hood, Joomla! is shifting gear and provides developer power while making the user experience all the more friendly.  For those who always wanted increased extensibility, Joomla! 1.5 can make this happen. </p>', -2, 1, 0, 1, '2006-10-12 12:00:00', 62, '', '2007-05-03 09:41:07', 62, 0, '0000-00-00 00:00:00', '2006-01-02 16:00:00', '0000-00-00 00:00:00', '', '', 'pageclass_sfx=\nshow_title=1\nlink_titles=\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=', 20, 0, 0, '', '', 0, 34, 'robots=\nauthor='),
(2, 'Newsflash 1', 'newsflash-1', '', '<p>Joomla! makes it easy to launch a website of any kind. Whether you want a brochure site or you''re building a large online community, Joomla! allows you to deploy a site in minutes and add functionality as you need it. The hundreds of extensions will expand your site and allow you to deliver new services that expand your reach into the Internet.</p>', '', -2, 1, 0, 3, '2004-08-10 08:30:34', 62, '', '2007-05-03 09:41:42', 62, 0, '0000-00-00 00:00:00', '2004-08-09 12:00:00', '0000-00-00 00:00:00', '', '', 'pageclass_sfx=\nshow_title=1\nlink_titles=\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=', 6, 0, 0, '', '', 0, 1, 'robots=\nauthor='),
(3, 'Emarketing News ', 'newsflash-2', '', '<h3 style="margin: auto 0cm"><span style="font-family: ''Arial'',''sans-serif''"><font size="4"><font color="#000000"><img src="images/stories/ch.png" border="0" align="right" />Why You''ll Want To Work With Us</font></font></span></h3><ul><li class="MsoNormal" style="margin: 0cm 0cm 0pt; tab-stops: list 36.0pt"><span style="font-size: 10pt; font-family: ''Arial'',''sans-serif''"><font color="#000000">We deliver the world''s most powerful advertising solutions for both advertisers and publishers. </font></span></li><li class="MsoNormal" style="margin: 0cm 0cm 0pt; tab-stops: list 36.0pt"><span style="font-size: 10pt; font-family: ''Arial'',''sans-serif''"><font color="#000000">We use a combination of mind-bending technology and good old-fashioned customer service. </font></span></li><li class="MsoNormal" style="margin: 0cm 0cm 0pt; tab-stops: list 36.0pt"><span style="font-size: 10pt; font-family: ''Arial'',''sans-serif''"><font color="#000000">We have a remarkable set of products capable of tapping into almost every online revenue stream imaginable.</font></span></li></ul>', '', 1, 1, 0, 3, '2004-08-10 00:30:34', 62, '', '2008-11-20 07:04:27', 62, 0, '0000-00-00 00:00:00', '2004-08-09 08:00:00', '0000-00-00 00:00:00', '', '', 'show_title=1\nlink_titles=\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 8, 0, 1, '', '', 0, 0, 'robots=\nauthor='),
(4, 'EMARKETING 2', 'newsflash-3', '', '<ul><li class="MsoNormal" style="margin: 0cm 0cm 0pt; tab-stops: list 36.0pt"><span style="font-size: 10pt; font-family: ''Arial'',''sans-serif''"><font color="#000000">We deliver the world''s most powerful advertising solutions for both advertisers and publishers. </font></span></li><li class="MsoNormal" style="margin: 0cm 0cm 0pt; tab-stops: list 36.0pt"><span style="font-size: 10pt; font-family: ''Arial'',''sans-serif''"><font color="#000000">We use a combination of mind-bending technology and good old-fashioned customer service. </font></span></li><li class="MsoNormal" style="margin: 0cm 0cm 0pt; tab-stops: list 36.0pt"><span style="font-size: 10pt; font-family: ''Arial'',''sans-serif''"><font color="#000000">We have a remarkable set of products capable of tapping into almost every online revenue stream imaginable.</font></span></li></ul>', '', 1, 1, 0, 3, '2004-08-10 08:30:34', 62, '', '2008-11-20 07:05:59', 62, 0, '0000-00-00 00:00:00', '2004-08-09 12:00:00', '0000-00-00 00:00:00', '', '', 'show_title=1\nlink_titles=\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 8, 0, 2, '', '', 0, 1, 'robots=\nauthor='),
(5, 'Joomla! License Guidelines', 'joomla-license-guidelines', 'joomla-license-guidelines', '<p>This website is powered by <a href="http://www.joomla.org/">Joomla!</a>  The software and default templates on which it runs are Copyright 2005-2006 <a href="http://www.opensourcematters.org/">Open Source Matters</a>.  All other content and data, including data entered into this website and templates added after installation, are copyrighted by their respective copyright owners.</p><p>If you want to distribute, copy or modify Joomla!, you are welcome to do so under the terms of the <a href="http://www.gnu.org/copyleft/gpl.html#SEC1">GNU General Public License</a>.  If you are unfamiliar with this license, you might want to read <a href="http://www.gnu.org/copyleft/gpl.html#SEC4">''How To Apply These Terms To Your Program''</a> and the <a href="http://www.gnu.org/licenses/gpl-faq.html">''GNU General Public License FAQ''</a>.</p>', '', -2, 4, 0, 25, '2004-08-20 12:11:07', 62, '', '2007-05-03 09:36:19', 62, 0, '0000-00-00 00:00:00', '2004-08-19 08:00:00', '0000-00-00 00:00:00', '', '', 'pageclass_sfx=\nshow_title=1\nlink_titles=\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=', 5, 0, 0, '', '', 0, 48, 'robots=\nauthor='),
(6, 'Example News Item 1', 'example-news-item-1', '', '<img src="images/stories/food/coffee.jpg" alt="" align="left" />Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum.', '<p><img src="images/stories/food/bread.jpg" alt="" align="right" />Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi. Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat.</p>  <p>Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi.</p>  <p>Nam liber tempor cum soluta nobis eleifend option congue nihil imperdiet doming id quod mazim placerat facer possim assum. Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat.</p>  <p>Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, At accusam aliquyam diam diam dolore dolores duo eirmod eos erat, et nonumy sed tempor et et invidunt justo labore Stet clita ea et gubergren, kasd magna no rebum. sanctus sea sed takimata ut vero voluptua. est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat.</p>  <p>Consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.</p>', -2, 1, 0, 1, '2004-07-07 11:54:06', 62, '', '2007-05-03 09:41:08', 62, 0, '0000-00-00 00:00:00', '2004-07-07 00:00:00', '0000-00-00 00:00:00', '', '', 'pageclass_sfx=\nshow_title=1\nlink_titles=\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=', 3, 0, 0, '', '', 0, 10, 'robots=\nauthor='),
(7, 'Example News Item 2', 'example-news-item-2', '', '<p><img src="images/stories/food/bun.jpg" alt="" align="right" />Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua.</p>', '  <p>At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.</p>', -2, 1, 0, 1, '2004-07-07 12:00:00', 62, '', '2007-05-03 09:41:13', 62, 0, '0000-00-00 00:00:00', '2004-07-07 12:00:00', '0000-00-00 00:00:00', '', '', 'pageclass_sfx=\nshow_title=1\nlink_titles=\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=', 5, 0, 0, '', '', 0, 3, 'robots=\nauthor='),
(8, 'Example News Item 3', 'example-news-item-3', '', '<p><img src="images/stories/fruit/pears.jpg" alt="" align="right" />Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.</p>', '', -2, 1, 0, 1, '2004-04-12 11:54:06', 62, '', '2007-05-03 09:41:15', 62, 0, '0000-00-00 00:00:00', '2004-07-07 00:00:00', '0000-00-00 00:00:00', '', '', 'pageclass_sfx=\nshow_title=1\nlink_titles=\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=', 3, 0, 0, '', '', 0, 2, 'robots=\nauthor='),
(9, 'Example News Item 4', 'example-news-item-4', '', '<p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.</p>', '<p><img src="images/stories/fruit/strawberry.jpg" alt="" align="left" />Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi. Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat.</p>  <hr class="system-pagebreak" /><p><img src="images/stories/fruit/pears.jpg" alt="" align="right" />Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi.</p>  <p><img src="images/stories/fruit/cherry.jpg" alt="" align="left" />Nam liber tempor cum soluta nobis eleifend option congue nihil imperdiet doming id quod mazim placerat facer possim assum. Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat.</p>  <p>Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, At accusam aliquyam diam diam dolore dolores duo eirmod eos erat, et nonumy sed tempor et et invidunt justo labore Stet clita ea et gubergren, kasd magna no rebum. sanctus sea sed takimata ut vero voluptua. est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat.</p>  <hr class="system-pagebreak" /><p>Consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.</p>', -2, 1, 0, 1, '2004-07-07 11:54:06', 62, '', '2007-05-03 09:41:24', 62, 0, '0000-00-00 00:00:00', '2004-07-07 00:00:00', '0000-00-00 00:00:00', '', '', 'pageclass_sfx=\nshow_title=1\nlink_titles=\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=', 3, 0, 0, '', '', 0, 7, 'robots=\nauthor='),
(10, 'How do I localise Joomla! to my language?', 'how-do-i-localise-joomla-to-my-language', '', '<h4>General<br /></h4><p>In Joomla! 1.5 all user interfaces can be localised. This includes the installation, the administrator interface and the front end site.</p><p>The core release of Joomla! 1.5 is shipped with mutliple language choices in the installation but languages for the site and administration interfaces need to be added after installation. (Other than English). Links to such language packs exist below.</p>', '<p>Translation Teams for Joomla! 1.5 may have also released fully localised installation packages where site, administrator and sample data are in the local language. These localised releases can be found in the specific team projects on the Joomla! Forge.</p><h4>How do I install language packs?</h4><ul><li>First download both the admin and the site language packs that you require.</li><li>Install each pack separately using the Extensions-&gt;Install/Uninstall menu selection and then the package file upload facility.</li><li>Go to the Language Manager and be sure to select Site or Admin in the sub-menu. Then select the appropriate language and make it the default one using the toolbar button.</li></ul><h4>How do I select languages?</h4><ul><li>Default language can be individually set for site and for admin</li><li>In addition, users can define their preferred language for each site and admin. This takes affect after logging in<br /></li><li>While logging in to the admin, a language can be selected for the particular session.</li></ul><h4>Where can I find Language Packs and Localised Releases?</h4><p><em>Please note that Joomla! 1.5 is new and language packs for this version may have not been released at this time.</em> </p><ul><li><a href="http://forge.joomla.org/sf/frs/do/viewSummary/projects.joomla_translations/frs" target="_blank" title="Accredited Translations">The Joomla! Accredited Translations Project</a>  - This is a joint repository for language packs that were developed by teams that are members of the Joomla! Translations Working Group.</li><li><a href="http://extensions.joomla.org/component/option,com_mtree/task,listcats/cat_id,1837/Itemid,35/" target="_blank" title="Translations">The Joomla! Extensions Site - Translations</a>  <br /></li><li><a href="http://dev.joomla.org/content/view/42/66/" target="_blank" title="Translation Work Group Teams">List of Translation Teams and Translation Partner Sites for Joomla! 1.5</a> <br /></li></ul><h4>Mutli-lingual sites:</h4><p>Joomla! can be adapted to provide multi-lingual sites by installing the Joom-Fish component. </p><ul><li> <a href="http://extensions.joomla.org/component/option,com_mtree/task,listcats/cat_id,1838/Itemid,35/" target="_blank" title="Joom-Fish">The Joomla! Extenstions Site  - Multi-lingual Content</a></li></ul>', -2, 3, 0, 32, '2006-09-30 16:06:37', 62, '', '2007-05-03 09:40:39', 62, 0, '0000-00-00 00:00:00', '2006-09-29 12:00:00', '0000-00-00 00:00:00', '', '', 'pageclass_sfx=\nshow_title=1\nlink_titles=\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=', 8, 0, 0, '', '', 0, 6, 'robots=\nauthor='),
(11, 'How do I upgrade to Joomla! 1.5 ?', 'how-do-i-upgrade-to-joomla-15', '', '<p>Joomla 1.5 does not provide an upgrade path from earlier versions. Converting an older site to a Joomla 1.5 site requires creation of a new empty site using Joomla 1.5 and then populating the new site with the content from the old site. This migration of content is not a one-to-one process and involves conversions and modifications to the content dump.</p> <p>There are two ways to perform the migration:</p>', ' <div id="post_content-107"><li>An automated method of migration has been provided which uses a migrator component to create the migration dump out of the old site (Mambo 4.5.x up to Joomla 1.0.x) and a smart import facility in the Joomla 1.5 Installation that performs required conversions and modifications during the installation process.</li> <li>Migration can be performed manually. This involves exporting the required tables, manually performing required conversions and modifications and then importing the content to the new site after it is installed.</li>  <p><!--more--></p> <h4><strong> Automated migration</strong></h4>  <p>This is a two phased process using two tools. The first tool is a migrator component named ''com_migrator''. This component has been contributed by Harald Baer and is based on his ''eBackup'' component. The migrator needs to be installed on the old site and when activated it prepares the required export dump of the old site''s data. The second tool is built into the Joomla 1.5 installation process. The exported content dump is loaded to the new site and all conversions and modification are performed ''on-the-fly''.</p> <p><u><br /> Step 1 - Using com_migrator to export data from old site:</u></p> <li>Install the com_migrator component on the <u><strong>old</strong></u> site. It can be found at the <a href="http://forge.joomla.org/sf/frs/do/listReleases/projects.joomla_addons/frs.com_migrator" target="_blank">Joomla! official Addons forge</a> .<br /></li> <li>Select the component in the component menu of the administrator.</li> <li>Click on the ''Dump it'' icon. Three exported gzipped export scripts will be created. The first is a complete backup of the old site. The second is the migration content of all core elements which will be imported to the new site. The third is a backup of all 3PD component tables.</li> <li>Click on the download icon of the particular exports files needed and store locally.</li> <li>Multiple export sets can be created.</li> <li>The exported data is not modified in anyway and the original encoding is preserved. This makes the com_migrator tool a recommended tool to use for manual migration as well.</li> <p><u><br /> Step 2 - Using the migration facility to import and convert data during Joomla 1.5 installation:</u></p><p>Note: This function requires use of the iconv function in PHP to convert encodings. If iconv is not found a warning will be provided.</p> <li>In step 6 - Configuration select the ''Load Migration Script'' option in the ''Load Sample Data, Restore or Migrate Backed Up Content'' section of the page.</li> <li>Enter the table prefix used in the content dump. For example: ''#_'' or ''#__'' are acceptable values.</li> <li>Select the encoding of the dumped content in the dropdown list. This should be the encoding used on the pages of the old site. (As defined in the _ISO variable in the language file or as seen in the browser page info/encoding/source)</li> <li>Browse the local host and select the migration export and click on ''Upload and Execute''</li> <li>A success message should appear or alternately a listing of db errors</li> <li>Complete the other required fields in the Configuration step such as Site Name and Admin details and advance to the final step of installation. (Admin details will be ignored as the imported data will take priority. Please remember admin name and password from the old site)</li> <p><u><br /></u></p></div>', -2, 3, 0, 28, '2006-10-01 00:27:52', 62, '', '2007-05-03 09:36:41', 62, 0, '0000-00-00 00:00:00', '2006-09-29 16:00:00', '0000-00-00 00:00:00', '', '', 'pageclass_sfx=\nshow_title=1\nlink_titles=\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=', 8, 0, 0, '', '', 0, 9, 'robots=\nauthor='),
(12, 'Why does Joomla! 1.5 use utf-8 encoding?', 'why-does-joomla-15-use-utf-8-encoding', '', '<p>Well... how about never needing to mess with encoding settings again?</p><p>Ever needed to display several languages on one page or site and something always came up in Giberish?</p><p>With utf-8 (a variant of Unicode) glyphs (charcter forms) of all basically all languages can be displayed with one single encoding setting. For example if you might wish to say WELCOME in as many language possible you could do the following:</p>', '', -2, 3, 0, 31, '2006-10-05 03:11:29', 62, '', '2007-05-03 09:39:54', 62, 0, '0000-00-00 00:00:00', '2006-10-03 12:00:00', '0000-00-00 00:00:00', '', '', 'pageclass_sfx=\nshow_title=1\nlink_titles=\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=', 7, 0, 0, '', '', 0, 25, 'robots=\nauthor='),
(13, 'What happened to the locale setting?', 'what-happened-to-the-locale-setting', '', 'This is now defined in the language &lt;lang&gt;.xml file in the language metadata settings. If you are having locale problems (dates don''t appear in your language) you might want to check/edit the entries in the locale tag. Note that multiple locale strings can be set and the host will usually accept the first one recognised.', '', -2, 3, 0, 28, '2006-10-06 18:47:35', 62, '', '2007-05-03 09:36:34', 62, 0, '0000-00-00 00:00:00', '2006-10-05 16:00:00', '0000-00-00 00:00:00', '', '', 'pageclass_sfx=\nshow_title=1\nlink_titles=\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=', 6, 0, 0, '', '', 0, 6, 'robots=\nauthor='),
(14, 'What is the FTP layer for?', 'what-is-the-ftp-layer-for', '', '<p>This allows file operations (such installing extensions or updating the main configuration) without having to make all the folders and files writeable. This makes the site admin''s life a lot easier and increases security of the site</p><p>You can check the write status of relevent folders by going to ''''Help-&gt;System Info" and then in the sub-menu to "Directory Permissions". With FTP even if all directories are red, Joomla! will operate smoothly.</p><p>NOTE: the FTP layer is not required on a Windows host. </p>', '', -2, 3, 0, 31, '2006-10-06 21:27:49', 62, '', '2007-05-03 09:39:48', 62, 0, '0000-00-00 00:00:00', '2006-10-05 16:00:00', '0000-00-00 00:00:00', '', '', 'pageclass_sfx=\nshow_title=1\nlink_titles=\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=', 6, 0, 0, '', '', 0, 8, 'robots=\nauthor='),
(15, 'Can Joomla! 1.5 operate with PHP Safe Mode On?', 'can-joomla-15-operate-with-php-safe-mode-on', '', '<p>Yes it can! This is a significant security improvement.</p><p>The safe mode limits PHP file to be able to perfom actions only on files/folders who''s owner is the same as PHP is currently using (this is usually ''apache''). As files normally are created either by the Joomla! application or by FTP access, the combination of PHP file actions and the FTP layer allows Joomla! to operate in PHP Safe Mode.</p>', '', -2, 3, 0, 31, '2006-10-06 21:28:35', 62, '', '2007-05-03 09:39:43', 62, 0, '0000-00-00 00:00:00', '2006-10-05 16:00:00', '0000-00-00 00:00:00', '', '', 'pageclass_sfx=\nshow_title=1\nlink_titles=\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=', 6, 0, 0, '', '', 0, 3, 'robots=\nauthor='),
(16, 'Only one edit window! How do I create "Read more..."?', 'only-one-edit-window-how-do-i-create-read-more', '', '<p>This is now implemented by inserting a tag (button is in the editor area) a dotted line appears in the edited text showing the split location for the "Read more...". A new bot takes care of the rest.</p><p>It is worth mentioning that this does not have a negative effect on migrated data from older sites. The new implementation is fully backward compatible.</p>', '', -2, 3, 0, 28, '2006-10-06 21:29:28', 62, '', '2007-05-03 09:36:49', 62, 0, '0000-00-00 00:00:00', '2006-10-05 16:00:00', '0000-00-00 00:00:00', '', '', 'pageclass_sfx=\nshow_title=1\nlink_titles=\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=', 6, 0, 0, '', '', 0, 9, 'robots=\nauthor='),
(17, 'My MySql database does not support UTF-8. Do I have a problem?', 'my-mysql-database-does-not-support-utf-8-do-i-have-a-problem', '', 'No you don''t. Versions of MySql lower than 4.1 do not have build in utf-8 support. However, Joomla! 1.5 has made provisions for backward compatibility and is able to use utf-8 on older databases. Let the installer take care of all settings and there is no need to make any changes to the database (charset, collation or any other).', '', -2, 3, 0, 31, '2006-10-07 13:30:37', 62, '', '2007-05-03 09:39:51', 62, 0, '0000-00-00 00:00:00', '2006-10-06 00:00:00', '0000-00-00 00:00:00', '', '', 'pageclass_sfx=\nshow_title=1\nlink_titles=\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=', 8, 0, 0, '', '', 0, 6, 'robots=\nauthor='),
(18, 'Joomla! Features', 'joomla-features', '', '<h4><font color="#ff6600">Joomla! features:</font></h4> <ul><li>Completely database driven site engines </li><li>News, products or services sections fully editable and manageable</li><li>Topics sections can be added to by contributing authors </li><li>Fully customisable layouts including left, center and right menu boxes </li><li>Browser upload of images to your own library for use anywhere in the site </li><li>Dynamic Forum/Poll/Voting booth for on-the-spot results </li><li>Runs on Linux, FreeBSD, MacOSX server, Solaris and AIX', '  </li></ul> <h4>Extensive Administration:</h4> <ul><li>Change order of objects including news, FAQs, articles etc. </li><li>Random Newsflash generator </li><li>Remote author submission module for News, Articles, FAQs and Links </li><li>Object hierarchy - as many sections, departments, divisions and pages as you want </li><li>Image library - store all your PNGs, PDFs, DOCs, XLSs, GIFs and JPEGs online for easy use </li><li>Automatic Path-Finder. Place a picture and let Joomla! fix the link </li><li>News feed manager. Choose from over 360 news feeds from around the world </li><li>Archive manager. Put your old articles into cold storage rather than throw them out </li><li>Email-a-friend and Print-format for every story and article </li><li>In-line Text editor similar to Word Pad </li><li>User editable look and feel </li><li>Polls/Surveys - Now put a different one on each page </li><li>Custom Page Modules. Download custom page modules to spice up your site </li><li>Template Manager. Download templates and implement them in seconds </li><li>Layout preview. See how it looks before going live </li><li>Banner manager. Make money out of your site</li></ul>', -2, 4, 0, 29, '2006-10-09 01:32:45', 62, '', '2007-05-03 09:36:05', 62, 0, '0000-00-00 00:00:00', '2006-10-07 08:00:00', '0000-00-00 00:00:00', '', '', 'pageclass_sfx=\nshow_title=1\nlink_titles=\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=', 10, 0, 0, '', '', 0, 52, 'robots=\nauthor='),
(19, 'Joomla! Overview', 'joomla-overview', '', '<p>If you''re new to web publishing systems, you''ll find that Joomla! delivers sophisticated solutions to your online needs. It can deliver a robust enterprise-level website, empowered by endless extensibility for your bespoke publishing needs. Moreover, it is often the system of choice for small business or home users who want a professional looking site that''s simple to deploy and use. We do content right.<br /> </p><p>So what''s the catch? How much does this system cost? Well, there''s good news ... and more good news! Joomla! 1.5 is free released under an Open Source license.</p><p>Had you invested in a commercial alternatives, there''d be nothing but moths left in your wallet.</p>Joomla! is set to change all that ... Joomla! is different from the normal models for content management software. For a start, it''s not complicated. Joomla! has been developed for everybody. It''s licensed under the GNU/GPL license, easy to install and administer and reliable. Joomla! doesn''t even require the user or administrator of the system to know HTML to operate it once it''s up and running.', '', -2, 4, 0, 29, '2006-10-09 09:49:20', 62, '', '2007-05-03 09:34:19', 62, 0, '0000-00-00 00:00:00', '2006-10-07 12:00:00', '0000-00-00 00:00:00', '', '', 'pageclass_sfx=\nshow_title=1\nlink_titles=\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=', 12, 0, 0, '', '', 0, 85, 'robots=\nauthor='),
(20, 'Support and Documentation', 'support-and-documentation', '', '<h1>Support </h1><p>Support for the Joomla! CMS can be found on several places. The best place to start would be the official <a href="http://help.joomla.org/" target="_blank">Help Site</a> . On the Help Site you can find a lot of documantation such as an Administrator manual, Developer info, Frequently Asked Questions and so on.</p><p>Of course you should not forget the Help System of the CMS itself. On the topmenu in the Backend Administrator you find the Help button which will provide you with lots of explanation on features. </p><p>Another great place would of course be the <a href="http://forum.joomla.org/" target="_blank">Forum</a> . On the Joomla! Forum you can find help and support from both Community members, but also from Joomla! Core members and Working Group members. The forum contains a lot of information, FAQ''s, just about anything you are looking for in terms of support.</p><p>Two other resources for Support are the <a href="http://dev.joomla.org/" target="_blank">Developer Site</a>  and the <a href="http://extensions.joomla.org/" target="_blank">Extensions Site</a> . The Developer Site for example provides lots of technical info to developers. The Joomla! Core members are regularly posting there blog reports about several topics such as programming techniques used in Joomla!, Security, Events and more.</p><h1>Documentation </h1><p>Joomla! Documentation can of course be found on the <a href="http://help.joomla.org/" target="_blank">Help Site</a> . You can find information such as an Installation Guide, User and Administrator manuals, Frueqently Asked Questions and a lot more.</p><p>Other than the documantation provided by the joomla! Core team, there are also books written about Joomla! You can find a listing of these books in the <a href="http://help.joomla.org/content/section/44/254/" target="_blank">Joomla! Bookshelf</a> . </p><p>Can you help?</p><p>Yes! If you have any suggestions for us, please post them to: <br /><a href="http://forum.joomla.org/index.php/board,59.0.html" target="_blank" title="http://forum.joomla.org/index.php/board,59.0.html" class="urlextern" onclick="return svchk()" onkeypress="return svchk()">http://forum.joomla.org/index.php/board,59.0.html</a></p>', '', -2, 4, 0, 25, '2006-10-09 10:33:57', 62, '', '2007-05-03 09:36:17', 62, 0, '0000-00-00 00:00:00', '2006-10-07 12:00:00', '0000-00-00 00:00:00', '', '', 'pageclass_sfx=\nshow_title=1\nlink_titles=\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=', 11, 0, 0, '', '', 0, 3, 'robots=\nauthor='),
(21, 'Joomla! Facts', 'joomla-facts', '', '<p>Here are some interesting facts about Joomla!</p><ul><li><span>Over 60,000 registered users on the Official Joomla! community site forum and more on the many international community sites.</span><br /></li><li><span>1168 Projects on the Joomla! Forge (<a href="http://forge.joomla.org/">forge.joomla.org</a> ). All for open source addons by third party developers. </span></li><li><span>890+ extensions for Joomla! registered on the Extension site (<a href="http://extensions.joomla.org/">extensions.joomla.org</a>)</span></li><li><span>Joomla.org exceeds 2 TB of traffic per month!</span></li><li><span>Alexa report [October 2006]: Joomla.org at #492 of top 500 busiest websites in the world.</span></li><li><span>Community <a href="http://forum.joomla.org" title="Joomla Forum">forums</a> , over half a million posts, and 60 000 activated users. </span>Growing at over 1200 posts per day and 150 new partcipants each day!</li></ul><p>&nbsp;</p>', '', -2, 4, 0, 30, '2006-10-09 18:46:37', 62, '', '2007-05-03 09:36:13', 62, 0, '0000-00-00 00:00:00', '2006-10-07 16:00:00', '0000-00-00 00:00:00', '', '', 'pageclass_sfx=\nshow_title=1\nlink_titles=\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=', 12, 0, 0, '', '', 0, 47, 'robots=\nauthor='),
(22, 'What''s New In 1.5?', 'whats-new-in-15', '', '<p>As with previous releases, Joomla! provides a unified and easy-to-use framework for delivering content for websites of all kinds. To support the changing nature of the Internet and emerging web technologies, Joomla! required substantial restructuring of its core functionality and we also used this effort to simplify many challenges within the current user interface. Joomla! 1.5 has many new features.</p>', '<p>&nbsp;</p><p style="margin-bottom: 0in">   The goals for the Joomla! 1.5 release are to: </p>    <ul><li>     <p style="margin-bottom: 0in">       Substantially improve usability, manageability, and scalability far beyond the original Mambo foundations.     </p>   </li><li>     <p style="margin-bottom: 0in"> Expand accessibility to support internationalisation, double-byte characters and Right-to-Left support for Arabic and Hebrew languages. </p>   </li><li>     <p style="margin-bottom: 0in"> Extend the integration of external applications through Web Services and remote authentication such as the Lightweight Directory Access Protocol (LDAP). </p>   </li><li>     <p style="margin-bottom: 0in"> Enhance the content delivery, template and presentation capabilities to support accessibility standards and content delivery to any destination. </p>   </li><li>     <p style="margin-bottom: 0in">       Achieve a more sustainable and flexible framework for component and extension developers.     </p>   </li><li>     <p style="margin-bottom: 0in">       Deliver backwards compatibility with previous releases of components, templates, modules and other extensions.</p></li></ul><p>&nbsp;</p>', -2, 4, 0, 29, '2006-10-12 00:13:58', 62, '', '2007-05-03 09:34:11', 62, 0, '0000-00-00 00:00:00', '2006-10-10 20:00:00', '0000-00-00 00:00:00', '', '', 'pageclass_sfx=\nshow_title=1\nlink_titles=\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=', 7, 0, 0, '', '', 0, 34, 'robots=\nauthor='),
(23, 'Platforms and Open Standards', 'platforms-and-open-standards', '', '<p class="MsoNormal">Joomla! runs on any platform including Windows, most flavors of Linux, Several Unix versions, and the Apple OSX platform.  Joomla! depends PHP and the MySQL database to deliver dynamic content.  </p>            <p class="MsoNormal">The minimum requirements are:</p>      <ul><li>Apache 1.x, 2.x and higher<br /></li><li>PHP 4.3 and higher</li><li>MySQL 3.23 and higher</li></ul>', '', -2, 4, 0, 25, '2006-10-11 08:22:14', 62, '', '2007-05-03 09:36:23', 62, 0, '0000-00-00 00:00:00', '2006-10-10 12:00:00', '0000-00-00 00:00:00', '', '', 'pageclass_sfx=\nshow_title=1\nlink_titles=\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=', 5, 0, 0, '', '', 0, 8, 'robots=\nauthor='),
(24, 'Content Layouts', 'content-layouts', '', '<p>Joomla! provides plenty of flexibility when displaying your web content. Whether you are using Joomla! for a blog site, news or a website for a company, you''ll find one or more content styles to showcase your information. You can also change the style of content dynamically depending on your preferences. Joomla calls how a page is laid out a <strong>layout</strong>. Use the guide below to understand which layouts are available and how you might use them. </p> <h2>Content </h2> <p>Joomla! makes it extremely easy to add and display content. All content  is placed where your mainbody tag in your template is located. There are three main types of layouts available in Joomla! and all of them can be customised via parameters. The display and parameters are set in the menu item used to display the content your working on. You create these layouts by creating a menu item and choosing how you want the content to display.</p> <h3>Blog layout<br /> </h3> <p>Blog layout will show a listing of all content items of the selected blog type (section or category) in the mainbody position of your template. It will give you the standard title, and Intro of each content article in that particular Category and/or Section. You can customise this layout via the use of the content parameters, (See Content Parameters) this is done from the menu not the section manager!</p> <h3>Blog Archive layout<br /> </h3> <p>A Blog Archive layout will give you a similar output of content as the normal Blog Display but will add at the top two dropdown boxes for Month and year plus a search button to allow users to search for all archived content from a specific month and year</p> <h3>Table layout<br /> </h3> <p>Table layout will simply give you a table of all the titles in that particular section or category. No intro will be displayed just the titles. You can set how many titles will be displayed in this table by Parameters. The table layout will also provide a filter section so that users can reorder, filter and set how many titles are listed on a single page (up to 50)</p> <h2>Wrapper</h2> <p>Wrappers allow you to place stand alone applications and 3rd party websites inside your Joomla! site. The content within a wrapper appears within the primary content area defined by the "mainbody" tag and allows you to display content to display them as part of your own site. A Wrapper will place an IFRAME into the content section of your website and wrap your standard template navigation around it so it appears in the same way a content item would.</p> <h2>Content Parameters</h2> <p>The parameters for each layout type can be found on the right hand side of the editor boxes in the menu item configuration screen. The parameters available depend largely on what kind of layout you are configuring.</p>', '', -2, 4, 0, 29, '2006-10-13 00:33:10', 62, '', '2007-05-03 09:36:12', 62, 0, '0000-00-00 00:00:00', '2006-10-11 08:00:00', '0000-00-00 00:00:00', '', '', 'pageclass_sfx=\nshow_title=1\nlink_titles=\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=', 10, 0, 0, '', '', 0, 46, 'robots=\nauthor='),
(25, 'What are the requirements to run Joomla! 1.5?', 'what-are-the-requirements-to-run-joomla-15', '', 'Joomla! runs on the php pre-processor. Php comes in many flavors, for a lot of operating systems. Beside php you will need a web server. Most of the times Apache is used, but also php can run on different web-servers like Microsoft IIS. Joomla! also depends on a database, for this currently you can only use MySQL. <br /><br />Many people know from their own experience that it''s not easy to install an Apache web server and it gets harder if you want to add MySQL, PHP and Perl. XAMPP is an easy to install Apache distribution containing MySQL, PHP and Perl. XAMPP is really very easy to install and to use - just download, extract and start. You can even install it on your local desktop or laptop with Windows XP. <br /><br />The minimum version requirements are:<br /><ul><li>Apache 1.x or 2.x<br /></li><li>PHP 4.3 or up<br /></li><li>MySQL 3.23 or up</li></ul>', '', -2, 3, 0, 31, '2006-10-11 02:42:31', 62, '', '2007-05-03 09:42:04', 62, 0, '0000-00-00 00:00:00', '2006-10-10 08:00:00', '0000-00-00 00:00:00', '', '', 'pageclass_sfx=\nshow_title=1\nlink_titles=\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=', 5, 0, 0, '', '', 0, 0, 'robots=\nauthor=');
INSERT INTO `jos_content` (`id`, `title`, `alias`, `title_alias`, `introtext`, `fulltext`, `state`, `sectionid`, `mask`, `catid`, `created`, `created_by`, `created_by_alias`, `modified`, `modified_by`, `checked_out`, `checked_out_time`, `publish_up`, `publish_down`, `images`, `urls`, `attribs`, `version`, `parentid`, `ordering`, `metakey`, `metadesc`, `access`, `hits`, `metadata`) VALUES
(26, 'Extensions', 'extensions', '', '<p>Out of the box, Joomla does a great job of managing the content needed to make your website sing. But for many people, the true power of Joomla lies in the application framework that makes it possible for thousands of developers around the world to create powerful add-ons that are called <strong>extensions</strong>. An extension is used to add capabilities to Joomla! that do not exist in the base core code. Here are just some examples of the hundreds of available extensions:</p> <ul>   <li>Dynamic form builders</li>   <li>Business or organisational directories</li>   <li>Document management</li>   <li>Image and multimedia galleries</li>   <li>E-commerce and shopping cart engines</li>   <li>Forums and chat software</li>   <li>Calendars</li>   <li>Email newsletters</li>   <li>Data collection and reporting tools</li>   <li>Banner advertising systems</li>   <li>Paid subscription services</li>   <li>and many, many more</li> </ul> <p>You can find more examples over at our growing <a href="http://extensions.joomla.org" target="_blank" title="Joomla! Extensions Directory">Joomla! Extensions Directory</a>. Prepare to be amazed at the amount of exciting work produced by our active developer community!</p><p>A useful guide to the extension site can be found at:<br /><a href="http://extensions.joomla.org/content/view/15/63/%20" target="_blank" title="Guide to the Joomla! Extension site">http://extensions.joomla.org/content/view/15/63/ </a> </p> <h3>Types of Extensions </h3><p>There are five types of extensions:</p> <ul>   <li>Components</li>   <li>Modules</li>   <li>Templates</li>   <li>Plugins</li>   <li>Languages</li> </ul> <p>You can read more about the specifics of these using the links in the article table of contents (another useful feature of Joomla!) at the top right or by clicking on the next link below.<br /> </p> <hr class="system-pagebreak" title="Components" /> <h3><img src="http://extensions.joomla.org/components/com_mtree/img/ext_com.png" border="0" alt="Component - Joomla! Extension Directory" title="Component - Joomla! Extension Directory" width="17" height="17" /> Components</h3> <p>A component is the largest and most complex of the extension types.  Components are like mini-applications that renders the main body of the  page. An analogy that might make the relationship easier to understand  would be that Joomla! is a book and all the components are chapters in  the book. The core content component (com_content), for example, is the  mini-application that handles all core content rendering just as the  core registration component (com_user) is the mini-application  that handles user registration.</p> <p>Many of Joomla''s core features are provided by the use of default components such as:</p> <ul>   <li>Contacts</li>   <li>Front Page</li>   <li>Newsfeeds</li>   <li>Banners</li>   <li>Mass Mail</li>   <li>Polls</li>   <li>RSS Syndication</li> </ul> <p>A Component will manage data, set displays, provide functions and in general can perform any operation that doesn''t fall under the general functions of the core code.</p> <p>Components work hand in hand with Modules and Plugins to provide a rich variety of content display and functionality aside from the standard article and content display. Components make it possible to completely transform Joomla and greatly expand its capabilities.</p> <p>More information on components is available from the Joomla! help manual: Components<br />   <a href="http://help.joomla.org/content/view/77/153/" target="_blank" title="Joomla! help manual: Components">http://help.joomla.org/content/view/77/153/</a></p> <hr class="system-pagebreak" title="Modules" /> <h3><img src="http://extensions.joomla.org/components/com_mtree/img/ext_mod.png" border="0" alt="Module - Joomla! Extension Directory" title="Module - Joomla! Extension Directory" width="17" height="17" /> Modules</h3> <p>A more lightweight and flexible extension used for page rendering is a  module. Modules are used for small bits of the page that are generally  less complex and able to be seen across different components. To  continue in our book analogy, a module can be looked at as a footnote  or header block, or perhaps an image/caption block that can be rendered  on a particular page. Obviously you can have a footnote on any page but  not all pages will have them. Footnotes also might appear regardless of  which chapter you are reading. Simlarly modules can be rendered  regardless of which component you have loaded.</p> <p>Modules are like little mini-applets that can be placed anywhere on your site. They work in conjunction with components in some cases and in others are complete stand alone snippets of code used to display some data from the database such as Content (Newsflash) Modules are usually used to output data but they can also be form items to input data (Login Module and Polls as an example)</p> <p>Modules can be assigned to module positions which are defined in both your template and backend under the Site/Template Manager/Module Positions menu items. For example, "left" and "right" are common for a 3 column layout. </p> <h4>Displaying Modules</h4> <p>Each module is assigned to a module position on your site. If you wish it to display in two different locations you must copy the module and assign the copy to display at the new location. You can also set which menu items (and thus pages) a module will display on. You can select all menu items or you can pick and choose specific menu items by holding down the control key and selecting multiple menu items one by one in the Modules Edit screen</p> <p>Note your Main Menu is a Module! When you create a new menu in the menu manager you are actually copying the Main Menu module code and giving it the name of your new menu. When you copy a module you do not copy all it''s parameters you simply allow Joomla to use the same code with two separate settings.</p> <h4>NewsFlash Example</h4> <p>NewsFlash is a Module which will display content items from your site in an assignable module position. It can be used and configured to display one category, all categories or to randomly choose content items to highlight to users. It will display as much of an article as you set, and will show a "read more" link to take the user to the full page.</p> <p>The Newsflash component is particularly useful for things like Site News or to show the latest content item added to your site.</p> <p>More information on Modules is available from the Joomla! help manual: Modules<br />   <a href="http://help.joomla.org/content/view/91/153/" target="_blank" title="Joomla! help manual: Modules">http://help.joomla.org/content/view/91/153/</a></p> <hr class="system-pagebreak" title="Plugins" /> <h3><img src="http://extensions.joomla.org/components/com_mtree/img/ext_plugin.png" border="0" alt="Plugin - Joomla! Extension Directory" title="Plugin - Joomla! Extension Directory" width="17" height="17" /> Plugins</h3> <p>One  of the more advanced extensions for Joomla! is the plugin (formerly called a mambot). In previous  versions plugins were known as mambots. Along with the development of  Joomla! 1.5, mambots have been renamed to plugins and their  functionality has been expanded. A plugin is a section of code that  runs when a pre-defined event happens within Joomla! Editors are  plugins, for example, that execute when the Joomla! event  "onGetEditorArea" occurs. Using a plugin allows a developer to change  the way their code behaves depending upon which plugins are installed  to react to an event.</p> <p>More information on Plugins is available from the Joomla! help manual: Plugins<br />   <a href="http://help.joomla.org/content/view/110/153/" target="_blank" title="Joomla! help manual: Plugins">http://help.joomla.org/content/view/110/153/</a></p> <hr class="system-pagebreak" title="Languages" /> <h3><img src="http://extensions.joomla.org/components/com_mtree/img/ext_lang.png" border="0" alt="Language - Joomla! Extensions Directory" title="Language - Joomla! Extensions Directory" width="17" height="17" /> Languages</h3> <p>New  to Joomla! 1.5 and perhaps the most basic and critical extension is a  language. Languages are packaged as either a core language pack or an  extension language pack. They allow both the Joomla! core as well as  third party components and modules to be internationalised.</p> <p>More information on languages is available from the Joomla! help manual: Languages<br />   <a href="http://help.joomla.org/content/view/23/160/" target="_blank" title="Joomla! help manual: Languages">http://help.joomla.org/content/view/23/160/</a></p>', '', -2, 4, 0, 29, '2006-10-11 12:00:00', 62, '', '2007-05-03 09:34:26', 62, 0, '0000-00-00 00:00:00', '2006-10-11 04:00:00', '0000-00-00 00:00:00', '', '', 'pageclass_sfx=\nshow_title=1\nlink_titles=\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=', 21, 0, 0, 'About Joomla!, General, Extensions', '', 0, 61, 'robots=\nauthor='),
(27, 'The Joomla Community', 'the-joomla-community', '', '<p><strong>Got a question? </strong>With over 60,000 members, the online forum at <a href="http://forum.joomla.org/" target="_blank">Joomla.org</a>  are a great resource for both new an experienced users. Go ahead, ask your toughest questions, the community is waiting to see what you''re going to do with your Joomla! site.</p><p><strong>Do you want to show off your new Joomla website?</strong> Go ahead, we have a section dedicated to that on our forum. </p><p><strong>Do you want to join in?</strong></p><p>If you think working with Joomla! is fun, wait until you start working on it. We''re passionate about helping Joomla! users make the jump to becoming contributing members of the community, so there are many ways you can help Joomla''s development:</p>                  <ul><li>Submit news about Joomla!. We syndicate all Joomla! related news on our <a href="http://news.joomla.org" title="Joomla! News Portal">news portal</a>. If you have some Joomla! news that you would like to share with the community, please submit your short story, article, announcement or review <a href="http://www.joomla.org/component/option,com_submissions/Itemid,75" title="Submit News">here</a>. </li><li>Report bugs and request features in our <a href="http://forge.joomla.org/sf/tracker/do/listTrackers/projects.joomla/tracker" title="Joomla! developement trackers">trackers</a>. Please read <a href="#reporting%20bugs">Reporting bugs</a>, below, for details on how we like our bug reports served up</li><li>Submit patches for new and/or fixed behavior. Please read <a href="#Submitting%20patches">Submitting patches</a>, below, for details on how to submit a patch.</li><li>Join the <a href="http://forum.joomla.org/index.php/board,126.0.html" title="Joomla! development forums">developer forums</a> and share your ideas for how to improve Joomla!. We''re always open to suggestions, although we''re likely to be skeptical of large-scale suggestions without some code to back it up.</li><li>Join any of the <a href="content/view/13/53/" title="Joomla! working groups">community working groups</a>  and bring your personal expertise to  the Joomla! community. More info about the different working groups can be found <a href="content/view/13/53/" title="Joomla! working groups">here</a>.      </li></ul>           <p> That''s all you need to know if you''d like to join the Joomla! development community.  </p>', '', -2, 4, 0, 30, '2006-10-12 18:50:48', 62, '', '2007-05-03 09:36:16', 62, 0, '0000-00-00 00:00:00', '2006-10-11 04:00:00', '0000-00-00 00:00:00', '', '', 'pageclass_sfx=\nshow_title=1\nlink_titles=\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=', 9, 0, 0, '', '', 0, 36, 'robots=\nauthor='),
(28, 'How do I install Joomla! 1.5?', 'how-do-i-install-joomla-15', '', 'Installing of Joomla! 1.5 is pretty easy. We assume you have set-up your website, and it is accessible with your browser.<br /><br />Download Joomla! 1.5, unzip it and put the files into the directory you website points to, fire up your browser and go to the page and the installation will start. We refer to the installation instructions on the help site for more information.', '', -2, 3, 0, 31, '2006-10-11 03:10:59', 62, '', '2007-05-03 09:37:17', 62, 0, '0000-00-00 00:00:00', '2006-10-10 08:00:00', '0000-00-00 00:00:00', '', '', 'pageclass_sfx=\nshow_title=1\nlink_titles=\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=', 4, 0, 0, '', '', 0, 0, 'robots=\nauthor='),
(29, 'What is the purpose of the collation selection in the installation screen?', 'what-is-the-purpose-of-the-collation-selection-in-the-installation-screen', '', 'The collation option determines the way ordering in the database is done. In languages that use special characters, for instance the German umlaut, the database collation determines the sorting order. If you don''t know which collation you need, select the "utf8_general_ci" as most languages use this. The other collations listed are exceptions in regards to the general collation. If your language is not listed in the list of collations it most likely means that "utf8_general_ci is suitable.', '', -2, 3, 0, 32, '2006-10-11 03:11:38', 62, '', '2007-05-03 09:40:32', 62, 0, '0000-00-00 00:00:00', '2006-10-10 08:00:00', '0000-00-00 00:00:00', '', '', 'pageclass_sfx=\nshow_title=1\nlink_titles=\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=', 4, 0, 0, '', '', 0, 0, 'robots=\nauthor='),
(30, 'What languages are supported by Joomla! 1.5?', 'what-languages-are-supported-by-joomla-15', '', 'Within the installer you will find a wide collection of languages. The installer currently supports the following languages: Arabic, Bulgarian, Bengali, Czech, Danish, German, Greek, English, Spanish, Finnish, French, Hebrew, Devanagari(India), Croatian(Croatia), Magyar (Hungary), Italian, Malay,<br />Norwegian bokmal, Dutch, Portuguese(Brasil), Portugues(Portugal), Romanian, Russian, Serbian, Svenska, Thai and more are being added.<br /><br />By default the English language is installed for the back and front-ends. You can download the language files from the Joomla! extensions site. In addition some translation teams are offering fully localised versions of the entire package. Please check the <a href="http://help.joomla.org/content/view/1651/62/" target="blank_" title="Joomla! help site for links">Joomla! help site for links</a>   to locations where languages and localised versions can be found.', '', -2, 3, 0, 32, '2006-10-11 03:12:18', 62, '', '2007-05-03 09:40:06', 62, 0, '0000-00-00 00:00:00', '2006-10-10 08:00:00', '0000-00-00 00:00:00', '', '', 'pageclass_sfx=\nshow_title=1\nlink_titles=\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=', 4, 0, 0, '', '', 0, 1, 'robots=\nauthor='),
(31, 'Is it useful to install the example data?', 'is-it-useful-to-install-the-example-data', '', 'This depends on what you want to achieve. If you are new to Joomla! and have no clue how all fits together, just install the example data. If you don''t like the English example because you - for instance - speak Chinese, then leave it out.', '', -2, 3, 0, 27, '2006-10-11 11:12:55', 62, '', '2007-05-03 09:40:56', 62, 0, '0000-00-00 00:00:00', '2006-10-10 12:00:00', '0000-00-00 00:00:00', '', '', 'pageclass_sfx=\nshow_title=1\nlink_titles=\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=', 5, 0, 0, '', '', 0, 0, 'robots=\nauthor='),
(32, 'Where is the static content?', 'where-is-the-static-content', '', 'In Joomla! versions prior to 1.5 there was a distinctive difference on static and normal content. Both content types are still around, but are not handled as separate items. If you want to create static content, just select "<span style="font-style: italic">uncategorized</span>" as section and category and the content is handled as static content.', '', -2, 3, 0, 28, '2006-10-11 03:13:33', 62, '', '2007-05-03 09:37:04', 62, 0, '0000-00-00 00:00:00', '2006-10-10 08:00:00', '0000-00-00 00:00:00', '', '', 'pageclass_sfx=\nshow_title=1\nlink_titles=\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=', 4, 0, 0, '', '', 0, 0, 'robots=\nauthor='),
(33, 'What is emarketing ', 'what-is-uncategorised-content', '', 'Most articles will be assigned to a section and category. In many cases, you might not know where you want it to appear so put the article in the uncategorized section. The articles marked as uncategorized are handled as static content.', '', 1, 3, 0, 31, '2006-10-11 19:14:11', 62, '', '2008-11-18 08:46:54', 62, 0, '0000-00-00 00:00:00', '2006-10-10 16:00:00', '0000-00-00 00:00:00', '', '', 'show_title=1\nlink_titles=\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 7, 0, 2, '', '', 0, 6, 'robots=\nauthor='),
(34, 'Does the PDF icon render pictures and special characters?', 'does-the-pdf-icon-render-pictures-and-special-characters', '', 'Yes! Prior to Joomla! 1.5, only the text values of an article and only for ISO-8859-1 encoding was allowed in the PDF rendition. With the new PDF library in place, the complete article including images is rendered and applied to the PDF. The PDF generator also handles the UTF-8 texts and can handle any character sets from any language. The appropriate fonts must be installed but this is done automatically during a language pack installation.', '', -2, 3, 0, 32, '2006-10-11 19:14:57', 62, '', '2007-05-03 09:40:13', 62, 0, '0000-00-00 00:00:00', '2006-10-10 16:00:00', '0000-00-00 00:00:00', '', '', 'pageclass_sfx=\nshow_title=1\nlink_titles=\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=', 6, 0, 0, '', '', 0, 2, 'robots=\nauthor='),
(35, 'Is it possible to change the types of menu entries?', 'is-it-possible-to-change-the-types-of-menu-entries', '', 'You indeed can change the menu items type to whatever you want, even after they have been created. If you for instance want to change the blog section of a menu link, jump to the back end and edit the menu item. Push the "<span style="font-style: italic">change type</span>" button and select the details for the menu you want to assign.', '', 1, 3, 0, 31, '2006-10-11 03:15:36', 62, '', '2007-05-03 09:37:09', 62, 0, '0000-00-00 00:00:00', '2006-10-10 08:00:00', '0000-00-00 00:00:00', '', '', 'pageclass_sfx=\nshow_title=1\nlink_titles=\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=', 4, 0, 1, '', '', 0, 0, 'robots=\nauthor='),
(36, 'Where did the installer go?', 'where-did-the-installer-go', '', 'The improved installer can be found under the extensions option. With versions prior to 1.5 you needed to select a specific extensions type when you wanted to install it, with Joomla! 1.5 you just select the extension you want to upload, and click on install. The installer will do all the hard work for you.', '', -2, 3, 0, 28, '2006-10-11 03:16:20', 62, '', '2007-05-03 09:36:22', 62, 0, '0000-00-00 00:00:00', '2006-10-10 08:00:00', '0000-00-00 00:00:00', '', '', 'pageclass_sfx=\nshow_title=1\nlink_titles=\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=', 4, 0, 0, '', '', 0, 0, 'robots=\nauthor='),
(37, 'Where did the Mambots go?', 'where-did-the-mambots-go', '', 'Mambots have been renamed as "Plugins" Mambots were introduced in Mambo and offered possibilities to add plugin logic to your site to mainly for the purpose of manipulating content. In Joomla!, Plugins will now have much broader capabilities than Mambots. Plugins are able to extend functionality at the framework layer as well.', '', -2, 3, 0, 28, '2006-10-11 11:17:00', 62, '', '2007-05-03 09:37:00', 62, 0, '0000-00-00 00:00:00', '2006-10-10 12:00:00', '0000-00-00 00:00:00', '', '', 'pageclass_sfx=\nshow_title=1\nlink_titles=\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=', 5, 0, 0, '', '', 0, 0, 'robots=\nauthor='),
(38, 'I installed with my own language, but the back end is still in English', 'i-installed-with-my-own-language-but-the-back-end-is-still-in-english', '', '<p>A lot of different languages are available for the back end, but by default this language may not be installed. If you want a translated back end, get your language pack and install it using the back end installer. After this, go to the extensions menu, select language manager and make your language the default one. Your back end will be translated instantaneously.</p><p>Users who have access rights to the back end may choose the language they prefer in their personal details parameters.</p><p>This is of course also true for the front-end language. </p><p> A good place to find where to download your languages and localised versions of Joomla is on our <a href="http://help.joomla.org/content/view/1651/62/" target="blank_" title="Help Site">Help Site</a>.</p>', '', -2, 3, 0, 32, '2006-10-11 19:18:14', 62, '', '2007-05-03 09:40:01', 62, 0, '0000-00-00 00:00:00', '2006-10-10 16:00:00', '0000-00-00 00:00:00', '', '', 'pageclass_sfx=\nshow_title=1\nlink_titles=\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=', 6, 0, 0, '', '', 0, 3, 'robots=\nauthor='),
(39, 'How do I remove an article?', 'how-do-i-remove-an-article', '', '<p>To completely remove an article, select the articles that you want to delete and move them to the trash. Next, open the Article Trash in the Content menu and select the articles you want to delete. After deleting an article, it is no longer available and it is not possible to undo this operation.  </p>', '', -2, 3, 0, 27, '2006-10-11 11:19:01', 62, '', '2007-05-03 09:40:48', 62, 0, '0000-00-00 00:00:00', '2006-10-10 12:00:00', '0000-00-00 00:00:00', '', '', 'pageclass_sfx=\nshow_title=1\nlink_titles=\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=', 5, 0, 0, '', '', 0, 4, 'robots=\nauthor='),
(40, 'What is the difference between archiving and trashing an article?', 'what-is-the-difference-between-archiving-and-trashing-an-article', '', '<p>When you archive an article, the content is put into a state which removes it from your site as published content. The article is still available from within the administration interface and can be retrieved for archival purposes. Trashed articles are just one step from being deleted but are still available until you remove the items from the trash manager. You should use archive if you consider an article important, but not current. Trashed should be used when you want to delete the content entirely from your site and from future search results.  </p>', '', -2, 3, 0, 27, '2006-10-11 11:19:43', 62, '', '2007-05-03 09:40:44', 62, 0, '0000-00-00 00:00:00', '2006-10-10 12:00:00', '0000-00-00 00:00:00', '', '', 'pageclass_sfx=\nshow_title=1\nlink_titles=\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=', 5, 0, 0, '', '', 0, 2, 'robots=\nauthor='),
(41, 'Newsflash 5', 'newsflash-5', '', 'Joomla! 1.5 - ''Experience the Freedom''!. It has never been easier to create your own dynamic site. Manage all your content from the best CMS admin interface and in virtually any language you speak.', '', -2, 1, 0, 3, '2006-10-12 02:17:31', 62, '', '2007-05-03 09:41:36', 62, 0, '0000-00-00 00:00:00', '2006-10-11 08:00:00', '0000-00-00 00:00:00', '', '', 'pageclass_sfx=\nshow_title=1\nlink_titles=\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=', 4, 0, 0, '', '', 0, 4, 'robots=\nauthor='),
(42, 'Newsflash 4', 'newsflash-4', '', 'Yesterday all servers in the U.S. went out on strike in a bid to get more RAM and better CPUs. A spokes person said that the need for better RAM was due to some fool increasing the front-side bus speed. In future, busses will be told to slow down in residential motherboards.', '', -2, 1, 0, 3, '2006-10-12 02:25:50', 62, '', '2007-05-03 09:41:28', 62, 0, '0000-00-00 00:00:00', '2006-10-11 08:00:00', '0000-00-00 00:00:00', '', '', 'pageclass_sfx=\nshow_title=1\nlink_titles=\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=', 4, 0, 0, '', '', 0, 1, 'robots=\nauthor='),
(43, 'Example Pages and Menu Links', 'example-pages-and-menu-links', '', '<p>This page is an example of content that is "uncategorized". You will see there is a new menu in the left column. It shows links to the SAME content presented in 4 different page layouts.</p><ul><li>A Blog of a section</li><li>A Table of a Section</li><li>A Blog of a Category</li><li>A Table of a Category</li></ul><p>Follow the links in the Example Pages menu to see some of the options available to you to present content.</p><p>You can also have links to components and individual articles. This is all controlled in the menu links. </p>', '', 1, 0, 0, 0, '2006-10-12 11:26:52', 62, '', '2007-05-03 09:34:04', 62, 0, '0000-00-00 00:00:00', '2006-10-11 12:00:00', '0000-00-00 00:00:00', '', '', 'pageclass_sfx=\nshow_title=1\nlink_titles=\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=', 6, 0, 22, 'Uncategorized, Uncategorized, Example Pages and Menu Links', '', 0, 26, 'robots=\nauthor='),
(44, 'eAdvertisers ', 'typography', '', '<strong><u><span style="font-family: ''Arial'',''sans-serif''"><font size="3"><font color="#999999"></font></font></span></u></strong> <span style="font-family: ''Arial'',''sans-serif''"><font size="3" color="#999999"> </font></span><span style="font-family: ''Arial'',''sans-serif''"><font size="3"><font color="#999999">Why take your brand online?</font></font></span><span style="font-family: ''Arial'',''sans-serif''"><font size="3" color="#999999"> </font></span><span style="font-family: ''Arial'',''sans-serif''"><font size="3"><font color="#999999">By being online you have the ability to cast your reach worldwide, being seen by millions of sets of eyes at a fraction of cost of traditional mediums.</font></font></span><span style="font-family: ''Arial'',''sans-serif''"><font size="3" color="#999999"> </font></span><span style="font-family: ''Arial'',''sans-serif''"><font size="3"><font color="#999999">You can drive the world to your site where you can interact, learn about and captivate your audience. </font></font></span><span style="font-family: ''Arial'',''sans-serif''"><font size="3" color="#999999"> </font></span><span style="font-family: ''Arial'',''sans-serif''"><font size="3"><font color="#999999">Capture their data and forge lasting relationships, build brand loyalty, communicate relevant information and listen to those who know best….your customers.</font></font></span><span style="font-family: ''Arial'',''sans-serif''"><font size="3" color="#999999"> </font></span><span style="font-family: ''Arial'',''sans-serif''"><font size="3"><font color="#999999">The future is online!</font></font></span><span style="font-family: ''Arial'',''sans-serif''"><font size="3" color="#999999"> </font></span><span style="font-family: ''Arial'',''sans-serif''"><font size="3" color="#999999"> </font></span><span style="font-family: ''Arial'',''sans-serif''"><font size="3"><font color="#999999">Expertise, experience, technology, transparency and the largest reach in the Arab speaking world makes E-Marketing the leading ad network for advertising and advertisers.</font></font></span><span style="font-family: ''Arial'',''sans-serif''"><font size="3" color="#999999"> </font></span><span style="font-family: ''Arial'',''sans-serif''"><font size="3"><font color="#999999">We focus on performance and results, identifying wants and needs devising long and short term plans to increase your awareness, deliver visitors, generate leads/<span>  </span>registrations and drive sales.</font></font></span><span style="font-family: ''Arial'',''sans-serif''"><font size="3" color="#999999"> </font></span><span style="font-family: ''Arial'',''sans-serif''"><font size="3"><font color="#999999">So when you are challenged by complex plans, tight deadlines, and getting results, we''ll be there with e-marketing solutions that are smart, flexible, quick and most importantly work. Let us deliver for you.</font></font></span><span style="font-family: ''Arial'',''sans-serif''"><font size="3" color="#000000"> </font></span><span style="font-family: ''Arial'',''sans-serif''"><font size="3" color="#000000"> </font></span> <p> </p>', '', 1, 0, 0, 0, '2007-06-04 14:55:09', 62, '', '2008-11-18 09:24:55', 62, 0, '0000-00-00 00:00:00', '2007-06-04 14:55:09', '0000-00-00 00:00:00', '', '', 'show_title=1\nlink_titles=\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_vote=\nshow_author=0\nshow_create_date=0\nshow_modify_date=0\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 4, 0, 16, '', '', 0, 88, 'robots=\nauthor='),
(45, '  About e-Marketing', 'switch', '', '<p><span style="font-family: ''Arial'',''sans-serif''"><font color="#808080"><span style="font-size: 10pt; font-family: ''Arial'',''sans-serif''"><img src="images/stories/emarketing.png" border="0" width="165" height="214" align="left" /> </span></font></span></p><p><span style="font-family: ''Arial'',''sans-serif''"><font color="#808080"><span style="font-size: 10pt; font-family: ''Arial'',''sans-serif''">E-Marketing is the leading ad network in the Middle East and North Africa boasting the largest reach in the Arab speaking world serving over<strong> 600 million monthly impressions</strong> and over <strong>29 million unique users</strong> bridging the gap allowing the world to communicate with this hard to reach targeted audience offering various channels which service our clients every desire.</span><span style="font-size: 10pt; font-family: ''Arial'',''sans-serif''"> </span><span style="font-size: 10pt; font-family: ''Arial'',''sans-serif''">We partner the top publishers in the region and provide advertisers with targeted ad placements. We offer site-specific, channel-wide and run of network solutions, we deliver results through expert advice, intelligent technology and experience.</span><span style="font-size: 10pt; font-family: ''Arial'',''sans-serif''"> </span><span style="font-size: 10pt; font-family: ''Arial'',''sans-serif''">Us</span><span style="font-size: 10pt; font-family: ''Arial'',''sans-serif''">ing</span><span style="font-size: 10pt; font-family: ''Arial'',''sans-serif''"> the most advanced banner management system and targeting solutions in<span>  </span>in the world (double click)</span><span style="font-size: 10pt; font-family: ''Arial'',''sans-serif''">, w</span><span style="font-size: 10pt; font-family: ''Arial'',''sans-serif''">e take care of everything and you</span><span style="font-size: 10pt; font-family: ''Arial'',''sans-serif''">,</span><span style="font-size: 10pt; font-family: ''Arial'',''sans-serif''"> from targeting and optimisation, strategy to creative, web to video</span><span style="font-size: 10pt; font-family: ''Arial'',''sans-serif''">, </span><span style="font-size: 10pt; font-family: ''Arial'',''sans-serif''">mobile to search</span><span style="font-size: 10pt; font-family: ''Arial'',''sans-serif''"> and trafficking & reporting</span><span style="font-size: 10pt; font-family: ''Arial'',''sans-serif''">.</span><span style="font-size: 10pt; font-family: ''Arial'',''sans-serif''"> </span><span style="font-size: 10pt; font-family: ''Arial'',''sans-serif''"> </span></font><span style="font-size: 10pt; font-family: ''Arial'',''sans-serif''"><font color="#000000"><font color="#808080">E – marketing is built on a foundation of strong core values. We believe in reaching for excellence in everything that we do. From the quality of our products and publishers to the delivery of customer service and consultancy, we constantly aim to exceed expectations. </font></font></span></span></p>', '', 1, 0, 0, 0, '2007-06-04 14:56:16', 62, '', '2008-11-20 07:30:17', 62, 0, '0000-00-00 00:00:00', '2007-06-04 14:56:16', '0000-00-00 00:00:00', '', '', 'show_title=1\nlink_titles=\nshow_intro=0\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_vote=\nshow_author=0\nshow_create_date=0\nshow_modify_date=0\nshow_pdf_icon=0\nshow_print_icon=0\nshow_email_icon=0\nlanguage=\nkeyref=\nreadmore=', 19, 0, 17, '', '', 0, 859, 'robots=\nauthor='),
(46, 'Top Panel', 'Features', '', '<img style="margin: 0px 0px 10px 10px" src="images/yootheme/features_toppanel.jpg" alt="Top Panel" title="Top Panel" width="240" height="180" align="right" />\r\nThe Top Panel is a hidden module area at the top of the template. By clicking the "Top Panel" button it slides down. To hide the Top Panel click the "Close" button at the upper right or hit the "Top Panel" button once again.\r\n<br />\r\n<br />\r\nAny content you publish in the "cpanel" module position appears in the Top Panel. It''s suitable for self presentation, legal information or login module.\r\n<br /><br />\r\nUse the template configuration to turned off the Top Panel. How does it look? <a href="index.php?option=com_content&task=view&id=18&Itemid=83">Click here!</a><br />\r\n<br />\r\n<pre style="clear: both;">\r\n/*** template parameters ***/\r\n$template_parameters = array(\r\n	"toppanel" => true        /* true | false */\r\n);\r\n\r\n</pre>\r\n<br />\r\n<br />', '', 1, 0, 0, 0, '2007-06-04 14:58:32', 62, '', '0000-00-00 00:00:00', 0, 0, '0000-00-00 00:00:00', '2007-06-04 14:58:32', '0000-00-00 00:00:00', '', '', 'pageclass_sfx=\nshow_title=1\nlink_titles=\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_vote=\nshow_author=0\nshow_create_date=0\nshow_modify_date=0\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=', 1, 0, 18, '', '', 0, 0, 'robots=\nauthor='),
(47, 'Publishers ', 'publishers-', '', '<font color="#000000"><strong><u></u></strong><u><span style="font-size: 10pt; font-family: ''Arial'',''sans-serif''"></span></u></font> <span style="font-size: 10pt; font-family: ''Arial'',''sans-serif''"><font color="#000000"> </font></span><font color="#000000"><strong><span style="font-size: 10pt; font-family: ''Arial'',''sans-serif''">Benefits include</span></strong><span style="font-size: 10pt; font-family: ''Arial'',''sans-serif''"> – </span></font><ul style="margin-top: 0cm"><li class="MsoNormal" style="margin: 0cm 0cm 0pt; tab-stops: list 36.0pt"><span style="font-size: 10pt; font-family: ''Arial'',''sans-serif''"><font color="#000000">Top CPM rates </font></span></li><li class="MsoNormal" style="margin: 0cm 0cm 0pt; tab-stops: list 36.0pt"><span style="font-size: 10pt; font-family: ''Arial'',''sans-serif''"><font color="#000000">Increased sales force at a reduced cost </font></span></li><li class="MsoNormal" style="margin: 0cm 0cm 0pt; tab-stops: list 36.0pt"><span style="font-size: 10pt; font-family: ''Arial'',''sans-serif''"><font color="#000000">Free ad-serving solution using the worlds no.1 banner management system.</font></span></li></ul><span style="font-size: 10pt; font-family: ''Arial'',''sans-serif''"><font color="#000000"> </font></span> <ul style="margin-top: 0cm"><li class="MsoNormal" style="margin: 0cm 0cm 0pt; tab-stops: list 36.0pt"><font color="#000000"><strong><span style="font-size: 10pt; font-family: ''Arial'',''sans-serif''">Maximize revenue</span></strong><span style="font-size: 10pt; font-family: ''Arial'',''sans-serif''"> – Our goal is to help you earn the maximum yield for your display and registration path inventory; we do this by giving you expert tools to earn the highest payouts and effective CPMs possible.</span></font></li></ul><span style="font-size: 10pt; font-family: ''Arial'',''sans-serif''"><font color="#000000"> </font></span> <ul style="margin-top: 0cm"><li class="MsoNormal" style="margin: 0cm 0cm 0pt; tab-stops: list 36.0pt"><font color="#000000"><strong><span style="font-size: 10pt; font-family: ''Arial'',''sans-serif''">Quality Advertisers</span></strong><span style="font-size: 10pt; font-family: ''Arial'',''sans-serif''"> – We have an experienced sales advertising sales team that consistently generate high quality, top performing campaigns from well recognized brand advertisers, giving you all the benefits of an elite sales force pushing your inventory.</span></font></li></ul><span style="font-size: 10pt; font-family: ''Arial'',''sans-serif''"><font color="#000000"> </font></span><span style="font-size: 10pt; font-family: ''Arial'',''sans-serif''"><font color="#000000"> </font></span> <ul style="margin-top: 0cm"><li class="MsoNormal" style="margin: 0cm 0cm 0pt; tab-stops: list 36.0pt"><font color="#000000"><strong><span style="font-size: 10pt; font-family: ''Arial'',''sans-serif''">Market leading technology </span></strong><span style="font-size: 10pt; font-family: ''Arial'',''sans-serif''">– We use the most advanced technology to optimize and report on our campaigns to ensure you earn the highest possible revenue.</span></font></li></ul><span style="font-size: 10pt; font-family: ''Arial'',''sans-serif''"><font color="#000000"> </font></span> <ul style="margin-top: 0cm"><li class="MsoNormal" style="margin: 0cm 0cm 0pt; tab-stops: list 36.0pt"><font color="#000000"><strong><span style="font-size: 10pt; font-family: ''Arial'',''sans-serif''">Outstanding support</span></strong><span style="font-size: 10pt; font-family: ''Arial'',''sans-serif''"> – Our experienced team offers the highest level of support providing consultative services that aim to increase your earnings and overall performance in an ever evolving competitive market, that''s in addition to superior general customer service and account maintenance enquiries.</span></font></li></ul><span style="font-size: 10pt; font-family: ''Arial'',''sans-serif''"><font color="#000000"> </font></span><span style="font-size: 10pt; font-family: ''Arial'',''sans-serif''"><font color="#000000"> </font></span> <ul style="margin-top: 0cm"><li class="MsoNormal" style="margin: 0cm 0cm 0pt; tab-stops: list 36.0pt"><font color="#000000"><strong><span style="font-size: 10pt; font-family: ''Arial'',''sans-serif''">How does it work</span></strong><span style="font-size: 10pt; font-family: ''Arial'',''sans-serif''">? – Ok so you must be thinking ''Show me the money'' but how does it work? We will effectively monetize your site through our ad network platform by running ads from hundreds of quality advertisers on your website. You can expect to receive the highest Ecpm rates through a wide range of standard banners, pop-unders and rich media such as video.</span></font></li></ul><span style="font-size: 10pt; font-family: ''Arial'',''sans-serif''"><font color="#000000"> </font></span>', '', 1, 0, 0, 0, '2007-06-04 14:59:10', 62, '', '2008-11-18 10:02:43', 62, 0, '0000-00-00 00:00:00', '2007-06-04 14:59:10', '0000-00-00 00:00:00', '', '', 'show_title=1\nlink_titles=\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_vote=\nshow_author=0\nshow_create_date=0\nshow_modify_date=0\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 5, 0, 19, '', '', 0, 85, 'robots=\nauthor='),
(48, 'about us ', 'features', '', '<span style="font-size: 10pt; font-family: ''Arial'',''sans-serif''"><font color="#999999">E-Marketing is the leading ad network in the Middle East and North Africa boasting the largest reach in the Arab speaking world serving over<strong> 600 million monthly impressions</strong> and over <strong>29 million unique users</strong> bridging the gap allowing the world to communicate with this hard to reach targeted audience offering various channels which service our clients every desire.</font></span><span style="font-size: 10pt; font-family: ''Arial'',''sans-serif''"><font color="#999999"> </font></span><span style="font-size: 10pt; font-family: ''Arial'',''sans-serif''"><font color="#999999">We partner the top publishers in the region and provide advertisers with targeted ad placements. We offer site-specific, channel-wide and run of network solutions, we deliver results through expert advice, intelligent technology and experience.</font></span><span style="font-size: 10pt; font-family: ''Arial'',''sans-serif''"><font color="#999999"> </font></span><font color="#999999"><span style="font-size: 10pt; font-family: ''Arial'',''sans-serif''">Us</span><span style="font-size: 10pt; font-family: ''Arial'',''sans-serif''">ing</span><span style="font-size: 10pt; font-family: ''Arial'',''sans-serif''"> the most advanced banner management system and targeting solutions in<span>  </span>in the world (double click)</span><span style="font-size: 10pt; font-family: ''Arial'',''sans-serif''">, w</span><span style="font-size: 10pt; font-family: ''Arial'',''sans-serif''">e take care of everything and you</span><span style="font-size: 10pt; font-family: ''Arial'',''sans-serif''">,</span><span style="font-size: 10pt; font-family: ''Arial'',''sans-serif''"> from targeting and optimisation, strategy to creative, web to video</span><span style="font-size: 10pt; font-family: ''Arial'',''sans-serif''">, </span><span style="font-size: 10pt; font-family: ''Arial'',''sans-serif''">mobile to search</span><span style="font-size: 10pt; font-family: ''Arial'',''sans-serif''"> and trafficking & reporting</span><span style="font-size: 10pt; font-family: ''Arial'',''sans-serif''">.</span><span style="font-size: 10pt; font-family: ''Arial'',''sans-serif''"></span></font><span style="font-size: 10pt; font-family: ''Arial'',''sans-serif''"><font color="#999999"> </font></span><span style="font-size: 10pt; font-family: ''Arial'',''sans-serif''"><font color="#999999"> </font></span><span style="font-size: 10pt; font-family: ''Arial'',''sans-serif''"><font color="#999999"> </font></span> <p style="margin: 0cm 0cm 0pt" class="MsoNormal"><strong><span style="font-size: 10pt; font-family: ''Arial'',''sans-serif''"><font color="#999999">Vision and Values</font></span></strong></p><strong><span style="font-size: 10pt; font-family: ''Arial'',''sans-serif''"><font color="#999999"></font></span></strong> <span style="font-size: 10pt; font-family: ''Arial'',''sans-serif''"><font color="#999999">E – marketing is built on a foundation of strong core values. We believe in reaching for excellence in everything that we do. From the quality of our products and publishers to the delivery of customer service and consultancy, we constantly aim to exceed expectations. <br /><br />Since we were established 3 years ago we''ve been committed to creating long-term value for our customers, partners and employees and we believe in maintaining our pledge to an ethical and honest work environment. These values are essential to preserving the integrity on which the organization was built. We pride ourselves on always keeping our advertisers, publishers and employees best interests in mind. </font></span><span style="font-size: 10pt; font-family: ''Arial'',''sans-serif''"><font color="#999999"> </font></span><span style="font-size: 10pt; font-family: ''Arial'',''sans-serif''"><font color="#999999">We live and breathe online whilst understanding other mediums…..however the question you need to ask yourself is do you want a marketing solution that is direct, measureable, cost effective, trackable and forever evolving? If so, online is the answer.</font></span> <p><font color="#999999"><strong>History</strong></font></p>', '', 1, 0, 0, 0, '2007-06-04 14:59:48', 62, '', '2008-11-18 08:13:59', 62, 0, '0000-00-00 00:00:00', '2007-06-04 14:59:48', '0000-00-00 00:00:00', '', '', 'show_title=1\nlink_titles=\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_vote=\nshow_author=0\nshow_create_date=0\nshow_modify_date=0\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 6, 0, 20, '', '', 0, 173, 'robots=\nauthor='),
(49, 'Dummy Content', 'dummy-content', '', 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.', '', -2, 0, 0, 0, '2007-06-04 15:00:30', 62, '', '0000-00-00 00:00:00', 0, 0, '0000-00-00 00:00:00', '2007-06-04 15:00:30', '0000-00-00 00:00:00', '', '', 'pageclass_sfx=\nshow_title=1\nlink_titles=\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_vote=\nshow_author=0\nshow_create_date=0\nshow_modify_date=0\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=', 1, 0, 0, '', '', 0, 24, 'robots=\nauthor='),
(50, 'Styleswitcher', 'Features', '', '<img style="margin: 0px 0px 10px 10px" src="images/yootheme/features_styleswitcher.jpg" alt="Styleswitcher" title="Styleswitcher" width="240" height="180" align="right" />\r\nAccessibility is very important to make your website accessible for a wide range of users. The YOOtheme Styleswitcher enables your website to fit to any screen resolution and to resize the entire text. This is done by giving users ability to change font size and page width.\r\n<br />\r\n<br />\r\nThe YOOtheme Styleswitcher is a smart combination of javascript and php which delivers an advanced solution for best user experience.<div class="info" style="clear: both;">And the icing on the cake is a smooth sliding effect. Try it out now, by clicking the styleswitcher!</div>\r\n<div class="tip">Notice: it''s no problem to deactivate the Styleswitcher completely and to stay always at a fixed width. Just set the Styleswitcher in the template configuration to false and choose your default fixed width.</div>\r\nFor Example:\r\n<pre>\r\n"styleswitcherFont"   => false,           /* true | false */\r\n"styleswitcherWidth"  => false,           /* true | false */\r\n\r\n"fontDefault"         => "font-medium",   /* font-small | font-medium | font-large */\r\n"widthDefault"        => "width-wide",    /* width-thin | width-wide | width-fluid */\r\n</pre>', '', 1, 0, 0, 0, '2007-06-04 15:00:56', 62, '', '0000-00-00 00:00:00', 0, 0, '0000-00-00 00:00:00', '2007-06-04 15:00:56', '0000-00-00 00:00:00', '', '', 'pageclass_sfx=\nshow_title=1\nlink_titles=\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_vote=\nshow_author=0\nshow_create_date=0\nshow_modify_date=0\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=', 1, 0, 21, '', '', 0, 0, 'robots=\nauthor=');
INSERT INTO `jos_content` (`id`, `title`, `alias`, `title_alias`, `introtext`, `fulltext`, `state`, `sectionid`, `mask`, `catid`, `created`, `created_by`, `created_by_alias`, `modified`, `modified_by`, `checked_out`, `checked_out_time`, `publish_up`, `publish_down`, `images`, `urls`, `attribs`, `version`, `parentid`, `ordering`, `metakey`, `metadesc`, `access`, `hits`, `metadata`) VALUES
(51, 'Tableless CSS Design', 'Features', '', 'Tableless CSS design is the art of building websites without resorting to the use of tables merely for presentational purposes. Instead of tables, CSS (Cascading Style Sheets) positioning is used to arrange elements and text on a web page. This Template is build with tableless CSS design. This improves web accessibility and makes HTML code semantic. \r\n<div class="tip">For more advantages look at <a href="http://en.wikipedia.org/wiki/Web_design_(Tableless)">Wikipedia: tableless web design</a></div>\r\nOur tableless CSS design works in nearly every modern browser. Look at <a href="index.php?option=com_content&task=view&id=27&Itemid=60">Browser compatibility</a>. Also you can use any Div-Layout with float and clear inside the template.<br />\r\n<br />\r\nFor Example some left and right floating boxes:<br /><br />\r\n<div style="background: #ff8c00; float: left; width: 80px; height: 20px; color: #ffffff; text-align: center"> Box A </div>\r\n<div style="background: #646464; float: left; width: 80px; height: 20px; color: #ffffff; text-align: center"> Box B </div>\r\n<div style="background: #b40000; float: left; width: 80px; height: 20px; color: #ffffff; text-align: center"> Box C </div>\r\n<div style="background: #ff8c00; float: right; width: 80px; height: 20px; color: #ffffff; text-align: center"> Box F </div>\r\n<div style="background: #646464; float: right; width: 80px; height: 20px; color: #ffffff; text-align: center"> Box E </div>\r\n<div style="background: #b40000; float: right; width: 80px; height: 20px; color: #ffffff; text-align: center"> Box D </div>\r\n<div style="background: #323232; clear: both; width: 100%; height: 20px; color: #ffffff; text-align: center"> Clearing Box </div>\r\n<br />\r\n<br />', '', -2, 0, 0, 0, '2007-06-04 15:02:49', 62, '', '0000-00-00 00:00:00', 0, 0, '0000-00-00 00:00:00', '2007-06-04 15:02:49', '0000-00-00 00:00:00', '', '', 'pageclass_sfx=\nshow_title=1\nlink_titles=\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_vote=\nshow_author=0\nshow_create_date=0\nshow_modify_date=0\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=', 1, 0, 0, '', '', 0, 0, 'robots=\nauthor='),
(52, 'Slimbox/Lightbox', 'Features', '', '<img class="lightbox" style="margin: 0px 0px 10px 10px" src="images/yootheme/features_lightbox.jpg" alt="Test Lightbox" title="Test Lightbox" width="240" height="180" align="right" />We&rsquo;ve integrated a visual clone of the popular Lightbox JS v2.0 called <a href="http://www.digitalia.be/software/slimbox" target="_blank">Slimbox</a>. Slimbox is smaller, more efficient, more convenient and 100% compatible with the original Lightbox v2.\r\n<br /><br />\r\nLightbox allows you to show overlay popups of images on the page you are currently at instead of linking to a new window. It shows a small preloader animation before showing the full image.\r\n<br />\r\n<br />You have 2 different ways to use Slimbox/Lightbox. For demonstrating the "YOOtheme" Method, just click image to the right.\r\n<br /><br /><br />\r\n<h4>1. &quot;YOOtheme&quot; Method</h4>\r\nAdd a <em class="box">class=&quot;lightbox&quot;</em> attribute to any image tag. Our script takes care of everything and will enable the lightbox behavior. It''s a quick and simple way to add the lightbox effect to any image.<span class="alert">The related popup image filename must have the suffix _lightbox and must be in the same folder as the image.</span>\r\nFor example:\r\n<pre style="white-space:normal;">\r\n&lt;img class=&quot;lightbox&quot; title=&quot;my caption&quot; src=&quot;image.jpg&quot; width=&quot;240&quot; height=&quot;180&quot; /&gt;\r\n</pre>\r\n<em>Optional</em>: Use the title attribute if you want to show a caption.<br />\r\n<br /><br />\r\n<h4>2. &quot;traditional&quot; Method</h4>\r\nAdd a <em class="box">rel=&quot;lightbox&quot;</em> attribute to any link tag to activate the lightbox.<br />\r\n<br />\r\nFor example:<br />\r\n<pre style="white-space:normal;">\r\n&lt;a href=&quot;image.jpg&quot; rel=&quot;lightbox&quot; title=&quot;my caption&quot;&gt;image #1&lt;/a&gt;\r\n</pre>\r\n<em>Optional</em>: Use the title attribute if you want to show a caption.<br />\r\n<br />\r\nIf you have a set of related images that you would like to group, follow step one but additionally include a group name between square brackets in the rel attribute.<br />\r\n<br />\r\nFor example:<br />\r\n<pre style="white-space:normal;">\r\n&lt;a href=&quot;image-1.jpg&quot; rel=&quot;lightbox[a]&quot;&gt;image #1&lt;/a&gt;<br />\r\n&lt;a href=&quot;image-2.jpg&quot; rel=&quot;lightbox[a]&quot;&gt;image #2&lt;/a&gt;\r\n</pre>\r\n<span class="note">Try out this feature by clicking on the following links: <a href="images/yootheme/features_lightbox_lightbox.jpg" rel="lightbox" title="my caption">image #1</a> and <a href="images/yootheme/features_lightbox_lightbox.jpg" rel="lightbox[aa]">showcase with two images</a>\r\n<a href="images/yootheme/features_lightbox2_lightbox.jpg" rel="lightbox[aa]"></a></span>', '', 1, 0, 0, 0, '2007-06-04 15:03:32', 62, '', '2007-06-04 15:04:02', 62, 0, '0000-00-00 00:00:00', '2007-06-04 15:03:32', '0000-00-00 00:00:00', '', '', 'pageclass_sfx=\nshow_title=1\nlink_titles=\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_vote=\nshow_author=0\nshow_create_date=0\nshow_modify_date=0\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=', 2, 0, 15, '', '', 0, 0, 'robots=\nauthor='),
(53, 'Reflection', 'Features', '', '<p><img class="reflect float-right correct-png" src="images/yootheme/features_reflection.gif" alt="Reflection" title="Reflection" width="240" height="70" /></p>\r\nReflection allows to add fantastic reflection effects to your images in modern browsers. This template includes <a href="http://www.digitalia.be/software/reflectionjs-for-mootools" target="_blank">Reflection.js for mootools</a> which is an improved version of the original Reflection.js script. So you don''t need to spend time in an image editor creating reflections.<br />\r\n<br /><br />\r\n<h4>Usage</h4>\r\nReflections can be added to any image tag over any kind of background (even image backgrounds!). Add a <em class="box">class=&quot;reflect&quot;</em> attribute to any image tag.<br />\r\n<br />\r\nFor example:\r\n<pre style="white-space: normal;">\r\n&lt;img class=&quot;reflect&quot; title=&quot;my caption&quot; src=&quot;image.jpg&quot; width=&quot;240&quot; height=&quot;180&quot; /&gt;\r\n</pre>\r\n<br />You can apply multiple classes to an image (separated by spaces), the script will detect if “reflect” is one of them.\r\n<br /><br />\r\n<strong>CSS limitations</strong><br />\r\nWhen adding the reflection effect, the script wraps the image inside a block and adds the reflection to the same block, just below the original image. The class and style attributes of the image will be set blank and applied to the div instead, so the whole block will show like the original image.\r\n<div class="alert">This means that you can style the mirrored images using CSS classes and using their style attribute, but you can not style the img tag directly.</div>', '', 1, 0, 0, 0, '2007-06-04 15:04:05', 62, '', '0000-00-00 00:00:00', 0, 0, '0000-00-00 00:00:00', '2007-06-04 15:04:05', '0000-00-00 00:00:00', '', '', 'pageclass_sfx=\nshow_title=1\nlink_titles=\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_vote=\nshow_author=0\nshow_create_date=0\nshow_modify_date=0\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=', 1, 0, 14, '', '', 0, 0, 'robots=\nauthor='),
(54, 'YOOmenu', 'Features', '', '<img style="margin: 0px 0px 10px 10px" src="images/yootheme/features_yoomenu.jpg" alt="YOOmenu" title="YOOmenu" width="240" height="180" align="right" />\r\nAll menus shown on this page are implemented using the YOOmenu system. YOOmenu is a flexible all-in-one menu system right out of the box. It makes it possible to bring you the freshest Javascript menus and a lot of cool features. It just takes your experience to a whole new level. \r\n<br /><br />\r\nThe YOOmenu introduces to two new stunning menus to the Joomla world.\r\n<ul class="arrow">\r\n<li>Tab Menu, <a href="index.php?option=com_content&task=view&id=30&Itemid=63">learn more</a></li>\r\n<li>Drop Down Menu, <a href="index.php?option=com_content&task=view&id=40&Itemid=173">learn more</a></li>\r\n<li>Accordion Menu, <a href="index.php?option=com_content&task=view&id=34&Itemid=85">learn more</a></li>\r\n</ul>\r\nIt also comes with two really enjoyable features:\r\n<ul class="arrow">\r\n<li>Active Item Detection for various color stylings</li>\r\n<li>Background images can be set through Joomla!</li>\r\n<li>Separates one menu into different outputs</li>\r\n</ul>\r\n<br />\r\n<h5>Active Item Detection</h5>\r\nWith the Active Item Detection the template knows which menu item you are currently browsing. For example set any CSS class depending on the active/current menu item in the body tag. This makes it possible to give each page a different color styling.\r\n<br />\r\n<br />\r\nExample how the template configuration can look like:\r\n<pre>\r\n/* item color variation */\r\n"item1"               => "red",          /* red | blue | green | yellow */\r\n"item2"               => "blue",         /* red | blue | green | yellow */\r\n"item3"               => "green",        /* red | blue | green | yellow */\r\n"item4"               => "yellow",       /* red | blue | green | yellow */\r\n...\r\n</pre>\r\n<br />\r\nAnd the generated template HTML output can look like this, if you are currently in Home (item1)...\r\n<pre>&lt;body class=&quot;blue&quot;&gt;...&lt;/body&gt;\r\n</pre>\r\n<br />\r\n<br />\r\n<h5>Background Images</h5>\r\nUsing the YOOmenu system background images can be set through Joomla! with the built in Joomla! menu image parameter. Now you can set an image to each menu item in the Joomla! menu administration and it will appear as the items background image.\r\n<br />\r\n<br />\r\nFor example: Take a look at the icons (e.g. new!, web 2.0) in the sub menu or the images in Slider Menu.\r\n<div class="tip" style="clear: both;">After creating a new menu item open it again for editing. Now you can set an image to the menu item parameter in the parameters section. After saving the image will appear as background image behind the menu item.\r\n<br />\r\n<img style="margin: 10px 0px 10px 0px" src="images/yootheme/features_yoomenu_config.jpg" alt="YOOmenu Configuration" title="YOOmenu Configuration" width="490" height="140" /></div>\r\n<br />\r\n<h5>Split Menu</h5>\r\nYOOmenu enables you to separate one menu into different outputs displaying certain menu levels. Each output can be placed anywhere on your site.\r\n<div class="tip">YOOmenu uses the ''mainmenu'' by default. The Slider Menu shows the top level of the hierarchical menu structure. All sub levels of the currently selected top level item will show up in the sub menu on the left.</div>', '', 1, 0, 0, 0, '2007-06-04 15:04:41', 62, '', '2007-07-02 15:35:10', 62, 0, '0000-00-00 00:00:00', '2007-06-04 15:04:41', '0000-00-00 00:00:00', '', '', 'pageclass_sfx=\nshow_title=1\nlink_titles=\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_vote=\nshow_author=0\nshow_create_date=0\nshow_modify_date=0\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=', 2, 0, 13, '', '', 0, 0, 'robots=\nauthor='),
(55, 'PNG Fix for IE6', 'Features', '', 'This template includes the YOOtheme PNG Fix for Internet Explorer up to version 6.x because these browser versions don’t support PNG transparency natively (Internet Explorer version 7 supports PNG transparency natively). The YOOtheme PNG Fix enables PNG Alpha Transparency for inline images in the whole template just by giving them a <em class="box">class=&quot;correct-png&quot;</em> attribute. <br />\r\n<br />\r\nFor example:<br />\r\n<pre style="white-space: normal;">\r\n&lt;img class=&quot;correct-png&quot; src=&quot;image-1.jpg&quot; width=&quot;240&quot; height=&quot;180&quot; /&gt;\r\n</pre>\r\n<br />\r\n<div class="info">PNG Fix only effects png images you want and not all png images. The YOOtheme PNG Fix is only activated when needed. IE7 and all other browsers ignore the PNG Fix.</div>\r\nTake a look at the icons inside the black, red and yellow module boxes, which are images with PNG transparency. <br />\r\n<br />', '', 1, 0, 0, 0, '2007-06-04 15:05:15', 62, '', '0000-00-00 00:00:00', 0, 0, '0000-00-00 00:00:00', '2007-06-04 15:05:15', '0000-00-00 00:00:00', '', '', 'pageclass_sfx=\nshow_title=1\nlink_titles=\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_vote=\nshow_author=0\nshow_create_date=0\nshow_modify_date=0\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=', 1, 0, 5, '', '', 0, 0, 'robots=\nauthor='),
(56, 'XHTML&amp;CSS Validation', 'Features', '', '<img style="margin: 0px 0px 10px 10px" src="images/yootheme/features_validation.jpg" alt="XHTML&amp;CSS Validation" title="XHTML&amp;CSS Validation" width="240" height="180" align="right" />\r\nThis template validates to XHTML and CSS web standards.\r\n<br />\r\n<br />\r\nIn particular this template is build with <a href="index.php?option=com_content&task=view&id=19&Itemid=54">tableless CSS design</a>. This template achieves complete separation of the presentation from content and structure using nice and clean XHTML and CSS code.\r\n<br /><br />The major reason for this separation of concerns is to simplify any change from a slight design adjustment to a full-fledged redesign. Furthermore it increases the site accessibility for a wide range of user agent software and devices, like screen readers.\r\n<div class="tip" style="clear: both;">You can check the validation of this template at the world wide web consortium by clicking the icons in the footer of this template.</div><br />\r\n<br />\r\n<br />', '', 1, 0, 0, 0, '2007-06-04 15:05:40', 62, '', '0000-00-00 00:00:00', 0, 0, '0000-00-00 00:00:00', '2007-06-04 15:05:40', '0000-00-00 00:00:00', '', '', 'pageclass_sfx=\nshow_title=1\nlink_titles=\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_vote=\nshow_author=0\nshow_create_date=0\nshow_modify_date=0\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=', 1, 0, 6, '', '', 0, 0, 'robots=\nauthor='),
(57, 'Browser Compatibility', 'Features', '', 'This template is designed to be compatible with all modern browsers. So it provides the best experience to all your visitors.\r\n<br /><br />\r\n<img class="correct-png" style="margin-right: 10px" src="images/yootheme/browser_firefox.png" alt="Firefox" title="Firefox" width="48" height="48" align="left" />\r\n<img class="correct-png" style="margin-right: 10px" src="images/yootheme/browser_ie6.png" alt="Internet Explorer 6" title="Internet Explorer 6" width="48" height="48" align="left" />\r\n<img class="correct-png" style="margin-right: 10px" src="images/yootheme/browser_ie7.png" alt="Internet Explorer 7" title="Internet Explorer 7" width="48" height="48" align="left" />\r\n<img class="correct-png" style="margin-right: 10px" src="images/yootheme/browser_safari.png" alt="Safari" title="Safari" width="48" height="48" align="left" />\r\n<img class="correct-png" style="margin-right: 10px" src="images/yootheme/browser_opera.png" alt="Opera" title="Opera" width="48" height="48" align="left" />\r\n<img class="correct-png" style="margin-right: 10px" src="images/yootheme/browser_camino.png" alt="Camino" title="Camino" width="48" height="48" align="left" />\r\n<img class="correct-png" style="margin-right: 10px" src="images/yootheme/browser_konqueror.png" alt="Konqueror" title="Konqueror" width="48" height="48" align="left" />\r\n<br /><br /><br /><br /><div class="info" style="clear: both;">Fully tested in...\r\n<ul>\r\n<li>Firefox 1.0+</li>\r\n<li>Internet Explorer 6</li>\r\n<li>Internet Explorer 7</li>\r\n<li>Safari 2 .0+</li>\r\n<li>Opera 9.0+</li>\r\n<li>Camino 1.0+</li>\r\n</ul></div>', '', 1, 0, 0, 0, '2007-06-04 15:06:06', 62, '', '0000-00-00 00:00:00', 0, 0, '0000-00-00 00:00:00', '2007-06-04 15:06:06', '0000-00-00 00:00:00', '', '', 'pageclass_sfx=\nshow_title=1\nlink_titles=\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_vote=\nshow_author=0\nshow_create_date=0\nshow_modify_date=0\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=', 1, 0, 7, '', '', 0, 0, 'robots=\nauthor='),
(58, 'Demo Content', 'Features', '', 'In addition to this template you can download the complete demo content which contains all content from this demo site you see right now. It consists of the database backup as text file and all images used on this site.<div class="download">Database backup and all images downloadable as zip file.</div>So you can set up the whole demo site on your own private webserver. This allows you to check all the backend administration settings and gives you a good start, how to use this template...<div class="alert">Re-use of any graphics, icons or photos from the demo content for any purpose is strictly prohibited. The demo content is only for demonstration use.</div><br />', '', 1, 0, 0, 0, '2007-06-04 15:06:51', 62, '', '0000-00-00 00:00:00', 0, 0, '0000-00-00 00:00:00', '2007-06-04 15:06:51', '0000-00-00 00:00:00', '', '', 'pageclass_sfx=\nshow_title=1\nlink_titles=\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_vote=\nshow_author=0\nshow_create_date=0\nshow_modify_date=0\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=', 1, 0, 8, '', '', 0, 0, 'robots=\nauthor='),
(59, 'Fancy Menu', 'Features', '', '<img style="margin: 0px 0px 10px 10px" src="images/yootheme/features_fancymenu.jpg" alt="Fancy Menu" title="Fancy Menu" width="240" height="180" align="right" />YOOtheme introduces again a new menu to the Joomla! world: The Fancy Menu! \r\n<br />\r\n<br />\r\nThe <a href="http://devthought.com/cssjavascript-true-power-fancy-menu/" target="_blank">Fancy Menu</a> is used in the horizontal top navigation. The catch is a movable slider element in the background. The Fancy Menu is completely and automatically generated from the basic Joomla! menu. Based on the Mootools library it''s size is only 1.5 KB. And of course it is also cross browser and accessible!\r\n<br />\r\n<br />\r\nFor example take a look at the top navigation and hover the menu items with your mouse.', '', 1, 0, 0, 0, '2007-06-04 15:07:20', 62, '', '2007-08-02 19:27:22', 62, 0, '0000-00-00 00:00:00', '2007-06-04 15:07:20', '0000-00-00 00:00:00', '', '', 'pageclass_sfx=\nshow_title=1\nlink_titles=\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_vote=\nshow_author=0\nshow_create_date=0\nshow_modify_date=0\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=', 2, 0, 9, '', '', 0, 4, 'robots=\nauthor='),
(65, 'YOOslider', 'yooslider', '', 'YOOtheme proudly presents the new YOOslider module!\r\n<br />\r\n<br />\r\nThe exclusive YOOslider module can be vertical or horizontal aligned and comes with smooth sliding effects while hovering the items. It also features two sliding behaviors to get different sliding effects. \r\n<br />\r\n<br />\r\n<h5>The Drawer</h5>\r\n<ul>\r\n	<li>Method: Overlapping with z-index</li>\r\n	<li>Item remains expanded and active on mouse leave</li>\r\n	<li>Example: take a look at the right and hover each item</li>\r\n</ul>\r\n<h5>The Slider</h5>\r\n<ul>\r\n	<li>Method: Scaling width using "overflow: hidden"</li>\r\n	<li>Shrink the item on mouse leave</li>\r\n	<li>Example: take a look <a href="index.php?option=com_content&task=view&id=17&Itemid=33">here</a> and hover each item</li>\r\n</ul>\r\n<br />\r\n<h3>Configuration of the YOOslider</h3>\r\nThe YOOslider comes with an huge configuration to make it as flexible as possible and to fit all purposes.\r\n<br /><br />\r\nFor example goto the Joomla! backend, install the YOOslider module and edit the module settings.\r\n<div class="tip" style="clear: both;">Choose a category to set the content items which should be loaded in the YOOslider.\r\n<br style="clear: both;"/>\r\n<img style="margin: 10px 0px 10px 0px" src="images/yootheme/features_yooslider_config.jpg" alt="YOOslider configuration" title="YOOslider configuration" width="450" height="300" />\r\n<br style="clear: both;"/>\r\nEnjoy!\r\n</div>', '', 1, 0, 0, 0, '2007-08-02 19:28:35', 62, '', '2007-08-02 19:29:33', 62, 0, '0000-00-00 00:00:00', '2007-08-02 19:28:35', '0000-00-00 00:00:00', '', '', 'pageclass_sfx=\nshow_title=1\nlink_titles=\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_vote=\nshow_author=0\nshow_create_date=0\nshow_modify_date=0\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=', 3, 0, 4, '', '', 0, 2, 'robots=\nauthor='),
(61, 'Accordion Menu', 'Features', '', '<img style="margin: 0px 0px 10px 10px" src="images/yootheme/features_accordionmenu.jpg" alt="Accordion Menu" title="Accordion Menu" width="240" height="180" align="right" />This template takes advantage of the exclusive YOOtheme Accordion Menu for the sub level navigation. The Accordion Menu uses <a href="http://www.mootools.net" target="_blank">mootools</a> for the transition effect with smooth animation and color fading.\r\n<br />\r\n<br />\r\nFor example take a look at the left/right and click on the arrows in the submenu to open the next menu level.\r\n<br />\r\n<br style="clear: both;"/>\r\nTo setup the Accordion Menu do the following.\r\n<div class="tip" style="clear: both;">Create a new menu item for level 2 (this means a new item for the sub menu). Choose under "Miscellaneous" the "Separator/Placeholder" option.\r\n<br style="clear: both;"/>\r\n<img style="margin: 10px 0px 10px 0px" src="images/yootheme/features_accordionmenu_config1.jpg" alt="Accordion Menu Setup" title="Accordion Menu Setup" width="480" height="150" />\r\n<br style="clear: both;"/>\r\nNext create new menu items in level 3 (this means the sub level of the new "Separator/Placeholder"). For example take a look.\r\n<br style="clear: both;"/>\r\n<img style="margin: 10px 0px 10px 0px" src="images/yootheme/features_accordionmenu_config2.jpg" alt="Accordion Menu Setup" title="Accordion Menu Setup" width="320" height="280" />\r\n</div>', '', 1, 0, 0, 0, '2007-06-04 15:08:16', 62, '', '0000-00-00 00:00:00', 0, 0, '0000-00-00 00:00:00', '2007-06-04 15:08:16', '0000-00-00 00:00:00', '', '', 'pageclass_sfx=\nshow_title=1\nlink_titles=\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_vote=\nshow_author=0\nshow_create_date=0\nshow_modify_date=0\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=', 1, 0, 10, '', '', 0, 2, 'robots=\nauthor='),
(62, 'YOOlogin', 'Features', '', 'With the YOOlogin module you get a enhanced version of the default Joomla! login module. We took the liberty to get rid of the tables used in the Joomla! login module to provide you a clean design. The YOOlogin module now fits well in our professional template layouts.\r\n<div class="info">Also we have integrated some additional features. Check out the module parameters in your Joomla! backend.</div>\r\n<br />\r\n<strong>To setup the YOOlogin module follow these instructions:</strong>\r\n<ul>\r\n<li>Download the YOOlogin module from the template download section</li>\r\n<li>Go to the Joomla! backend and install the YOOlogin module</li>\r\n<li>Publish the YOOlogin module in module position "header"</li>\r\n</ul>', '', 1, 0, 0, 0, '2007-06-04 15:08:47', 62, '', '0000-00-00 00:00:00', 0, 0, '0000-00-00 00:00:00', '2007-06-04 15:08:47', '0000-00-00 00:00:00', '', '', 'pageclass_sfx=\nshow_title=1\nlink_titles=\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_vote=\nshow_author=0\nshow_create_date=0\nshow_modify_date=0\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=', 1, 0, 11, '', '', 0, 2, 'robots=\nauthor='),
(63, 'Sliced Image Sources', 'Features', '', 'Launch up your Adobe Fireworks and open the fully sliced image source files to get started with some serious customizations! Does some color doesn''t match your current taste? Or do you need to match the templates design closer to your clients corporate identity? No problem, start modifying the included image source file to suit your needs.\r\n<div class="download">Adobe Fireworks .png file downloadable as zip file.</div>', '', 1, 0, 0, 0, '2007-06-04 15:09:16', 62, '', '2007-08-02 18:19:54', 62, 0, '0000-00-00 00:00:00', '2007-06-04 15:09:16', '0000-00-00 00:00:00', '', '', 'pageclass_sfx=\nshow_title=1\nlink_titles=\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_vote=\nshow_author=0\nshow_create_date=0\nshow_modify_date=0\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=', 2, 0, 12, '', '', 0, 2, 'robots=\nauthor='),
(66, 'Featured Advertiser', 'yooslider', '', '<div align="center" style="margin: 0px 10px"><a href="index.php?option=com_content&task=view&id=41&Itemid=178"><strong><font color="#ff0000"> </font></strong></a><strong><font color="#ff0000"> </font></strong></div><div align="center" style="margin: 0px 10px"><strong><font color="#000000">Featured Advertiser</font></strong></div><h1 style="margin: 0px 10px" align="center"><a href="index.php?option=com_content&task=view&id=41&Itemid=178"></a></h1><div align="center" style="margin: 0px 10px"> <img src="images/stories/p.png" border="0" /></div><a href="index.php?option=com_content&task=view&id=41&Itemid=178"></a><div align="center" style="margin: 0px 10px">pepsi leading company in world advertiseed aboutpepsi leading company in world advertiseed about    <br /><a href="index.php?option=com_content&task=view&id=41&Itemid=178">see more...</a> </div>', '', 1, 5, 0, 33, '2007-08-03 13:23:04', 62, '', '2008-11-18 10:27:48', 62, 0, '0000-00-00 00:00:00', '2007-08-03 13:23:04', '0000-00-00 00:00:00', '', '', 'show_title=1\nlink_titles=\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 13, 0, 1, '', '', 0, 0, 'robots=\nauthor='),
(67, 'Featured Channels ', 'why-emarketing', '', '<p><a href="index.php?option=com_content&task=view&id=17&Itemid=33"></a></p><p align="center"><font color="#000000"></font></p><p align="center"><font color="#000000"><strong>Featured</strong><strong> Channels</strong> </font></p><p style="margin: auto 0cm" align="center"><span> <a href="index.php?option=com_content&task=view&id=17&Itemid=33"><strong><img src="images/stories/aljamila.com.png" border="0" /></strong></a></span></p><p style="margin: auto 0cm" align="center"><span>aljameelah one of our best network in the arab worldnetwork in the arab world  </span></p><div align="center" style="margin: 0px 10px">Learn more... </div>', '', 1, 5, 0, 33, '2007-08-03 13:23:33', 62, '', '2008-11-18 10:46:27', 62, 0, '0000-00-00 00:00:00', '2007-08-03 13:23:33', '0000-00-00 00:00:00', '', '', 'show_title=1\nlink_titles=\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 5, 0, 2, '', '', 0, 0, 'robots=\nauthor='),
(68, 'Testominol', 'yootheme', '', '<a href="http://www.yootheme.com"></a><p align="center"><strong>Testominol</strong></p><p align="center"><strong><font face="Helvetica" color="#135cae"><a href="http://www.yootheme.com"><img src="images/stories/testem.png" border="0" /></a></font></strong></p><div align="center" style="margin: 0px 10px">oh how much emarketing is real adventure oh how much emarketing is real adventure</div><div align="center" style="margin: 0px 10px">Learn more... </div>', '', 1, 5, 0, 33, '2007-08-03 13:23:52', 62, '', '2008-11-18 11:05:18', 62, 0, '0000-00-00 00:00:00', '2007-08-03 13:23:52', '0000-00-00 00:00:00', '', '', 'show_title=1\nlink_titles=\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 3, 0, 3, '', '', 0, 0, 'robots=\nauthor='),
(69, 'Sign up', 'sign-up', '', '<div style="margin: 0px 10px 0px 10px;">\r\n	<center><a href="http://www.yootheme.com/signup.html">\r\n		<img class="correct-png" style="margin: 20px 0px 5px 0px;" width="150" height="110" title="Sign up" alt="Sign up" src="images/yootheme/yooslider/signup.png"/>\r\n	</a></center>\r\n	<h3>Sign up</h3>\r\n	Web 2.0 for your site?\r\n	<br/>Kick your design from 1999!\r\n	<br /><a href="http://www.yootheme.com/signup.html">Join today...</a>\r\n</div>', '', 1, 5, 0, 33, '2007-08-03 13:24:05', 62, '', '2007-08-03 13:24:19', 62, 0, '0000-00-00 00:00:00', '2007-08-03 13:24:05', '0000-00-00 00:00:00', '', '', 'pageclass_sfx=\nshow_title=1\nlink_titles=\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=', 2, 0, 4, '', '', 0, 0, 'robots=\nauthor='),
(70, 'YOOslider', 'yooslider', '', '<div class="floatbox" style="width: 313px;">\r\n	<div class="float-left" style="width: 172px; height: 150px;">\r\n		<center><a href="index.php?option=com_content&amp;task=view&amp;id=41&amp;Itemid=178">\r\n			<img class="correct-png" style="margin: 20px 0px 0px 0px;" width="150" height="110" title="New! YOOslider" alt="New! YOOslider" src="images/yootheme/yooslider/yooslider.png"/>\r\n		</a></center>\r\n	</div>\r\n	<div class="float-left" style="width: 141px; height: 100px; padding: 50px 0px 0px 0px;">\r\n		<h3>New! YOOslider</h3>\r\n		Keep playing with the new\r\n		<br />YOOslider module.\r\n		<br /><a href="index.php?option=com_content&amp;task=view&amp;id=41&amp;Itemid=178">Learn more...</a>\r\n	</div>\r\n</div>', '', 1, 5, 0, 34, '2007-08-03 13:24:25', 62, '', '0000-00-00 00:00:00', 0, 0, '0000-00-00 00:00:00', '2007-08-03 13:24:25', '0000-00-00 00:00:00', '', '', 'pageclass_sfx=\nshow_title=1\nlink_titles=\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=', 1, 0, 1, '', '', 0, 1, 'robots=\nauthor='),
(71, 'why', 'latest-gadgets', '', '<p><strong><font color="#999999">Featured Channels</font></strong></p><p> <img src="images/stories/aljamila.com.png" border="0" /></p><div class="floatbox" style="width: 313px"><div class="float-left" style="width: 172px; height: 150px"><div class="float-left" style="padding-right: 0px; padding-left: 0px; padding-bottom: 0px; width: 141px; padding-top: 50px; height: 116px">aljameelah one of our famous network in the arab world famous network in the arab world <br /><a href="index.php?option=com_content&task=view&id=17&Itemid=33">Learn more...</a> </div><a href="index.php?option=com_content&task=view&id=17&Itemid=33"> </a></div></div>', '', 1, 5, 0, 34, '2007-08-03 13:24:43', 62, '', '2008-11-18 10:38:22', 62, 0, '0000-00-00 00:00:00', '2007-08-03 13:24:43', '0000-00-00 00:00:00', '', '', 'show_title=1\nlink_titles=\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 3, 0, 2, '', '', 0, 0, 'robots=\nauthor='),
(72, 'YOOtheme', 'yootheme', '', '<div class="floatbox" style="width: 313px;">\r\n	<div class="float-left" style="width: 172px; height: 150px;">\r\n		<center><a href="http://www.yootheme.com">\r\n			<img class="correct-png" style="margin: 10px 0px 15px 0px;" width="150" height="110" title="YOOtheme" alt="YOOtheme" src="images/yootheme/yooslider/yootheme.png"/>\r\n		</a></center>\r\n	</div>\r\n	<div class="float-left" style="width: 141px; height: 100px; padding: 50px 0px 0px 0px;">\r\n		<h3>YOOtheme</h3>\r\n		Professional Web 2.0\r\n		<br/>Joomla! template club.\r\n		<br /><a href="http://www.yootheme.com/">Learn more...</a>\r\n	</div>\r\n</div>', '', 1, 5, 0, 34, '2007-08-03 13:25:04', 62, '', '0000-00-00 00:00:00', 0, 0, '0000-00-00 00:00:00', '2007-08-03 13:25:04', '0000-00-00 00:00:00', '', '', 'pageclass_sfx=\nshow_title=1\nlink_titles=\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=', 1, 0, 3, '', '', 0, 0, 'robots=\nauthor='),
(73, 'Sign up', 'sign-up', '', '<div class="floatbox" style="width: 313px;">\r\n	<div class="float-left" style="width: 172px; height: 150px;">\r\n		<center><a href="http://www.yootheme.com/signup.html">\r\n			<img class="correct-png" style="margin: 10px 0px 15px 0px;" width="150" height="110" title="Sign up" alt="Sign up" src="images/yootheme/yooslider/signup.png"/>\r\n		</a></center>\r\n	</div>\r\n	<div class="float-left" style="width: 141px; height: 100px; padding: 50px 0px 0px 0px;">\r\n		<h3>Sign up</h3>\r\n		Web 2.0 for your site?\r\n		<br/>Kick your design from 1999!\r\n		<br /><a href="http://www.yootheme.com/signup.html">Join today...</a>\r\n	</div>\r\n</div>', '', 1, 5, 0, 34, '2007-08-03 13:25:15', 62, '', '0000-00-00 00:00:00', 0, 0, '0000-00-00 00:00:00', '2007-08-03 13:25:15', '0000-00-00 00:00:00', '', '', 'pageclass_sfx=\nshow_title=1\nlink_titles=\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=', 1, 0, 4, '', '', 0, 2, 'robots=\nauthor='),
(74, 'about us ', 'about-us-', '', '<span style="font-size: 10pt; font-family: ''Arial'',''sans-serif''"><font color="#999999">E-Marketing is the leading ad network in the Middle East and North Africa boasting the largest reach in the Arab speaking world serving over<strong> 600 million monthly impressions</strong> and over <strong>29 million unique users</strong> bridging the gap allowing the world to communicate with this hard to reach targeted audience offering various channels which service our clients every desire.</font></span><span style="font-size: 10pt; font-family: ''Arial'',''sans-serif''"><font color="#999999"> </font></span><span style="font-size: 10pt; font-family: ''Arial'',''sans-serif''"><font color="#999999">We partner the top publishers in the region and provide advertisers with targeted ad placements. We offer site-specific, channel-wide and run of network solutions, we deliver results through expert advice, intelligent technology and experience.</font></span><span style="font-size: 10pt; font-family: ''Arial'',''sans-serif''"><font color="#999999"> </font></span><font color="#999999"><span style="font-size: 10pt; font-family: ''Arial'',''sans-serif''">Us</span><span style="font-size: 10pt; font-family: ''Arial'',''sans-serif''">ing</span><span style="font-size: 10pt; font-family: ''Arial'',''sans-serif''"> the most advanced banner management system and targeting solutions in<span>  </span>in the world (double click)</span><span style="font-size: 10pt; font-family: ''Arial'',''sans-serif''">, w</span><span style="font-size: 10pt; font-family: ''Arial'',''sans-serif''">e take care of everything and you</span><span style="font-size: 10pt; font-family: ''Arial'',''sans-serif''">,</span><span style="font-size: 10pt; font-family: ''Arial'',''sans-serif''"> from targeting and optimisation, strategy to creative, web to video</span><span style="font-size: 10pt; font-family: ''Arial'',''sans-serif''">, </span><span style="font-size: 10pt; font-family: ''Arial'',''sans-serif''">mobile to search</span><span style="font-size: 10pt; font-family: ''Arial'',''sans-serif''"> and trafficking & reporting</span><span style="font-size: 10pt; font-family: ''Arial'',''sans-serif''">.</span></font><span style="font-size: 10pt; font-family: ''Arial'',''sans-serif''"></span>', '', 1, 0, 0, 0, '2008-11-18 08:03:21', 62, '', '0000-00-00 00:00:00', 0, 0, '0000-00-00 00:00:00', '2008-11-18 08:03:21', '0000-00-00 00:00:00', '', '', 'show_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 1, 0, 3, '', '', 0, 4, 'robots=\nauthor='),
(75, 'Vision and Values', 'vision-and-objectives', '', '<strong><span style="font-size: 10pt; font-family: ''Arial'',''sans-serif''"><font color="#999999"></font></span></strong> <span style="font-size: 10pt; font-family: ''Arial'',''sans-serif''"><font color="#999999">E – marketing is built on a foundation of strong core values. We believe in reaching for excellence in everything that we do. From the quality of our products and publishers to the delivery of customer service and consultancy, we constantly aim to exceed expectations. <br /><br />Since we were established 3 years ago we''ve been committed to creating long-term value for our customers, partners and employees and we believe in maintaining our pledge to an ethical and honest work environment. These values are essential to preserving the integrity on which the organization was built. We pride ourselves on always keeping our advertisers, publishers and employees best interests in mind. </font></span><span style="font-size: 10pt; font-family: ''Arial'',''sans-serif''"><font color="#999999"> </font></span><span style="font-size: 10pt; font-family: ''Arial'',''sans-serif''"><font color="#999999">We live and breathe online whilst understanding other mediums…..however the question you need to ask yourself is do you want a marketing solution that is direct, measureable, cost effective, trackable and forever evolving? If so, online is the answer.</font></span>', '', 1, 0, 0, 0, '2008-11-18 08:05:54', 62, '', '0000-00-00 00:00:00', 0, 0, '0000-00-00 00:00:00', '2008-11-18 08:05:54', '0000-00-00 00:00:00', '', '', 'show_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 1, 0, 2, '', '', 0, 1, 'robots=\nauthor='),
(76, 'History', 'history', '', 'later', '', 1, 0, 0, 0, '2008-11-18 08:07:31', 62, '', '0000-00-00 00:00:00', 0, 0, '0000-00-00 00:00:00', '2008-11-18 08:07:31', '0000-00-00 00:00:00', '', '', 'show_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 1, 0, 1, '', '', 0, 0, 'robots=\nauthor=');

-- --------------------------------------------------------

--
-- Table structure for table `jos_content_frontpage`
--

CREATE TABLE IF NOT EXISTS `jos_content_frontpage` (
  `content_id` int(11) NOT NULL default '0',
  `ordering` int(11) NOT NULL default '0',
  PRIMARY KEY  (`content_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `jos_content_frontpage`
--

INSERT INTO `jos_content_frontpage` (`content_id`, `ordering`) VALUES
(6, 2),
(14, 4),
(7, 3),
(1, 1),
(16, 5);

-- --------------------------------------------------------

--
-- Table structure for table `jos_content_rating`
--

CREATE TABLE IF NOT EXISTS `jos_content_rating` (
  `content_id` int(11) NOT NULL default '0',
  `rating_sum` int(11) unsigned NOT NULL default '0',
  `rating_count` int(11) unsigned NOT NULL default '0',
  `lastip` varchar(150) NOT NULL default '',
  PRIMARY KEY  (`content_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `jos_content_rating`
--


-- --------------------------------------------------------

--
-- Table structure for table `jos_core_acl_aro`
--

CREATE TABLE IF NOT EXISTS `jos_core_acl_aro` (
  `id` int(11) NOT NULL auto_increment,
  `section_value` varchar(240) NOT NULL default '0',
  `value` varchar(240) NOT NULL default '',
  `order_value` int(11) NOT NULL default '0',
  `name` varchar(255) NOT NULL default '',
  `hidden` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `__section_value_value_aro` (`section_value`(100),`value`(100)),
  KEY `jos_gacl_hidden_aro` (`hidden`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `jos_core_acl_aro`
--

INSERT INTO `jos_core_acl_aro` (`id`, `section_value`, `value`, `order_value`, `name`, `hidden`) VALUES
(10, 'users', '62', 0, 'Administrator', 0);

-- --------------------------------------------------------

--
-- Table structure for table `jos_core_acl_aro_groups`
--

CREATE TABLE IF NOT EXISTS `jos_core_acl_aro_groups` (
  `id` int(11) NOT NULL auto_increment,
  `parent_id` int(11) NOT NULL default '0',
  `name` varchar(255) NOT NULL default '',
  `lft` int(11) NOT NULL default '0',
  `rgt` int(11) NOT NULL default '0',
  `value` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`id`),
  KEY `jos_gacl_parent_id_aro_groups` (`parent_id`),
  KEY `jos_gacl_lft_rgt_aro_groups` (`lft`,`rgt`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=31 ;

--
-- Dumping data for table `jos_core_acl_aro_groups`
--

INSERT INTO `jos_core_acl_aro_groups` (`id`, `parent_id`, `name`, `lft`, `rgt`, `value`) VALUES
(17, 0, 'ROOT', 1, 22, 'ROOT'),
(28, 17, 'USERS', 2, 21, 'USERS'),
(29, 28, 'Public Frontend', 3, 12, 'Public Frontend'),
(18, 29, 'Registered', 4, 11, 'Registered'),
(19, 18, 'Author', 5, 10, 'Author'),
(20, 19, 'Editor', 6, 9, 'Editor'),
(21, 20, 'Publisher', 7, 8, 'Publisher'),
(30, 28, 'Public Backend', 13, 20, 'Public Backend'),
(23, 30, 'Manager', 14, 19, 'Manager'),
(24, 23, 'Administrator', 15, 18, 'Administrator'),
(25, 24, 'Super Administrator', 16, 17, 'Super Administrator');

-- --------------------------------------------------------

--
-- Table structure for table `jos_core_acl_aro_sections`
--

CREATE TABLE IF NOT EXISTS `jos_core_acl_aro_sections` (
  `section_id` int(11) NOT NULL auto_increment,
  `value` varchar(230) NOT NULL default '',
  `order_value` int(11) NOT NULL default '0',
  `name` varchar(230) NOT NULL default '',
  `hidden` int(11) NOT NULL default '0',
  PRIMARY KEY  (`section_id`),
  UNIQUE KEY `value_aro_sections` (`value`),
  UNIQUE KEY `jos_gacl_value_aro_sections` (`value`),
  KEY `hidden_aro_sections` (`hidden`),
  KEY `jos_gacl_hidden_aro_sections` (`hidden`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `jos_core_acl_aro_sections`
--

INSERT INTO `jos_core_acl_aro_sections` (`section_id`, `value`, `order_value`, `name`, `hidden`) VALUES
(10, 'users', 1, 'Users', 0);

-- --------------------------------------------------------

--
-- Table structure for table `jos_core_acl_groups_aro_map`
--

CREATE TABLE IF NOT EXISTS `jos_core_acl_groups_aro_map` (
  `group_id` int(11) NOT NULL default '0',
  `section_value` varchar(240) NOT NULL default '',
  `aro_id` int(11) NOT NULL default '0',
  UNIQUE KEY `group_id_aro_id_groups_aro_map` (`group_id`,`section_value`,`aro_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `jos_core_acl_groups_aro_map`
--

INSERT INTO `jos_core_acl_groups_aro_map` (`group_id`, `section_value`, `aro_id`) VALUES
(25, '', 10);

-- --------------------------------------------------------

--
-- Table structure for table `jos_core_log_items`
--

CREATE TABLE IF NOT EXISTS `jos_core_log_items` (
  `time_stamp` date NOT NULL default '0000-00-00',
  `item_table` varchar(50) NOT NULL default '',
  `item_id` int(11) unsigned NOT NULL default '0',
  `hits` int(11) unsigned NOT NULL default '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `jos_core_log_items`
--


-- --------------------------------------------------------

--
-- Table structure for table `jos_core_log_searches`
--

CREATE TABLE IF NOT EXISTS `jos_core_log_searches` (
  `search_term` text NOT NULL,
  `hits` int(11) unsigned NOT NULL default '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `jos_core_log_searches`
--


-- --------------------------------------------------------

--
-- Table structure for table `jos_groups`
--

CREATE TABLE IF NOT EXISTS `jos_groups` (
  `id` tinyint(3) unsigned NOT NULL default '0',
  `name` varchar(150) NOT NULL default '',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `jos_groups`
--

INSERT INTO `jos_groups` (`id`, `name`) VALUES
(0, 'Public'),
(1, 'Registered'),
(2, 'Special');

-- --------------------------------------------------------

--
-- Table structure for table `jos_menu`
--

CREATE TABLE IF NOT EXISTS `jos_menu` (
  `id` int(11) NOT NULL auto_increment,
  `menutype` varchar(225) default NULL,
  `name` text,
  `alias` varchar(255) NOT NULL default '',
  `link` text,
  `type` varchar(150) NOT NULL default '',
  `published` tinyint(1) NOT NULL default '0',
  `parent` int(11) unsigned NOT NULL default '0',
  `componentid` int(11) unsigned NOT NULL default '0',
  `sublevel` int(11) default '0',
  `ordering` int(11) default '0',
  `checked_out` int(11) unsigned NOT NULL default '0',
  `checked_out_time` datetime NOT NULL default '0000-00-00 00:00:00',
  `pollid` int(11) NOT NULL default '0',
  `browserNav` tinyint(4) default '0',
  `access` tinyint(3) unsigned NOT NULL default '0',
  `utaccess` tinyint(3) unsigned NOT NULL default '0',
  `params` text NOT NULL,
  `lft` int(11) unsigned NOT NULL default '0',
  `rgt` int(11) unsigned NOT NULL default '0',
  `home` int(1) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `componentid` (`componentid`,`menutype`,`published`,`access`),
  KEY `menutype` (`menutype`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=157 ;

--
-- Dumping data for table `jos_menu`
--

INSERT INTO `jos_menu` (`id`, `menutype`, `name`, `alias`, `link`, `type`, `published`, `parent`, `componentid`, `sublevel`, `ordering`, `checked_out`, `checked_out_time`, `pollid`, `browserNav`, `access`, `utaccess`, `params`, `lft`, `rgt`, `home`) VALUES
(1, 'mainmenu', 'Channels', 'joomla', 'index.php?option=com_content&view=category&id=27', 'component', 1, 0, 20, 0, 9, 0, '0000-00-00 00:00:00', 0, 0, 0, 3, 'display_num=10\nshow_headings=1\nshow_date=0\ndate_format=\nfilter=1\nfilter_type=title\norderby_sec=\nshow_pagination=0\nshow_pagination_limit=1\nshow_feed_link=1\nshow_noauth=0\nshow_title=1\nlink_titles=0\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_author=1\nshow_create_date=1\nshow_modify_date=1\nshow_item_navigation=0\nshow_readmore=1\nshow_vote=0\nshow_icons=1\nshow_pdf_icon=1\nshow_print_icon=1\nshow_email_icon=1\nshow_hits=1\nfeed_summary=\npage_title=Welcome to the Frontpage\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(2, 'mainmenu', 'Joomla! License', 'joomla-license', 'index.php?option=com_content&view=article&id=5', 'component', 1, 1, 20, 1, 3, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'pageclass_sfx=\nmenu_image=-1\nsecure=0\nshow_noauth=0\nshow_title=1\nlink_titles=0\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_author=1\nshow_create_date=1\nshow_modify_date=1\nshow_item_navigation=0\nshow_readmore=1\nshow_vote=0\nshow_icons=1\nshow_pdf_icon=1\nshow_print_icon=1\nshow_email_icon=1\nshow_hits=1\n\n', 0, 0, 0),
(41, 'mainmenu', 'FAQ', 'faq', 'index.php?option=com_content&view=section&id=3', 'component', 1, 0, 20, 0, 10, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'show_description=0\nshow_description_image=0\nshow_categories=1\nshow_empty_categories=0\nshow_cat_num_articles=1\nshow_category_description=1\norderby=\norderby_sec=\nshow_feed_link=1\nshow_noauth=0\nshow_title=1\nlink_titles=0\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_author=1\nshow_create_date=1\nshow_modify_date=1\nshow_item_navigation=0\nshow_readmore=1\nshow_vote=0\nshow_icons=1\nshow_pdf_icon=1\nshow_print_icon=1\nshow_email_icon=1\nshow_hits=1\nfeed_summary=\npage_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(11, 'othermenu', 'About us', 'about-us', 'index.php?option=com_content&view=article&id=48&Itemid=51', 'url', 1, 0, 0, 0, 8, 0, '0000-00-00 00:00:00', 0, 0, 0, 3, 'menu_image=-1\n\n', 0, 0, 0),
(12, 'othermenu', 'Advertisers', 'advertisers', '', 'separator', 1, 0, 0, 0, 9, 0, '0000-00-00 00:00:00', 0, 0, 0, 3, 'menu_image=-1\n\n', 0, 0, 0),
(13, 'othermenu', 'Publishers', 'publishers', 'http://help.joomla.org', 'url', 1, 0, 0, 0, 10, 0, '0000-00-00 00:00:00', 0, 0, 0, 3, 'menu_image=-1\n\n', 0, 0, 0),
(14, 'othermenu', 'Channels', 'channels', 'http://www.opensourcematters.org', 'url', 1, 0, 0, 0, 11, 0, '0000-00-00 00:00:00', 0, 0, 0, 4, 'menu_image=-1\n\n', 0, 0, 0),
(15, 'othermenu', 'Search Engine Marketing', 'search-engine-marketing', '', 'separator', 1, 0, 0, 0, 12, 0, '0000-00-00 00:00:00', 0, 0, 0, 3, 'menu_image=-1\n\n', 0, 0, 0),
(18, 'topmenu', 'News', 'news', 'index.php?option=com_newsfeeds&view=newsfeed&id=1&feedid=1', 'component', 1, 0, 11, 0, 3, 0, '0000-00-00 00:00:00', 0, 0, 0, 3, 'show_page_title=1\npage_title=News\npageclass_sfx=\nmenu_image=-1\nsecure=0\nshow_headings=1\nshow_name=1\nshow_articles=1\nshow_link=1\nshow_other_cats=1\nshow_cat_description=1\nshow_cat_items=1\nshow_feed_image=1\nshow_feed_description=1\nshow_item_description=1\nfeed_word_count=0\n\n', 0, 0, 0),
(20, 'usermenu', 'Your Details', 'your-details', 'index.php?option=com_user&view=user&task=edit', 'component', 1, 0, 14, 0, 1, 0, '0000-00-00 00:00:00', 0, 0, 1, 3, '', 0, 0, 0),
(24, 'usermenu', 'Logout', 'logout', 'index.php?option=com_user&view=login', 'component', 1, 0, 14, 0, 2, 0, '0000-00-00 00:00:00', 0, 0, 1, 3, '', 0, 0, 0),
(38, 'keyconcepts', 'Content Layouts', 'content-layouts', 'index.php?option=com_content&view=article&id=24', 'component', 1, 0, 20, 0, 2, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'pageclass_sfx=\nmenu_image=-1\nsecure=0\nshow_noauth=0\nlink_titles=0\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_author=1\nshow_create_date=1\nshow_modify_date=1\nshow_item_navigation=0\nshow_readmore=1\nshow_vote=0\nshow_icons=1\nshow_pdf_icon=1\nshow_print_icon=1\nshow_email_icon=1\nshow_hits=1\n\n', 0, 0, 0),
(27, 'mainmenu', 'Joomla! Overview', 'joomla-overview', 'index.php?option=com_content&view=article&id=19', 'component', 1, 1, 20, 1, 1, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'pageclass_sfx=\nmenu_image=-1\nsecure=0\nshow_noauth=0\nshow_title=1\nlink_titles=0\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_author=1\nshow_create_date=1\nshow_modify_date=1\nshow_item_navigation=0\nshow_readmore=1\nshow_vote=0\nshow_icons=1\nshow_pdf_icon=1\nshow_print_icon=1\nshow_email_icon=1\nshow_hits=1\n\n', 0, 0, 0),
(28, 'topmenu', 'About Joomla!', 'about-joomla', 'index.php?option=com_content&view=article&id=25', 'component', 1, 0, 20, 0, 1, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'pageclass_sfx=\nmenu_image=-1\nsecure=0\nshow_noauth=0\nlink_titles=0\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_author=1\nshow_create_date=1\nshow_modify_date=1\nshow_item_navigation=0\nshow_readmore=1\nshow_vote=0\nshow_icons=1\nshow_pdf_icon=1\nshow_print_icon=1\nshow_email_icon=1\nshow_hits=1\n\n', 0, 0, 0),
(29, 'topmenu', 'Features', 'features', 'index.php?option=com_content&view=article&id=22', 'component', 1, 0, 20, 0, 2, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'pageclass_sfx=\nmenu_image=-1\nsecure=0\nshow_noauth=0\nlink_titles=0\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_author=1\nshow_create_date=1\nshow_modify_date=1\nshow_item_navigation=0\nshow_readmore=1\nshow_vote=0\nshow_icons=1\nshow_pdf_icon=1\nshow_print_icon=1\nshow_email_icon=1\nshow_hits=1\n\n', 0, 0, 0),
(30, 'topmenu', 'The Community', 'the-community', 'index.php?option=com_content&view=article&id=35', 'component', 1, 0, 20, 0, 4, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'pageclass_sfx=\nmenu_image=-1\nsecure=0\nshow_noauth=0\nlink_titles=0\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_author=1\nshow_create_date=1\nshow_modify_date=1\nshow_item_navigation=0\nshow_readmore=1\nshow_vote=0\nshow_icons=1\nshow_pdf_icon=1\nshow_print_icon=1\nshow_email_icon=1\nshow_hits=1\n\n', 0, 0, 0),
(34, 'mainmenu', 'What''s New in 1.5?', 'what-is-new-in-1-5', 'index.php?option=com_content&view=article&id=22', 'component', 1, 1, 20, 1, 2, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'pageclass_sfx=\nmenu_image=-1\nsecure=0\nshow_noauth=0\nshow_title=1\nlink_titles=0\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_author=1\nshow_create_date=1\nshow_modify_date=1\nshow_item_navigation=0\nshow_readmore=1\nshow_vote=0\nshow_icons=1\nshow_pdf_icon=1\nshow_print_icon=1\nshow_email_icon=1\nshow_hits=1\n\n', 0, 0, 0),
(40, 'keyconcepts', 'Extensions', 'extenstions', 'index.php?option=com_content&view=article&id=26', 'component', 1, 0, 20, 0, 1, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'pageclass_sfx=\nmenu_image=-1\nsecure=0\nshow_noauth=0\nlink_titles=0\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_author=1\nshow_create_date=1\nshow_modify_date=1\nshow_item_navigation=0\nshow_readmore=1\nshow_vote=0\nshow_icons=1\nshow_pdf_icon=1\nshow_print_icon=1\nshow_email_icon=1\nshow_hits=1\n\n', 0, 0, 0),
(37, 'mainmenu', 'More about Joomla!', 'more-about-joomla', 'index.php?option=com_content&view=section&id=4', 'component', 1, 1, 20, 1, 4, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'show_page_title=1\nshow_description=0\nshow_description_image=0\nshow_categories=1\nshow_empty_categories=0\nshow_cat_num_articles=1\nshow_category_description=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\norderby=\nshow_noauth=0\nshow_title=1\nlink_titles=0\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_author=1\nshow_create_date=1\nshow_modify_date=1\nshow_item_navigation=0\nshow_readmore=1\nshow_vote=0\nshow_icons=1\nshow_pdf_icon=1\nshow_print_icon=1\nshow_email_icon=1\nshow_hits=1\n\n', 0, 0, 0),
(43, 'keyconcepts', 'Example Pages', 'example-pages', 'index.php?option=com_content&view=article&id=43', 'component', 1, 0, 20, 0, 3, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'pageclass_sfx=\nmenu_image=-1\nsecure=0\nshow_noauth=0\nlink_titles=0\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_author=1\nshow_create_date=1\nshow_modify_date=1\nshow_item_navigation=0\nshow_readmore=1\nshow_vote=0\nshow_icons=1\nshow_pdf_icon=1\nshow_print_icon=1\nshow_email_icon=1\nshow_hits=1\n\n', 0, 0, 0),
(44, 'ExamplePages', 'Section Blog', 'section-blog', 'index.php?option=com_content&view=section&layout=blog&id=3', 'component', 1, 0, 20, 0, 1, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'show_page_title=1\npage_title=1\nshow_description=0\nshow_description_image=0\nnum_leading_articles=1\nnum_intro_articles=4\nnum_columns=2\nnum_links=4\nshow_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\norderby_pri=\norderby_sec=\nshow_pagination=2\nshow_pagination_results=1\nshow_noauth=0\nlink_titles=0\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_author=1\nshow_create_date=1\nshow_modify_date=1\nshow_item_navigation=0\nshow_readmore=1\nshow_vote=0\nshow_icons=1\nshow_pdf_icon=1\nshow_print_icon=1\nshow_email_icon=1\nshow_hits=1\n\n', 0, 0, 0),
(45, 'ExamplePages', 'Section Table', 'section-blog', 'index.php?option=com_content&view=section&id=3', 'component', 1, 0, 20, 0, 2, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'show_page_title=1\nshow_description=0\nshow_description_image=0\nshow_categories=1\nshow_empty_categories=0\nshow_cat_num_articles=1\nshow_category_description=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\norderby=\nshow_noauth=0\nlink_titles=0\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_author=1\nshow_create_date=1\nshow_modify_date=1\nshow_item_navigation=0\nshow_readmore=1\nshow_vote=0\nshow_icons=1\nshow_pdf_icon=1\nshow_print_icon=1\nshow_email_icon=1\nshow_hits=1\n\n', 0, 0, 0),
(46, 'ExamplePages', 'Category Blog', 'categoryblog', 'index.php?option=com_content&view=category&layout=blog&id=31', 'component', 1, 0, 20, 0, 3, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'show_page_title=1\npage_title=1\nshow_description=0\nshow_description_image=0\nnum_leading_articles=1\nnum_intro_articles=4\nnum_columns=2\nnum_links=4\nshow_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\norderby_pri=\norderby_sec=\nshow_pagination=2\nshow_pagination_results=1\nshow_noauth=0\nlink_titles=0\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_author=1\nshow_create_date=1\nshow_modify_date=1\nshow_item_navigation=0\nshow_readmore=1\nshow_vote=0\nshow_icons=1\nshow_pdf_icon=1\nshow_print_icon=1\nshow_email_icon=1\nshow_hits=1\n\n', 0, 0, 0),
(47, 'ExamplePages', 'Category Table', 'category-table', 'index.php?option=com_content&view=category&id=32', 'component', 1, 0, 20, 0, 4, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'show_page_title=1\npage_title=1\nshow_headings=1\nshow_date=0\ndate_format=\nfilter=1\nfilter_type=title\npageclass_sfx=\nmenu_image=-1\nsecure=0\norderby_sec=\nshow_pagination=1\nshow_pagination_limit=1\nshow_noauth=0\nlink_titles=0\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_author=1\nshow_create_date=1\nshow_modify_date=1\nshow_item_navigation=0\nshow_readmore=1\nshow_vote=0\nshow_icons=1\nshow_pdf_icon=1\nshow_print_icon=1\nshow_email_icon=1\nshow_hits=1\n\n', 0, 0, 0),
(48, 'mainmenu', 'Web Links', 'web-links', 'index.php?option=com_weblinks&view=categories', 'component', 1, 1, 4, 1, 7, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'page_title=Weblinks\nimage=-1\nimage_align=right\npageclass_sfx=\nmenu_image=-1\nsecure=0\nshow_comp_description=1\ncomp_description=\nshow_link_hits=1\nshow_link_description=1\nshow_other_cats=1\nshow_headings=1\nshow_page_title=1\nlink_target=0\nlink_icons=\n\n', 0, 0, 0),
(49, 'mainmenu', 'News Feeds', 'news-feeds', 'index.php?option=com_newsfeeds&view=categories', 'component', 1, 1, 11, 1, 8, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'show_page_title=1\npage_title=Newsfeeds\nshow_comp_description=1\ncomp_description=\nimage=-1\nimage_align=right\npageclass_sfx=\nmenu_image=-1\nsecure=0\nshow_headings=1\nshow_name=1\nshow_articles=1\nshow_link=1\nshow_other_cats=1\nshow_cat_description=1\nshow_cat_items=1\nshow_feed_image=1\nshow_feed_description=1\nshow_item_description=1\nfeed_word_count=0\n\n', 0, 0, 0),
(50, 'mainmenu', 'The News', 'the-news', 'index.php?option=com_content&view=category&layout=blog&id=1', 'component', 1, 1, 20, 1, 6, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'show_page_title=1\npage_title=The News\nshow_description=0\nshow_description_image=0\nnum_leading_articles=1\nnum_intro_articles=4\nnum_columns=2\nnum_links=4\npageclass_sfx=\nmenu_image=-1\nsecure=0\norderby_pri=\norderby_sec=\nshow_pagination=2\nshow_pagination_results=1\nshow_noauth=0\nshow_title=1\nlink_titles=0\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_author=1\nshow_create_date=1\nshow_modify_date=1\nshow_item_navigation=0\nshow_readmore=1\nshow_vote=0\nshow_icons=1\nshow_pdf_icon=1\nshow_print_icon=1\nshow_email_icon=1\nshow_hits=1\n\n', 0, 0, 0),
(51, 'mainmenu', 'About Us', 'features', 'index.php?option=com_content&view=article&id=48', 'component', 1, 0, 20, 0, 6, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'show_noauth=0\nshow_title=1\nlink_titles=0\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_author=1\nshow_create_date=1\nshow_modify_date=1\nshow_item_navigation=0\nshow_readmore=1\nshow_vote=0\nshow_icons=1\nshow_pdf_icon=1\nshow_print_icon=1\nshow_email_icon=1\nshow_hits=1\nfeed_summary=\npage_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(52, 'mainmenu', 'Advertisers', 'advertisers-', 'index.php?option=com_content&view=article&id=44', 'component', 1, 0, 20, 0, 7, 62, '2008-11-17 07:19:14', 0, 0, 0, 0, 'show_noauth=0\nshow_title=1\nlink_titles=0\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_author=1\nshow_create_date=1\nshow_modify_date=1\nshow_item_navigation=0\nshow_readmore=1\nshow_vote=0\nshow_icons=1\nshow_pdf_icon=1\nshow_print_icon=1\nshow_email_icon=1\nshow_hits=1\nfeed_summary=\npage_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(53, 'mainmenu', 'Publishers', 'publishers', 'index.php?option=com_content&view=article&id=47', 'component', 1, 0, 20, 0, 8, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'show_noauth=0\nshow_title=1\nlink_titles=0\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_author=1\nshow_create_date=1\nshow_modify_date=1\nshow_item_navigation=0\nshow_readmore=1\nshow_vote=0\nshow_icons=1\nshow_pdf_icon=1\nshow_print_icon=1\nshow_email_icon=1\nshow_hits=1\nfeed_summary=\npage_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(54, 'mainmenu', 'Home', 'home', 'index.php?option=com_content&view=article&id=45', 'component', 1, 0, 20, 0, 5, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'pageclass_sfx=\nmenu_image=-1\nsecure=0\nshow_noauth=0\nshow_title=1\nlink_titles=0\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_author=1\nshow_create_date=1\nshow_modify_date=1\nshow_item_navigation=0\nshow_readmore=1\nshow_vote=0\nshow_icons=1\nshow_pdf_icon=1\nshow_print_icon=1\nshow_email_icon=1\nshow_hits=1\n\n', 0, 0, 1),
(58, 'mainmenu', 'YOOmenu', 'yoomenu', 'index.php?option=com_content&view=article&id=54', 'component', 1, 119, 20, 2, 1, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'pageclass_sfx=\nmenu_image=-1\nsecure=0\nshow_noauth=0\nshow_title=1\nlink_titles=0\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_author=1\nshow_create_date=1\nshow_modify_date=1\nshow_item_navigation=0\nshow_readmore=1\nshow_vote=0\nshow_icons=1\nshow_pdf_icon=1\nshow_print_icon=1\nshow_email_icon=1\nshow_hits=1\n\n', 0, 0, 0),
(59, 'mainmenu', 'Fancy Menu', 'fancy-menu', 'index.php?option=com_content&view=article&id=59', 'component', 1, 119, 20, 2, 2, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'show_noauth=0\nshow_title=1\nlink_titles=0\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_author=1\nshow_create_date=1\nshow_modify_date=1\nshow_item_navigation=0\nshow_readmore=1\nshow_vote=0\nshow_icons=1\nshow_pdf_icon=1\nshow_print_icon=1\nshow_email_icon=1\nshow_hits=1\npage_title=\nshow_page_title=1\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(60, 'mainmenu', 'Accordion Menu', 'accordion-menu', 'index.php?option=com_content&view=article&id=61', 'component', 1, 119, 20, 2, 3, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'pageclass_sfx=\nmenu_image=-1\nsecure=0\nshow_noauth=0\nshow_title=1\nlink_titles=0\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_author=1\nshow_create_date=1\nshow_modify_date=1\nshow_item_navigation=0\nshow_readmore=1\nshow_vote=0\nshow_icons=1\nshow_pdf_icon=1\nshow_print_icon=1\nshow_email_icon=1\nshow_hits=1\n\n', 0, 0, 0),
(69, 'mainmenu', 'Top Panel', 'top-panel', 'index.php?option=com_content&view=article&id=46', 'component', 1, 124, 20, 2, 2, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'pageclass_sfx=\nmenu_image=-1\nsecure=0\nshow_noauth=0\nshow_title=1\nlink_titles=0\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_author=1\nshow_create_date=1\nshow_modify_date=1\nshow_item_navigation=0\nshow_readmore=1\nshow_vote=0\nshow_icons=1\nshow_pdf_icon=1\nshow_print_icon=1\nshow_email_icon=1\nshow_hits=1\n\n', 0, 0, 0),
(70, 'mainmenu', 'Tableless CSS Design', 'tableless-css-design', 'index.php?option=com_content&view=article&id=51', 'component', 1, 125, 20, 2, 1, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'pageclass_sfx=\nmenu_image=-1\nsecure=0\nshow_noauth=0\nshow_title=1\nlink_titles=0\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_author=1\nshow_create_date=1\nshow_modify_date=1\nshow_item_navigation=0\nshow_readmore=1\nshow_vote=0\nshow_icons=1\nshow_pdf_icon=1\nshow_print_icon=1\nshow_email_icon=1\nshow_hits=1\n\n', 0, 0, 0),
(71, 'mainmenu', 'Slimbox/Lightbox', 'slimboxlightbox', 'index.php?option=com_content&view=article&id=52', 'component', 1, 124, 20, 2, 3, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'pageclass_sfx=\nmenu_image=-1\nsecure=0\nshow_noauth=0\nshow_title=1\nlink_titles=0\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_author=1\nshow_create_date=1\nshow_modify_date=1\nshow_item_navigation=0\nshow_readmore=1\nshow_vote=0\nshow_icons=1\nshow_pdf_icon=1\nshow_print_icon=1\nshow_email_icon=1\nshow_hits=1\n\n', 0, 0, 0),
(72, 'mainmenu', 'Reflection', 'reflection', 'index.php?option=com_content&view=article&id=53', 'component', 1, 124, 20, 2, 4, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'pageclass_sfx=\nmenu_image=-1\nsecure=0\nshow_noauth=0\nshow_title=1\nlink_titles=0\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_author=1\nshow_create_date=1\nshow_modify_date=1\nshow_item_navigation=0\nshow_readmore=1\nshow_vote=0\nshow_icons=1\nshow_pdf_icon=1\nshow_print_icon=1\nshow_email_icon=1\nshow_hits=1\n\n', 0, 0, 0),
(73, 'mainmenu', 'Styleswitcher', 'styleswitcher', 'index.php?option=com_content&view=article&id=50', 'component', 1, 125, 20, 2, 2, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'pageclass_sfx=\nmenu_image=-1\nsecure=0\nshow_noauth=0\nshow_title=1\nlink_titles=0\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_author=1\nshow_create_date=1\nshow_modify_date=1\nshow_item_navigation=0\nshow_readmore=1\nshow_vote=0\nshow_icons=1\nshow_pdf_icon=1\nshow_print_icon=1\nshow_email_icon=1\nshow_hits=1\n\n', 0, 0, 0),
(74, 'mainmenu', 'YOOlogin', 'yoologin', 'index.php?option=com_content&view=article&id=62', 'component', 1, 126, 20, 2, 1, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'pageclass_sfx=\nmenu_image=-1\nsecure=0\nshow_noauth=0\nshow_title=1\nlink_titles=0\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_author=1\nshow_create_date=1\nshow_modify_date=1\nshow_item_navigation=0\nshow_readmore=1\nshow_vote=0\nshow_icons=1\nshow_pdf_icon=1\nshow_print_icon=1\nshow_email_icon=1\nshow_hits=1\n\n', 0, 0, 0),
(76, 'mainmenu', 'PNG Fix for IE6', 'png-fix-for-ie6', 'index.php?option=com_content&view=article&id=55', 'component', 1, 126, 20, 2, 2, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'pageclass_sfx=\nmenu_image=-1\nsecure=0\nshow_noauth=0\nshow_title=1\nlink_titles=0\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_author=1\nshow_create_date=1\nshow_modify_date=1\nshow_item_navigation=0\nshow_readmore=1\nshow_vote=0\nshow_icons=1\nshow_pdf_icon=1\nshow_print_icon=1\nshow_email_icon=1\nshow_hits=1\n\n', 0, 0, 0),
(77, 'mainmenu', 'XHTML&amp;CSS Validation', 'xhtmlaampcss-validation', 'index.php?option=com_content&view=article&id=56', 'component', 1, 125, 20, 2, 3, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'pageclass_sfx=\nmenu_image=-1\nsecure=0\nshow_noauth=0\nshow_title=1\nlink_titles=0\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_author=1\nshow_create_date=1\nshow_modify_date=1\nshow_item_navigation=0\nshow_readmore=1\nshow_vote=0\nshow_icons=1\nshow_pdf_icon=1\nshow_print_icon=1\nshow_email_icon=1\nshow_hits=1\n\n', 0, 0, 0),
(78, 'mainmenu', 'Browser Compatibility', 'browser-compatibility', 'index.php?option=com_content&view=article&id=57', 'component', 1, 125, 20, 2, 4, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'pageclass_sfx=\nmenu_image=-1\nsecure=0\nshow_noauth=0\nshow_title=1\nlink_titles=0\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_author=1\nshow_create_date=1\nshow_modify_date=1\nshow_item_navigation=0\nshow_readmore=1\nshow_vote=0\nshow_icons=1\nshow_pdf_icon=1\nshow_print_icon=1\nshow_email_icon=1\nshow_hits=1\n\n', 0, 0, 0),
(79, 'mainmenu', 'Demo Content', 'demo-content', 'index.php?option=com_content&view=article&id=58', 'component', 1, 126, 20, 2, 3, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'pageclass_sfx=\nmenu_image=-1\nsecure=0\nshow_noauth=0\nshow_title=1\nlink_titles=0\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_author=1\nshow_create_date=1\nshow_modify_date=1\nshow_item_navigation=0\nshow_readmore=1\nshow_vote=0\nshow_icons=1\nshow_pdf_icon=1\nshow_print_icon=1\nshow_email_icon=1\nshow_hits=1\n\n', 0, 0, 0),
(80, 'mainmenu', 'Sliced Image Sources', 'psd-file', 'index.php?option=com_content&view=article&id=63', 'component', 1, 126, 20, 2, 4, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'show_noauth=0\nshow_title=1\nlink_titles=0\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_author=1\nshow_create_date=1\nshow_modify_date=1\nshow_item_navigation=0\nshow_readmore=1\nshow_vote=0\nshow_icons=1\nshow_pdf_icon=1\nshow_print_icon=1\nshow_email_icon=1\nshow_hits=1\npage_title=\nshow_page_title=1\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(81, 'mainmenu', 'Top Variations', 'top-variations', '', 'separator', 1, 53, 0, 1, 1, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'menu_image=-1\n\n', 0, 0, 0),
(82, 'mainmenu', 'Top Variation A', 'top-variation-a', 'index.php?option=com_content&view=article&id=49', 'component', 1, 81, 20, 2, 1, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'pageclass_sfx=\nmenu_image=-1\nsecure=0\nshow_noauth=0\nshow_title=1\nlink_titles=0\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_author=1\nshow_create_date=1\nshow_modify_date=1\nshow_item_navigation=0\nshow_readmore=1\nshow_vote=0\nshow_icons=1\nshow_pdf_icon=1\nshow_print_icon=1\nshow_email_icon=1\nshow_hits=1\n\n', 0, 0, 0),
(83, 'mainmenu', 'Top Variation B', 'top-variation-b', 'index.php?option=com_content&view=article&id=49', 'component', 1, 81, 20, 2, 2, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'pageclass_sfx=\nmenu_image=-1\nsecure=0\nshow_noauth=0\nshow_title=1\nlink_titles=0\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_author=1\nshow_create_date=1\nshow_modify_date=1\nshow_item_navigation=0\nshow_readmore=1\nshow_vote=0\nshow_icons=1\nshow_pdf_icon=1\nshow_print_icon=1\nshow_email_icon=1\nshow_hits=1\n\n', 0, 0, 0),
(84, 'mainmenu', 'Right Variations', 'right-variations', '', 'separator', 1, 53, 0, 1, 2, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'menu_image=-1\n\n', 0, 0, 0),
(85, 'mainmenu', 'Right nested', 'right-nested', 'index.php?option=com_content&view=article&id=49', 'component', 1, 84, 20, 2, 1, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'pageclass_sfx=\nmenu_image=-1\nsecure=0\nshow_noauth=0\nshow_title=1\nlink_titles=0\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_author=1\nshow_create_date=1\nshow_modify_date=1\nshow_item_navigation=0\nshow_readmore=1\nshow_vote=0\nshow_icons=1\nshow_pdf_icon=1\nshow_print_icon=1\nshow_email_icon=1\nshow_hits=1\n\n', 0, 0, 0),
(86, 'mainmenu', 'Right normal', 'right-normal', 'index.php?option=com_content&view=article&id=49', 'component', 1, 84, 20, 2, 2, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'pageclass_sfx=\nmenu_image=-1\nsecure=0\nshow_noauth=0\nshow_title=1\nlink_titles=0\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_author=1\nshow_create_date=1\nshow_modify_date=1\nshow_item_navigation=0\nshow_readmore=1\nshow_vote=0\nshow_icons=1\nshow_pdf_icon=1\nshow_print_icon=1\nshow_email_icon=1\nshow_hits=1\n\n', 0, 0, 0),
(87, 'mainmenu', 'Middle Variation A', 'middle-variation-a', 'index.php?option=com_content&view=article&id=49', 'component', 1, 88, 20, 2, 1, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'pageclass_sfx=\nmenu_image=-1\nsecure=0\nshow_noauth=0\nshow_title=1\nlink_titles=0\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_author=1\nshow_create_date=1\nshow_modify_date=1\nshow_item_navigation=0\nshow_readmore=1\nshow_vote=0\nshow_icons=1\nshow_pdf_icon=1\nshow_print_icon=1\nshow_email_icon=1\nshow_hits=1\n\n', 0, 0, 0),
(88, 'mainmenu', 'Middle Variations', 'middle-variations', '', 'separator', 1, 53, 0, 1, 3, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'menu_image=-1\n\n', 0, 0, 0),
(90, 'mainmenu', 'Middle Variation B', 'middle-variation-b', 'index.php?option=com_content&view=article&id=49', 'component', 1, 88, 20, 2, 2, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'pageclass_sfx=\nmenu_image=-1\nsecure=0\nshow_noauth=0\nshow_title=1\nlink_titles=0\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_author=1\nshow_create_date=1\nshow_modify_date=1\nshow_item_navigation=0\nshow_readmore=1\nshow_vote=0\nshow_icons=1\nshow_pdf_icon=1\nshow_print_icon=1\nshow_email_icon=1\nshow_hits=1\n\n', 0, 0, 0),
(91, 'mainmenu', 'Middle Variation Blank', 'middle-variation-blank', 'index.php?option=com_content&view=article&id=49', 'component', 1, 88, 20, 2, 4, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'pageclass_sfx=\nmenu_image=-1\nsecure=0\nshow_noauth=0\nshow_title=1\nlink_titles=0\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_author=1\nshow_create_date=1\nshow_modify_date=1\nshow_item_navigation=0\nshow_readmore=1\nshow_vote=0\nshow_icons=1\nshow_pdf_icon=1\nshow_print_icon=1\nshow_email_icon=1\nshow_hits=1\n\n', 0, 0, 0),
(92, 'mainmenu', 'Left Variation', 'left-variation', 'index.php?option=com_content&view=article&id=49', 'component', 1, 53, 20, 1, 4, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'pageclass_sfx=\nmenu_image=-1\nsecure=0\nshow_noauth=0\nshow_title=1\nlink_titles=0\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_author=1\nshow_create_date=1\nshow_modify_date=1\nshow_item_navigation=0\nshow_readmore=1\nshow_vote=0\nshow_icons=1\nshow_pdf_icon=1\nshow_print_icon=1\nshow_email_icon=1\nshow_hits=1\n\n', 0, 0, 0),
(93, 'mainmenu', 'Bottom Variation', 'bottom-variation', 'index.php?option=com_content&view=article&id=49', 'component', 1, 53, 20, 1, 5, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'pageclass_sfx=\nmenu_image=-1\nsecure=0\nshow_noauth=0\nshow_title=1\nlink_titles=0\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_author=1\nshow_create_date=1\nshow_modify_date=1\nshow_item_navigation=0\nshow_readmore=1\nshow_vote=0\nshow_icons=1\nshow_pdf_icon=1\nshow_print_icon=1\nshow_email_icon=1\nshow_hits=1\n\n', 0, 0, 0),
(94, 'mainmenu', 'Without Bottom', 'without-bottom', 'index.php?option=com_content&view=article&id=49', 'component', 1, 128, 20, 2, 1, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'pageclass_sfx=\nmenu_image=-1\nsecure=0\nshow_noauth=0\nshow_title=1\nlink_titles=0\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_author=1\nshow_create_date=1\nshow_modify_date=1\nshow_item_navigation=0\nshow_readmore=1\nshow_vote=0\nshow_icons=1\nshow_pdf_icon=1\nshow_print_icon=1\nshow_email_icon=1\nshow_hits=1\n\n', 0, 0, 0),
(95, 'mainmenu', 'Without Search', 'without-search', 'index.php?option=com_content&view=article&id=49', 'component', 1, 128, 20, 2, 4, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'pageclass_sfx=\nmenu_image=-1\nsecure=0\nshow_noauth=0\nshow_title=1\nlink_titles=0\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_author=1\nshow_create_date=1\nshow_modify_date=1\nshow_item_navigation=0\nshow_readmore=1\nshow_vote=0\nshow_icons=1\nshow_pdf_icon=1\nshow_print_icon=1\nshow_email_icon=1\nshow_hits=1\n\n', 0, 0, 0),
(96, 'mainmenu', 'Without Top', 'without-top', 'index.php?option=com_content&view=article&id=49', 'component', 1, 128, 20, 2, 3, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'pageclass_sfx=\nmenu_image=-1\nsecure=0\nshow_noauth=0\nshow_title=1\nlink_titles=0\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_author=1\nshow_create_date=1\nshow_modify_date=1\nshow_item_navigation=0\nshow_readmore=1\nshow_vote=0\nshow_icons=1\nshow_pdf_icon=1\nshow_print_icon=1\nshow_email_icon=1\nshow_hits=1\n\n', 0, 0, 0),
(97, 'mainmenu', 'Without Top Panel', 'without-top-panel', 'index.php?option=com_content&view=article&id=49', 'component', 1, 128, 20, 2, 2, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'pageclass_sfx=\nmenu_image=-1\nsecure=0\nshow_noauth=0\nshow_title=1\nlink_titles=0\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_author=1\nshow_create_date=1\nshow_modify_date=1\nshow_item_navigation=0\nshow_readmore=1\nshow_vote=0\nshow_icons=1\nshow_pdf_icon=1\nshow_print_icon=1\nshow_email_icon=1\nshow_hits=1\n\n', 0, 0, 0),
(98, 'mainmenu', 'New Features', 'new-features', '', 'separator', -2, 0, 0, 1, 3, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'menu_image=-1\n\n', 0, 0, 0),
(99, 'mainmenu', 'Fancy Menu', 'fancy-menu', 'index.php?option=com_content&view=article&id=59&Itemid=59', 'url', -2, 0, 0, 2, 4, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'menu_image=-1\n\n', 0, 0, 0),
(100, 'mainmenu', 'Color Variations', 'color-variations', '', 'separator', 1, 54, 0, 1, 2, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'menu_image=-1\n\n', 0, 0, 0),
(101, 'mainmenu', 'Color White', 'color-white', 'index.php?option=com_content&view=frontpage&Itemid=1', 'url', 1, 100, 0, 2, 1, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'menu_image=-1\n\n', 0, 0, 0),
(102, 'mainmenu', 'Color Red', 'color-red', 'index.php?option=com_content&view=article&id=45&Itemid=54', 'url', 1, 100, 0, 2, 2, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'menu_image=-1\n\n', 0, 0, 0),
(103, 'mainmenu', 'Color Blue', 'color-blue', 'index.php?option=com_content&view=article&id=48&Itemid=51', 'url', 1, 100, 0, 2, 3, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'menu_image=-1\n\n', 0, 0, 0),
(104, 'mainmenu', 'Color Orange', 'color-orange', 'index.php?option=com_content&view=article&id=44&Itemid=52', 'url', 1, 100, 0, 2, 4, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'menu_image=-1\n\n', 0, 0, 0),
(105, 'mainmenu', 'Color Green', 'color-green', 'index.php?option=com_content&view=article&id=47&Itemid=53', 'url', 1, 100, 0, 2, 5, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'menu_image=-1\n\n', 0, 0, 0),
(111, 'mainmenu', 'Menu Item as Separator', 'menu-item-as-separator', '', 'separator', 0, 54, 0, 1, 3, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'menu_image=-1\n\n', 0, 0, 0),
(112, 'mainmenu', 'Item 1', 'item-1', 'index.php?option=com_content&view=article&id=49', 'component', 0, 111, 20, 2, 1, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'pageclass_sfx=\nmenu_image=-1\nsecure=0\nshow_noauth=0\nshow_title=1\nlink_titles=0\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_author=1\nshow_create_date=1\nshow_modify_date=1\nshow_item_navigation=0\nshow_readmore=1\nshow_vote=0\nshow_icons=1\nshow_pdf_icon=1\nshow_print_icon=1\nshow_email_icon=1\nshow_hits=1\n\n', 0, 0, 0),
(113, 'mainmenu', 'Item 2', 'item-2', 'index.php?option=com_content&view=article&id=49', 'component', 0, 111, 20, 2, 2, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'pageclass_sfx=\nmenu_image=-1\nsecure=0\nshow_noauth=0\nshow_title=1\nlink_titles=0\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_author=1\nshow_create_date=1\nshow_modify_date=1\nshow_item_navigation=0\nshow_readmore=1\nshow_vote=0\nshow_icons=1\nshow_pdf_icon=1\nshow_print_icon=1\nshow_email_icon=1\nshow_hits=1\n\n', 0, 0, 0),
(114, 'mainmenu', 'Item 3', 'item-3', 'index.php?option=com_content&view=article&id=49', 'component', 0, 111, 20, 2, 3, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'pageclass_sfx=\nmenu_image=-1\nsecure=0\nshow_noauth=0\nshow_title=1\nlink_titles=0\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_author=1\nshow_create_date=1\nshow_modify_date=1\nshow_item_navigation=0\nshow_readmore=1\nshow_vote=0\nshow_icons=1\nshow_pdf_icon=1\nshow_print_icon=1\nshow_email_icon=1\nshow_hits=1\n\n', 0, 0, 0),
(115, 'mainmenu', 'Menu Item as Link', 'menu-item-as-link', 'index.php?option=com_content&view=article&id=49', 'component', 0, 54, 20, 1, 4, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'pageclass_sfx=\nmenu_image=-1\nsecure=0\nshow_noauth=0\nshow_title=1\nlink_titles=0\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_author=1\nshow_create_date=1\nshow_modify_date=1\nshow_item_navigation=0\nshow_readmore=1\nshow_vote=0\nshow_icons=1\nshow_pdf_icon=1\nshow_print_icon=1\nshow_email_icon=1\nshow_hits=1\n\n', 0, 0, 0),
(116, 'mainmenu', 'Item 1', 'item-1', 'index.php?option=com_content&view=article&id=49', 'component', 0, 115, 20, 2, 1, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'pageclass_sfx=\nmenu_image=-1\nsecure=0\nshow_noauth=0\nshow_title=1\nlink_titles=0\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_author=1\nshow_create_date=1\nshow_modify_date=1\nshow_item_navigation=0\nshow_readmore=1\nshow_vote=0\nshow_icons=1\nshow_pdf_icon=1\nshow_print_icon=1\nshow_email_icon=1\nshow_hits=1\n\n', 0, 0, 0),
(117, 'mainmenu', 'Item 2', 'item-2', 'index.php?option=com_content&view=article&id=49', 'component', 0, 115, 20, 2, 2, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'pageclass_sfx=\nmenu_image=-1\nsecure=0\nshow_noauth=0\nshow_title=1\nlink_titles=0\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_author=1\nshow_create_date=1\nshow_modify_date=1\nshow_item_navigation=0\nshow_readmore=1\nshow_vote=0\nshow_icons=1\nshow_pdf_icon=1\nshow_print_icon=1\nshow_email_icon=1\nshow_hits=1\n\n', 0, 0, 0),
(118, 'mainmenu', 'Item 3', 'item-3', 'index.php?option=com_content&view=article&id=49', 'component', 0, 115, 20, 2, 3, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'pageclass_sfx=\nmenu_image=-1\nsecure=0\nshow_noauth=0\nshow_title=1\nlink_titles=0\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_author=1\nshow_create_date=1\nshow_modify_date=1\nshow_item_navigation=0\nshow_readmore=1\nshow_vote=0\nshow_icons=1\nshow_pdf_icon=1\nshow_print_icon=1\nshow_email_icon=1\nshow_hits=1\n\n', 0, 0, 0),
(119, 'mainmenu', 'YOOmenu System', 'yoomenu-system', '', 'separator', 1, 51, 0, 1, 5, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'menu_image=-1\n\n', 0, 0, 0),
(121, 'othermenu', 'Careers', 'careers', '', 'separator', 1, 0, 0, 1, 6, 62, '2008-11-17 12:11:12', 0, 0, 0, 0, 'menu_image=-1\n\n', 0, 0, 0),
(122, 'othermenu', 'Company profile', 'level-2', 'index.php?option=com_content&view=article&id=61', 'component', 1, 121, 20, 2, 1, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'show_noauth=0\nshow_title=1\nlink_titles=0\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_author=1\nshow_create_date=1\nshow_modify_date=1\nshow_item_navigation=0\nshow_readmore=1\nshow_vote=0\nshow_icons=1\nshow_pdf_icon=1\nshow_print_icon=1\nshow_email_icon=1\nshow_hits=1\nfeed_summary=\npage_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(123, 'othermenu', 'Contact Us', 'contact-us', '', 'separator', 1, 0, 0, 1, 7, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'menu_image=-1\n\n', 0, 0, 0),
(124, 'mainmenu', 'Web 2.0 Features', 'web-20-features', '', 'separator', 1, 51, 0, 1, 6, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'menu_image=-1\n\n', 0, 0, 0),
(125, 'mainmenu', 'Web Accessibility', 'web-accessibility', '', 'separator', 1, 51, 0, 1, 7, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'menu_image=-1\n\n', 0, 0, 0),
(126, 'mainmenu', 'Basic Features', 'basic-features', '', 'separator', 1, 51, 0, 1, 8, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'menu_image=-1\n\n', 0, 0, 0),
(127, 'mainmenu', 'Middle Variation C', 'middle-variation-c', 'index.php?option=com_content&view=article&id=49', 'component', 1, 88, 20, 2, 3, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'pageclass_sfx=\nmenu_image=-1\nsecure=0\nshow_noauth=0\nshow_title=1\nlink_titles=0\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_author=1\nshow_create_date=1\nshow_modify_date=1\nshow_item_navigation=0\nshow_readmore=1\nshow_vote=0\nshow_icons=1\nshow_pdf_icon=1\nshow_print_icon=1\nshow_email_icon=1\nshow_hits=1\n\n', 0, 0, 0),
(128, 'mainmenu', 'Variations Without', 'variations-without', '', 'separator', 1, 53, 0, 1, 6, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'menu_image=-1\n\n', 0, 0, 0),
(129, 'mainmenu', 'Without Banner', 'without-banner', 'index.php?option=com_content&view=article&id=49', 'component', 1, 128, 20, 2, 5, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'pageclass_sfx=\nmenu_image=-1\nsecure=0\nshow_noauth=0\nshow_title=1\nlink_titles=0\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_author=1\nshow_create_date=1\nshow_modify_date=1\nshow_item_navigation=0\nshow_readmore=1\nshow_vote=0\nshow_icons=1\nshow_pdf_icon=1\nshow_print_icon=1\nshow_email_icon=1\nshow_hits=1\n\n', 0, 0, 0),
(130, 'othermenu', 'General Information', 'general-information', 'index.php?option=com_content&view=article&id=61', 'component', 1, 123, 20, 2, 1, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'show_noauth=0\nshow_title=1\nlink_titles=0\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_author=1\nshow_create_date=1\nshow_modify_date=1\nshow_item_navigation=0\nshow_readmore=1\nshow_vote=0\nshow_icons=1\nshow_pdf_icon=1\nshow_print_icon=1\nshow_email_icon=1\nshow_hits=1\nfeed_summary=\npage_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(131, 'othermenu', 'Life at e-marketing', 'level-2', 'index.php?option=com_content&view=article&id=61', 'component', 1, 121, 20, 2, 2, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'show_noauth=0\nshow_title=1\nlink_titles=0\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_author=1\nshow_create_date=1\nshow_modify_date=1\nshow_item_navigation=0\nshow_readmore=1\nshow_vote=0\nshow_icons=1\nshow_pdf_icon=1\nshow_print_icon=1\nshow_email_icon=1\nshow_hits=1\nfeed_summary=\npage_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(132, 'othermenu', 'Help Desk', 'help-desk-', 'index.php?option=com_content&view=article&id=61', 'component', 1, 123, 20, 2, 2, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'show_noauth=0\nshow_title=1\nlink_titles=0\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_author=1\nshow_create_date=1\nshow_modify_date=1\nshow_item_navigation=0\nshow_readmore=1\nshow_vote=0\nshow_icons=1\nshow_pdf_icon=1\nshow_print_icon=1\nshow_email_icon=1\nshow_hits=1\nfeed_summary=\npage_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(133, 'othermenu', 'Job board', 'level-2', 'index.php?option=com_content&view=article&id=61', 'component', 1, 121, 20, 2, 3, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'show_noauth=0\nshow_title=1\nlink_titles=0\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_author=1\nshow_create_date=1\nshow_modify_date=1\nshow_item_navigation=0\nshow_readmore=1\nshow_vote=0\nshow_icons=1\nshow_pdf_icon=1\nshow_print_icon=1\nshow_email_icon=1\nshow_hits=1\nfeed_summary=\npage_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(134, 'othermenu', 'Level 3', 'level-3', 'index.php?option=com_content&view=article&id=61', 'component', -2, 0, 20, 3, 5, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'pageclass_sfx=\nmenu_image=-1\nsecure=0\nshow_noauth=0\nshow_title=1\nlink_titles=0\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_author=1\nshow_create_date=1\nshow_modify_date=1\nshow_item_navigation=0\nshow_readmore=1\nshow_vote=0\nshow_icons=1\nshow_pdf_icon=1\nshow_print_icon=1\nshow_email_icon=1\nshow_hits=1\n\n', 0, 0, 0),
(135, 'othermenu', 'Level 3', 'level-3', 'index.php?option=com_content&view=article&id=61', 'component', -2, 0, 20, 3, 4, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'pageclass_sfx=\nmenu_image=-1\nsecure=0\nshow_noauth=0\nshow_title=1\nlink_titles=0\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_author=1\nshow_create_date=1\nshow_modify_date=1\nshow_item_navigation=0\nshow_readmore=1\nshow_vote=0\nshow_icons=1\nshow_pdf_icon=1\nshow_print_icon=1\nshow_email_icon=1\nshow_hits=1\n\n', 0, 0, 0),
(136, 'othermenu', 'Level 4', 'level-4', 'index.php?option=com_content&view=article&id=61', 'component', -2, 0, 20, 4, 3, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'pageclass_sfx=\nmenu_image=-1\nsecure=0\nshow_noauth=0\nshow_title=1\nlink_titles=0\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_author=1\nshow_create_date=1\nshow_modify_date=1\nshow_item_navigation=0\nshow_readmore=1\nshow_vote=0\nshow_icons=1\nshow_pdf_icon=1\nshow_print_icon=1\nshow_email_icon=1\nshow_hits=1\n\n', 0, 0, 0),
(137, 'othermenu', 'Level 2', 'level-2', 'index.php?option=com_content&view=article&id=61', 'component', -2, 0, 20, 2, 1, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'pageclass_sfx=\nmenu_image=-1\nsecure=0\nshow_noauth=0\nshow_title=1\nlink_titles=0\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_author=1\nshow_create_date=1\nshow_modify_date=1\nshow_item_navigation=0\nshow_readmore=1\nshow_vote=0\nshow_icons=1\nshow_pdf_icon=1\nshow_print_icon=1\nshow_email_icon=1\nshow_hits=1\n\n', 0, 0, 0),
(138, 'othermenu', 'Level 4', 'level-4', 'index.php?option=com_content&view=article&id=61', 'component', -2, 0, 20, 4, 2, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'pageclass_sfx=\nmenu_image=-1\nsecure=0\nshow_noauth=0\nshow_title=1\nlink_titles=0\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_author=1\nshow_create_date=1\nshow_modify_date=1\nshow_item_navigation=0\nshow_readmore=1\nshow_vote=0\nshow_icons=1\nshow_pdf_icon=1\nshow_print_icon=1\nshow_email_icon=1\nshow_hits=1\n\n', 0, 0, 0),
(140, 'mainmenu', 'YOOslider', 'yooslider', 'index.php?option=com_content&view=article&id=65&Itemid=141', 'url', -2, 0, 0, 2, 2, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'menu_image=-1\n\n', 0, 0, 0),
(141, 'mainmenu', 'YOOslider', 'yooslider', 'index.php?option=com_content&view=article&id=65', 'component', 1, 124, 20, 2, 1, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'show_noauth=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_item_navigation=\nshow_readmore=\nshow_vote=\nshow_icons=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nshow_hits=\npage_title=\nshow_page_title=1\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(142, 'mainmenu', 'Sliced Fireworks Sources', 'sliced-fireworks-sources', 'index.php?option=com_content&view=article&id=63&Itemid=80', 'url', -2, 0, 0, 2, 1, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'menu_image=-1\n\n', 0, 0, 0),
(143, 'mainmenu', 'about 2', 'about-2', '', 'url', 1, 0, 0, 0, 11, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'menu_image=-1\n\n', 0, 0, 0),
(144, 'othermenu', 'Paid placement', 'paid-placement', 'index.php?option=com_content&view=article&id=65', 'component', 1, 15, 20, 1, 1, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'show_noauth=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_item_navigation=\nshow_readmore=\nshow_vote=\nshow_icons=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nshow_hits=\nfeed_summary=\npage_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(145, 'othermenu', 'Organic Optimisation', 'organic-optimisation', '', 'url', 1, 15, 0, 1, 2, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'menu_image=-1\n\n', 0, 0, 0),
(146, 'othermenu', 'Blogs', 'blog--', 'index.php?option=com_weblinks&view=categories', 'component', 1, 0, 4, 0, 13, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'image=-1\nimage_align=right\nshow_feed_link=1\nshow_comp_description=\ncomp_description=\nshow_link_hits=\nshow_link_description=\nshow_other_cats=\nshow_headings=\ntarget=\nlink_icons=\npage_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(147, 'othermenu', 'Our vision', 'our-vision-', 'index.php?option=com_content&view=article&id=74', 'component', 0, 11, 20, 1, 1, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'show_noauth=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_item_navigation=\nshow_readmore=\nshow_vote=\nshow_icons=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nshow_hits=\nfeed_summary=\npage_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(148, 'othermenu', 'Services', 'services', '', 'url', 0, 11, 0, 1, 2, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'menu_image=-1\n\n', 0, 0, 0),
(149, 'othermenu', 'Quality Content', 'quality-content', '', 'url', 1, 12, 0, 1, 1, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'menu_image=-1\n\n', 0, 0, 0),
(150, 'othermenu', 'Performance and results', 'performance-and-optimized-results', '', 'url', 1, 12, 0, 1, 2, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'menu_image=-1\n\n', 0, 0, 0),
(151, 'othermenu', 'Targeted Reach', 'targeted-reach-', '', 'url', 1, 12, 0, 1, 3, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'menu_image=-1\n\n', 0, 0, 0),
(152, 'othermenu', 'Mobile', 'mobile--downloadable-applications', '', 'url', 1, 12, 0, 1, 4, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'menu_image=-1\n\n', 0, 0, 0),
(153, 'othermenu', 'Affiliate', 'affiliate-', '', 'url', 1, 12, 0, 1, 5, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'menu_image=-1\n\n', 0, 0, 0),
(154, 'othermenu', 'Creative Services', 'creative-services', '', 'url', 1, 12, 0, 1, 6, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'menu_image=-1\n\n', 0, 0, 0),
(155, 'othermenu', 'Case Studies', 'case-studies', '', 'url', 1, 12, 0, 1, 7, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'menu_image=-1\n\n', 0, 0, 0),
(156, 'othermenu', 'Login', 'login', '', 'url', 1, 12, 0, 1, 8, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'menu_image=-1\n\n', 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `jos_menu_types`
--

CREATE TABLE IF NOT EXISTS `jos_menu_types` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `menutype` varchar(225) NOT NULL default '',
  `title` text NOT NULL,
  `description` text NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `menutype` (`menutype`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `jos_menu_types`
--

INSERT INTO `jos_menu_types` (`id`, `menutype`, `title`, `description`) VALUES
(1, 'mainmenu', 'Main Menu', 'The main menu for the site'),
(2, 'usermenu', 'User Menu', 'A menu for logged in users'),
(3, 'topmenu', 'Top Menu', 'Top level navigation'),
(4, 'othermenu', 'Other Menu', 'Additional links'),
(5, 'ExamplePages', 'Example Pages', 'Example Pages'),
(6, 'keyconcepts', 'Key Concepts', 'This describes some critical information for new users.');

-- --------------------------------------------------------

--
-- Table structure for table `jos_messages`
--

CREATE TABLE IF NOT EXISTS `jos_messages` (
  `message_id` int(10) unsigned NOT NULL auto_increment,
  `user_id_from` int(10) unsigned NOT NULL default '0',
  `user_id_to` int(10) unsigned NOT NULL default '0',
  `folder_id` int(10) unsigned NOT NULL default '0',
  `date_time` datetime NOT NULL default '0000-00-00 00:00:00',
  `state` int(11) NOT NULL default '0',
  `priority` int(1) unsigned NOT NULL default '0',
  `subject` text NOT NULL,
  `message` text NOT NULL,
  PRIMARY KEY  (`message_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `jos_messages`
--


-- --------------------------------------------------------

--
-- Table structure for table `jos_messages_cfg`
--

CREATE TABLE IF NOT EXISTS `jos_messages_cfg` (
  `user_id` int(10) unsigned NOT NULL default '0',
  `cfg_name` text NOT NULL,
  `cfg_value` text NOT NULL,
  UNIQUE KEY `idx_user_var_name` (`user_id`,`cfg_name`(100))
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `jos_messages_cfg`
--


-- --------------------------------------------------------

--
-- Table structure for table `jos_modules`
--

CREATE TABLE IF NOT EXISTS `jos_modules` (
  `id` int(11) NOT NULL auto_increment,
  `title` text NOT NULL,
  `content` text NOT NULL,
  `ordering` int(11) NOT NULL default '0',
  `position` varchar(150) default NULL,
  `checked_out` int(11) unsigned NOT NULL default '0',
  `checked_out_time` datetime NOT NULL default '0000-00-00 00:00:00',
  `published` tinyint(1) NOT NULL default '0',
  `module` varchar(150) default NULL,
  `numnews` int(11) NOT NULL default '0',
  `access` tinyint(3) unsigned NOT NULL default '0',
  `showtitle` tinyint(3) unsigned NOT NULL default '1',
  `params` text NOT NULL,
  `iscore` tinyint(4) NOT NULL default '0',
  `client_id` tinyint(4) NOT NULL default '0',
  `control` text NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `published` (`published`,`access`),
  KEY `newsfeeds` (`module`,`published`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=97 ;

--
-- Dumping data for table `jos_modules`
--

INSERT INTO `jos_modules` (`id`, `title`, `content`, `ordering`, `position`, `checked_out`, `checked_out_time`, `published`, `module`, `numnews`, `access`, `showtitle`, `params`, `iscore`, `client_id`, `control`) VALUES
(1, 'Main Menu (Fancy)', '', 0, 'menu', 0, '0000-00-00 00:00:00', 1, 'mod_mainmenu', 0, 0, 0, 'menutype=mainmenu\nmenu_style=list\nstartLevel=0\nendLevel=1\nshowAllChildren=0\nwindow_open=\nshow_whitespace=0\ncache=1\nclass_sfx=\nmoduleclass_sfx=_menu\nmenu_images=0\nmenu_images_align=0\nexpand_menu=0\nactivate_parent=0\nfull_active_id=0\nindent_image=0\nindent_image1=\nindent_image2=\nindent_image3=\nindent_image4=\nindent_image5=\nindent_image6=\nspacer=\nend_spacer=\n\n', 1, 0, ''),
(2, 'Login', '', 1, 'login', 0, '0000-00-00 00:00:00', 1, 'mod_login', 0, 0, 1, '', 1, 1, ''),
(3, 'Popular', '', 3, 'cpanel', 0, '0000-00-00 00:00:00', 1, 'mod_popular', 0, 2, 1, '', 0, 1, ''),
(4, 'Recent added Articles', '', 4, 'cpanel', 0, '0000-00-00 00:00:00', 1, 'mod_latest', 0, 2, 1, 'ordering=c_dsc\nuser_id=0\ncache=0\n\n', 0, 1, ''),
(5, 'Menu Stats', '', 5, 'cpanel', 0, '0000-00-00 00:00:00', 1, 'mod_stats', 0, 2, 1, '', 0, 1, ''),
(6, 'Unread Messages', '', 1, 'header', 0, '0000-00-00 00:00:00', 1, 'mod_unread', 0, 2, 1, '', 1, 1, ''),
(7, 'Online Users', '', 2, 'header', 0, '0000-00-00 00:00:00', 1, 'mod_online', 0, 2, 1, '', 1, 1, ''),
(8, 'Toolbar', '', 1, 'toolbar', 0, '0000-00-00 00:00:00', 1, 'mod_toolbar', 0, 2, 1, '', 1, 1, ''),
(9, 'Quick Icons', '', 1, 'icon', 0, '0000-00-00 00:00:00', 1, 'mod_quickicon', 0, 2, 1, '', 1, 1, ''),
(10, 'Logged in Users', '', 2, 'cpanel', 0, '0000-00-00 00:00:00', 1, 'mod_logged', 0, 2, 1, '', 0, 1, ''),
(11, 'Footer', '', 0, 'footer', 0, '0000-00-00 00:00:00', 1, 'mod_footer', 0, 0, 1, '', 1, 1, ''),
(12, 'Admin Menu', '', 1, 'menu', 0, '0000-00-00 00:00:00', 1, 'mod_menu', 0, 2, 1, '', 0, 1, ''),
(13, 'Admin SubMenu', '', 1, 'submenu', 0, '0000-00-00 00:00:00', 1, 'mod_submenu', 0, 2, 1, '', 0, 1, ''),
(14, 'User Status', '', 1, 'status', 0, '0000-00-00 00:00:00', 1, 'mod_status', 0, 2, 1, '', 0, 1, ''),
(15, 'Title', '', 1, 'title', 0, '0000-00-00 00:00:00', 1, 'mod_title', 0, 2, 1, '', 0, 1, ''),
(16, 'Polls', '', 1, 'right', 0, '0000-00-00 00:00:00', 1, 'mod_poll', 0, 0, 1, 'id=15\nmoduleclass_sfx=\ncache=1\ncache_time=900\n\n', 0, 0, ''),
(17, 'User Menu', '', 2, 'left', 0, '0000-00-00 00:00:00', 1, 'mod_mainmenu', 0, 1, 1, 'menutype=usermenu\nmenu_style=list\nstartLevel=0\nendLevel=5\nshowAllChildren=0\nwindow_open=\nshow_whitespace=0\ncache=1\nclass_sfx=\nmoduleclass_sfx=_menu\nmenu_images=0\nmenu_images_align=0\nexpand_menu=0\nactivate_parent=0\nfull_active_id=0\nindent_image=0\nindent_image1=\nindent_image2=\nindent_image3=\nindent_image4=\nindent_image5=\nindent_image6=\nspacer=\nend_spacer=\n\n', 1, 0, ''),
(18, 'Login Form', '', 1, 'top', 0, '0000-00-00 00:00:00', 1, 'mod_login', 0, 0, 1, 'cache=0\nmoduleclass_sfx=\npretext=\nposttext=\nlogin=\nlogout=\ngreeting=1\nname=0\n\n', 1, 0, ''),
(19, 'Latest News', '', 3, 'user4', 0, '0000-00-00 00:00:00', 0, 'mod_latestnews', 0, 0, 1, 'count=5\nordering=c_dsc\nuser_id=0\nshow_front=1\ncatid=\nsecid=\nmoduleclass_sfx=\ncache=1\ncache_time=900\n\n', 1, 0, ''),
(20, 'Statistics', '', 6, 'left', 0, '0000-00-00 00:00:00', 0, 'mod_stats', 0, 0, 1, 'serverinfo=1\nsiteinfo=1\ncounter=1\nincrease=0\nmoduleclass_sfx=', 0, 0, ''),
(21, 'Who''s Online', '', 2, 'right', 0, '0000-00-00 00:00:00', 0, 'mod_whosonline', 0, 0, 1, 'cache=0\nshowmode=0\nmoduleclass_sfx=\n\n', 0, 0, ''),
(22, 'Popular', '', 2, 'user5', 0, '0000-00-00 00:00:00', 1, 'mod_mostread', 0, 0, 1, 'moduleclass_sfx=\nshow_front=1\ncount=5\ncatid=\nsecid=\ncache=1\ncache_time=900\n\n', 0, 0, ''),
(23, 'Archive', '', 8, 'left', 0, '0000-00-00 00:00:00', 0, 'mod_archive', 0, 0, 1, 'cache=1', 1, 0, ''),
(24, 'Sections', '', 9, 'left', 0, '0000-00-00 00:00:00', 0, 'mod_sections', 0, 0, 1, 'cache=1', 1, 0, ''),
(25, 'Newsflash', '', 2, 'top', 0, '0000-00-00 00:00:00', 0, 'mod_newsflash', 0, 0, 1, 'catid=3\r\nstyle=random\r\nitems=\r\nmoduleclass_sfx=', 0, 0, ''),
(26, 'Related Items', '', 10, 'left', 0, '0000-00-00 00:00:00', 0, 'mod_related_items', 0, 0, 1, '', 0, 0, ''),
(27, 'Search', '', 1, 'search', 0, '0000-00-00 00:00:00', 1, 'mod_search', 0, 0, 0, 'moduleclass_sfx=\nset_itemid=\nwidth=20\ntext=\nbutton=1\nbutton_pos=right\nimagebutton=1\nbutton_text=\ncache=1\ncache_time=900\n\n', 0, 0, ''),
(28, 'Random Image', '', 4, 'right', 0, '0000-00-00 00:00:00', 0, 'mod_random_image', 0, 0, 1, '', 0, 0, ''),
(29, 'Top Menu', '', 1, 'topmenu', 0, '0000-00-00 00:00:00', 0, 'mod_mainmenu', 0, 0, 0, 'menutype=topmenu\nmenu_style=list\nstartLevel=0\nendLevel=0\nshowAllChildren=0\nwindow_open=\ncache=1\nclass_sfx=-nav\nmoduleclass_sfx=\nmenu_images=0\nmenu_images_align=0\nexpand_menu=0\nactivate_parent=0\nfull_active_id=0\nindent_image=0\nindent_image1=-1\nindent_image2=-1\nindent_image3=-1\nindent_image4=-1\nindent_image5=-1\nindent_image6=-1\nspacer=\nend_spacer=\n\n', 1, 0, ''),
(30, 'Banners', '', 1, 'banner', 0, '0000-00-00 00:00:00', 0, 'mod_banners', 0, 0, 0, 'target=1\ncount=1\ncid=0\ncatid=0\ntag_search=0\nordering=0\nheader_text=\nfooter_text=\nmoduleclass_sfx=\ncache=1\ncache_time=900\n\n', 1, 0, ''),
(31, 'Other Menu', '', 0, 'left', 0, '0000-00-00 00:00:00', 1, 'mod_mainmenu', 0, 0, 0, 'menutype=othermenu\nmenu_style=list\nstartLevel=0\nendLevel=5\nshowAllChildren=1\nwindow_open=\nshow_whitespace=1\ncache=1\ntag_id=\nclass_sfx=\nmoduleclass_sfx=_menu\nmaxdepth=10\nmenu_images=0\nmenu_images_align=0\nmenu_images_link=0\nexpand_menu=0\nactivate_parent=0\nfull_active_id=0\nindent_image=0\nindent_image1=\nindent_image2=\nindent_image3=\nindent_image4=\nindent_image5=\nindent_image6=\nspacer=\nend_spacer=\n\n', 0, 0, ''),
(32, 'Wrapper', '', 11, 'left', 0, '0000-00-00 00:00:00', 0, 'mod_wrapper', 0, 0, 1, '', 0, 0, ''),
(33, 'Joomla Footer', '', 1, 'footer', 0, '0000-00-00 00:00:00', 0, 'mod_footer', 0, 0, 1, 'cache=1\n\n', 1, 0, ''),
(34, 'Feed Display', '', 12, 'left', 0, '0000-00-00 00:00:00', 0, 'mod_feed', 0, 0, 1, '', 1, 0, ''),
(35, 'Breadcrumbs', '', 1, 'breadcrumb', 0, '0000-00-00 00:00:00', 0, 'mod_breadcrumbs', 0, 0, 1, 'moduleclass_sfx=\ncache=0\nshowHome=1\nhomeText=Home\nshowComponent=1\nseparator=\n\n', 1, 0, ''),
(36, 'Syndication', '', 3, 'footer', 0, '0000-00-00 00:00:00', 1, 'mod_syndicate', 0, 0, 0, 'cache=0\ntext=Feed Entries\nformat=rss\nmoduleclass_sfx=\n\n', 1, 0, ''),
(37, 'Resources', '', 7, 'left', 0, '0000-00-00 00:00:00', 0, 'mod_mainmenu', 0, 0, 1, 'cache=1\nclass_sfx=\nmoduleclass_sfx=_menu\nmenutype=othermenu\nmenu_style=list\nstartLevel=0\nendLevel=0\nshowAllChildren=0\nfull_active_id=0\nmenu_images=0\nmenu_images_align=0\nexpand_menu=0\nactivate_parent=0\nindent_image=0\nindent_image1=\nindent_image2=\nindent_image3=\nindent_image4=\nindent_image5=\nindent_image6=\nspacer=\nend_spacer=\nwindow_open=\n\n', 0, 0, ''),
(38, 'Advertisement', '', 3, 'right', 0, '0000-00-00 00:00:00', 0, 'mod_banners', 0, 0, 1, 'count=4\r\nrandomise=0\r\ncid=0\r\ncatid=14\r\nheader_text=Featured Links:\r\nfooter_text=<a href="http://www.joomla.org">Ads by Joomla!</a>\r\nmoduleclass_sfx=_text\r\ncache=0\r\n\r\n', 0, 0, ''),
(39, 'Example Pages', '', 5, 'left', 0, '0000-00-00 00:00:00', 0, 'mod_mainmenu', 0, 0, 1, 'cache=1\nclass_sfx=\nmoduleclass_sfx=_menu\nmenutype=ExamplePages\nmenu_style=list_flat\nstartLevel=0\nendLevel=0\nshowAllChildren=0\nfull_active_id=0\nmenu_images=0\nmenu_images_align=0\nexpand_menu=0\nactivate_parent=0\nindent_image=0\nindent_image1=\nindent_image2=\nindent_image3=\nindent_image4=\nindent_image5=\nindent_image6=\nspacer=\nend_spacer=\nwindow_open=\n\n', 0, 0, ''),
(40, 'Key Concepts', '', 4, 'left', 0, '0000-00-00 00:00:00', 0, 'mod_mainmenu', 0, 0, 1, 'cache=1\nclass_sfx=\nmoduleclass_sfx=_menu\nmenutype=keyconcepts\nmenu_style=list\nstartLevel=0\nendLevel=0\nshowAllChildren=0\nfull_active_id=0\nmenu_images=0\nmenu_images_align=0\nexpand_menu=0\nactivate_parent=0\nindent_image=0\nindent_image1=\nindent_image2=\nindent_image3=\nindent_image4=\nindent_image5=\nindent_image6=\nspacer=\nend_spacer=\nwindow_open=\n\n', 0, 0, ''),
(41, 'Welcome to Joomla!', '<div style="padding: 5px"><p>Congratulations on choosing Joomla! as your content management system. We hope you are able to create a successful website with our program and maybe, you are able to give something back to the community later.</p><p>To make your start with Joomla! as smooth as possible, we want to give you some pointers to documentation, common questions and help on securing your server.</p><p>You should start with the &quot;<a href="http://forum.joomla.org/index.php/topic,47524.0.html" target="_blank">Beginners guide to Joomla!</a>&quot; and for securing your server, you should read this <a href="http://forum.joomla.org/index.php/topic,81058.0.html" target="_blank">security checklist</a>.</p><p>For your most common questions, you should first look in the <a href="http://forum.joomla.org" target="_blank">forum</a> and there especially into the <a href="http://forum.joomla.org/index.php/board,49.0.html" target="_blank">FAQ forum</a>. The forum is most likely the biggest resource on Joomla! there is and you will find almost every question answered at least once, so please first use the search function and then ask your question. <img alt="Smile" border="0" src="../plugins/editors/tinymce/jscripts/tiny_mce/plugins/emotions/images/smiley-smile.gif" title="Smile" /></p><p>Security is a big concern for us, which is why we would like you to subscribe to the <a href="http://forum.joomla.org/index.php/board,8.0.html" target="_blank">anouncenment forum</a> to always get the latest informations on new releases for Joomla! Also, you should regularly check the <a href="http://forum.joomla.org/index.php/board,267.0.html" target="_blank">security forum</a>.</p><p>We hope you have much fun and success with Joomla! and hope to see you in the forum among the hundreds and thousands of contributors.</p><p>Your Joomla! team</p><p>P.S.: To remove this message, delete the &quot;Welcome to Joomla!&quot;-module in the administrator screen of the module manager.</p></div>', 1, 'cpanel', 0, '0000-00-00 00:00:00', 1, 'mod_custom', 0, 2, 1, 'moduleclass_sfx=\n\n', 1, 1, ''),
(42, 'Sub Menu', '', 0, 'left', 0, '0000-00-00 00:00:00', 0, 'mod_mainmenu', 0, 0, 1, 'menutype=mainmenu\nmenu_style=list\nstartLevel=1\nendLevel=5\nshowAllChildren=1\nwindow_open=\nshow_whitespace=0\ncache=1\nclass_sfx=\nmoduleclass_sfx=_menu\nmenu_images=0\nmenu_images_align=0\nexpand_menu=0\nactivate_parent=0\nfull_active_id=0\nindent_image=0\nindent_image1=\nindent_image2=\nindent_image3=\nindent_image4=\nindent_image5=\nindent_image6=\nspacer=\nend_spacer=\n\n', 0, 0, ''),
(43, 'case Study', '<div style="margin-bottom: 5px">Here is Khalid Jabasini the hero of dubai </div><div class="width50 float-left"><div style="margin-top: 0px; background: #1e1e1e; height: 178px; border: #3c3c3c 1px solid; padding: 10px"><p><strong>check our case study to learn more </strong></p><p> <a href="index.php?option=com_content&task=view&id=18&Itemid=83">Click here!</a></p></div></div>', 0, 'user4', 0, '0000-00-00 00:00:00', 0, 'mod_custom', 0, 0, 1, 'moduleclass_sfx=\n\n', 0, 0, ''),
(95, 'YOOcarousel', '', 0, 'user6', 62, '2008-11-24 12:52:49', 1, 'mod_yoo_carousel', 0, 0, 0, 'catid=3\nstyle=basic\nmodule_width=720\nmodule_height=200\ntab_width=200\nautoplay=on\nslide_interval=10000\ntransition_duration=700\ntransition_effect=fade\ncontrol_panel=top\nrotate_action=click\nrotate_duration=200\nrotate_effect=scroll\nbuttons=1\norder=o_asc\nreadmore=0\nitems=4\nmoduleclass_sfx=-blank\ncache=0\ncache_time=900\n\n', 0, 0, ''),
(45, 'Advert 1', 'Lorem ipsum dolor sit amet, consect adipisicing elit, sed do eiusmod.', 1, 'advert1', 0, '0000-00-00 00:00:00', 1, 'mod_custom', 0, 0, 1, 'moduleclass_sfx=\n\n', 0, 0, ''),
(78, 'Advert 4', 'Lorem ipsum dolor sit amet, consect adipisicing elit, sed do eiusmod.', 1, 'advert4', 0, '0000-00-00 00:00:00', 1, 'mod_custom', 0, 0, 1, 'moduleclass_sfx=\n\n', 0, 0, ''),
(79, 'Advert 3', 'Lorem ipsum dolor sit amet, consect adipisicing elit, sed do eiusmod.', 1, 'advert3', 0, '0000-00-00 00:00:00', 1, 'mod_custom', 0, 0, 1, 'moduleclass_sfx=\n\n', 0, 0, ''),
(47, 'Advert 2', 'Lorem ipsum dolor sit amet, consect adipisicing elit, sed do eiusmod.', 1, 'advert2', 0, '0000-00-00 00:00:00', 1, 'mod_custom', 0, 0, 1, 'moduleclass_sfx=\n\n', 0, 0, ''),
(48, 'Bottom', '<p>about us l  contact l privacy policy</p>', 0, 'bottom', 0, '0000-00-00 00:00:00', 1, 'mod_custom', 0, 0, 0, 'moduleclass_sfx=\n\n', 0, 0, ''),
(96, 'user10', '<a href="http://validator.w3.org/check?uri=http://demo.yootheme.com/jun07" target="_blank"><img src="images/yootheme/validation_xhtml.png" border="0" alt="XHTML Validation" title="XHTML Validation" width="80" height="15" /></a> <br /><a href="http://jigsaw.w3.org/css-validator/validator?uri=http://demo.yootheme.com/jun07" target="_blank"><img src="images/yootheme/validation_css.png" border="0" alt="CSS Validation" title="CSS Validation" width="80" height="15" /></a> <br /><a href="http://www.yootheme.com" target="_blank"><img src="images/yootheme/validation_yoo.png" border="0" alt="Powerd by YOOtheme" title="Powerd by YOOtheme" width="80" height="15" /></a>', 0, 'user9', 0, '0000-00-00 00:00:00', 0, 'mod_custom', 0, 0, 0, 'moduleclass_sfx=\n\n', 0, 0, ''),
(49, 'Footer', 'Copyright E Marketing', 2, 'footer', 0, '0000-00-00 00:00:00', 1, 'mod_custom', 0, 0, 0, 'moduleclass_sfx=\n\n', 0, 0, ''),
(50, 'Left Firefox', '<center><a href="http://www.spreadfirefox.com/?q=affiliates&amp;id=198939&amp;t=213" target="_blank"><img class="reflect" border="0" alt="Firefox" title="Firefox" src="images/yootheme/left_spreadfirefox.gif"/></a></center>', 13, 'left', 0, '0000-00-00 00:00:00', 0, 'mod_custom', 0, 0, 0, 'moduleclass_sfx=-blank\n\n', 0, 0, ''),
(51, 'Additional Web 2.0 Features', '<div style="margin-top: 10px"><img class="correct-png" src="images/yootheme/left_image01.png" border="0" alt="Top Panel" title="Top Panel" width="40" height="40" align="left" /><strong>Top Panel</strong><br /><a href="index.php?option=com_content&task=view&id=33&Itemid=84" target="_blank">Read more...</a></div><div style="margin-top: 10px"><img class="correct-png" src="images/yootheme/left_image02.png" border="0" alt="Accordion Menu" title="Accordion Menu" width="40" height="40" align="left" /><strong>Accordion Menu</strong><br /><a href="index.php?option=com_content&task=view&id=34&Itemid=85" target="_blank">Read more...</a></div><div style="margin-top: 10px"><img class="correct-png" src="images/yootheme/left_image03.png" border="0" alt="Lightbox" title="Lightbox" width="40" height="40" align="left" /><strong>Lightbox</strong><br /><a href="index.php?option=com_content&task=view&id=20&Itemid=55" target="_blank">Read more...</a></div><div style="margin-top: 10px"><a href="index.php?option=com_content&task=view&id=29&Itemid=62" target="_blank"></a></div>', 14, 'left', 0, '0000-00-00 00:00:00', 0, 'mod_custom', 0, 0, 1, 'moduleclass_sfx=\n\n', 0, 0, ''),
(52, 'Left Joomla', '<center><a href="http://www.joomla.org" target="_blank"><img class="reflect" src="images/yootheme/left_joomla.gif" border="0" alt="Joomla" title="Joomla" /></a></center>', 17, 'left', 0, '0000-00-00 00:00:00', 0, 'mod_custom', 0, 0, 0, 'moduleclass_sfx=-blank\n\n', 0, 0, ''),
(53, 'Left Module', 'Standard Modules show up like this.', 18, 'left', 0, '0000-00-00 00:00:00', 1, 'mod_custom', 0, 0, 1, 'moduleclass_sfx=\n\n', 0, 0, ''),
(88, 'Left Module Black', 'Set Module Class Suffix element of the Module properties to "-black" to show up like this.', 19, 'left', 0, '0000-00-00 00:00:00', 0, 'mod_custom', 0, 0, 1, 'moduleclass_sfx=-black\n\n', 0, 0, ''),
(56, 'Left Module Black', 'Set Module Class Suffix element of the Module properties to "-black" to show up like this.', 3, 'left', 0, '0000-00-00 00:00:00', 1, 'mod_custom', 0, 0, 1, 'moduleclass_sfx=-black\n\n', 0, 0, ''),
(57, 'Left Module Blank', 'Set Module Class Suffix element of the Module properties to "-blank" to show up like this.', 20, 'left', 0, '0000-00-00 00:00:00', 1, 'mod_custom', 0, 0, 1, 'moduleclass_sfx=-blank\n\n', 0, 0, ''),
(58, 'Left Firebug', '<center><a href="https://addons.mozilla.org/de/firefox/addon/1843" target="_blank"><img class="reflect" src="images/yootheme/left_firebug.gif" border="0" alt="Firebug" title="Firebug" /></a></center>', 15, 'left', 0, '0000-00-00 00:00:00', 0, 'mod_custom', 0, 0, 0, 'moduleclass_sfx=-blank\n\n', 0, 0, ''),
(59, 'Right Module', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.', 5, 'right', 0, '0000-00-00 00:00:00', 1, 'mod_custom', 0, 0, 1, 'moduleclass_sfx=\n\n', 0, 0, ''),
(60, 'The Top Advertisers', 'please checcccccccc our adver <a href="index.php?option=com_content&task=view&id=41&Itemid=178">Learn more...</a>', 0, 'right', 0, '0000-00-00 00:00:00', 0, 'mod_custom', 0, 0, 1, 'moduleclass_sfx=\n\n', 0, 0, ''),
(61, 'User 1', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam. <strong>Standard Modules show up like this.</strong>', 2, 'user1', 0, '0000-00-00 00:00:00', 1, 'mod_custom', 0, 0, 1, 'moduleclass_sfx=\n\n', 0, 0, ''),
(62, 'Publishers ', '<p><span><span style="font-size: 12pt; font-family: ''Arial'',''sans-serif''"><font color="#ffffff">You can drive the world to your site where you can interact, learn about and captivate your audience</font></span></span></p>', 0, 'user2', 0, '0000-00-00 00:00:00', 1, 'mod_custom', 0, 0, 1, 'moduleclass_sfx=-intensive\n\n', 0, 0, ''),
(93, 'YOOgallery', '', 0, 'left', 0, '0000-00-00 00:00:00', 0, 'mod_yoo_gallery', 0, 0, 1, 'src=/images/stories/fruit/\nstyle=lightbox\neffect=fade\nthumb=default\norder=asc\nspotlight=1\nwidth=100\nheight=0\nresize=1\ncount=0\ntitle=\nprefix=thumb_\nthumb_cache_dir=thumbs\nthumb_cache_time=1440\nload_lightbox=1\nrel=\nmoduleclass_sfx=-blank\ncache=0\ncache_time=900\n\n', 0, 0, ''),
(63, 'User 2', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. <strong>Set Module Class Suffix element of the Module properties to "-intensive" to show up like this.</strong>', 2, 'user2', 0, '0000-00-00 00:00:00', 1, 'mod_custom', 0, 0, 1, 'moduleclass_sfx=-intensive\n\n', 0, 0, ''),
(64, 'eAdvertisers', '<p><span style="font-size: 12pt; font-family: ''Arial'',''sans-serif''"><span><font color="#ffffff"><font face="arial,helvetica,sans-serif">You can drive the world to your site where you can interact, learn about and captivate your audience.</font> </font></span></span></p>', 0, 'user3', 0, '0000-00-00 00:00:00', 1, 'mod_custom', 0, 0, 1, 'moduleclass_sfx=-bright\n\n', 0, 0, ''),
(65, 'User 3', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. <strong>Set Module Class Suffix element of the Module properties to "-bright" to show up like this.</strong>', 2, 'user3', 0, '0000-00-00 00:00:00', 1, 'mod_custom', 0, 0, 1, 'moduleclass_sfx=-bright\n\n', 0, 0, ''),
(67, 'User 4', 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat.', 1, 'user4', 0, '0000-00-00 00:00:00', 1, 'mod_custom', 0, 0, 1, 'moduleclass_sfx=\n\n', 0, 0, ''),
(68, 'User 4', '<img style="margin: 0px 10px 0px 0px" class="correct-png" src="images/yootheme/module_monitor.png" alt="" align="left" />Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. <strong>Standard Modules show up like this.</strong>', 2, 'user4', 0, '0000-00-00 00:00:00', 1, 'mod_custom', 0, 0, 1, 'moduleclass_sfx=\n\n', 0, 0, ''),
(70, 'User 6', '<div style="overflow: hidden;"><img style="margin: 10px 10px 0px 0px" class="correct-png" src="images/yootheme/module_hi.png" alt=" " align="left" /> Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum. <strong>Standard Modules show up like this.</strong></div>', 1, 'user6', 0, '0000-00-00 00:00:00', 1, 'mod_custom', 0, 0, 1, 'moduleclass_sfx=\n\n', 0, 0, ''),
(71, 'Thunderbird', '<div style="overflow: hidden;"><img class="correct-png" style="margin-right: 10px;" src="images/yootheme/mainbottom_user6.png" alt="Thunderbird" title="Thunderbird" width="80" height="80" align="left" />Mozilla Thunderbird is a free, cross-platform e-mail and news client developed by the Mozilla Foundation. <a href="#" target="_blank">Learn more.</a></div>', 2, 'user6', 0, '0000-00-00 00:00:00', 0, 'mod_custom', 0, 0, 1, 'moduleclass_sfx=\n\n', 0, 0, ''),
(72, 'User 6 Blank', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. <strong>Set Module Class Suffix element of the Module properties to "-blank" to show up like this.</strong>', 3, 'user6', 0, '0000-00-00 00:00:00', 1, 'mod_custom', 0, 0, 1, 'moduleclass_sfx=-blank\n\n', 0, 0, ''),
(73, 'Firefox', '<div style="overflow: hidden;"><img class="correct-png" style="margin-right: 10px;" src="images/yootheme/mainbottom_user7.png" alt="Firefox" title="Firefox" width="80" height="80" align="left" />Mozilla Firefox is a graphical web browser developed by the Mozilla Corporation and a large community of external contributors. <a href="#" target="_blank">Learn more.</a></div>', 1, 'user7', 0, '0000-00-00 00:00:00', 0, 'mod_custom', 0, 0, 1, 'moduleclass_sfx=\n\n', 0, 0, ''),
(74, 'User 7', '<div style="overflow: hidden;"><img style="margin: 10px 10px 0px 0px" class="correct-png" src="images/yootheme/module_paper.png" alt=" " align="left" />Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum. <strong>Standard Modules show up like this.</strong></div>', 2, 'user7', 0, '0000-00-00 00:00:00', 1, 'mod_custom', 0, 0, 1, 'moduleclass_sfx=\n\n', 0, 0, ''),
(75, 'User 8', '<a href="http://www.yootheme.com" target="_blank"><img class="correct-png" style="margin-top: 15px;" src="images/yootheme/yootheme_logo_footer.png" alt="Powerd by YOOtheme" title="Powerd by YOOtheme" width="150" height="33" /></a>', 1, 'user8', 0, '0000-00-00 00:00:00', 0, 'mod_custom', 0, 0, 0, 'moduleclass_sfx=\n\n', 0, 0, ''),
(76, 'User 9', '<a href="http://validator.w3.org/check?uri=http://demo.yootheme.com/jun07" target="_blank"><img src="images/yootheme/validation_xhtml.png" alt="XHTML Validation" title="XHTML Validation" width="80" height="15" /></a>\r\n<br />\r\n<a href="http://jigsaw.w3.org/css-validator/validator?uri=http://demo.yootheme.com/jun07" target="_blank"><img src="images/yootheme/validation_css.png" alt="CSS Validation" title="CSS Validation" width="80" height="15" /></a>\r\n<br />\r\n<a href="http://www.yootheme.com" target="_blank"><img src="images/yootheme/validation_yoo.png" alt="Powerd by YOOtheme" title="Powerd by YOOtheme" width="80" height="15" /></a>\r\n<br />', 2, 'user9', 0, '0000-00-00 00:00:00', 0, 'mod_custom', 0, 0, 0, 'moduleclass_sfx=\n\n', 0, 0, ''),
(77, 'User 5', 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat.', 1, 'user5', 0, '0000-00-00 00:00:00', 1, 'mod_custom', 0, 0, 1, 'moduleclass_sfx=\n\n', 0, 0, ''),
(81, 'Badge', '', 2, 'banner', 0, '0000-00-00 00:00:00', 0, 'mod_custom', 0, 0, 0, 'moduleclass_sfx=\n\n', 0, 0, ''),
(82, 'Header Image Red', '<img src="images/yootheme/header_image_red.jpg" alt="YOOtheme" />', 1, 'header', 0, '0000-00-00 00:00:00', 1, 'mod_custom', 0, 0, 0, 'moduleclass_sfx=\n\n', 0, 0, ''),
(83, 'Header Image Green', '<img src="images/yootheme/header_image_green.jpg" alt="YOOtheme" />', 5, 'header', 0, '0000-00-00 00:00:00', 1, 'mod_custom', 0, 0, 0, 'moduleclass_sfx=\n\n', 0, 0, ''),
(84, 'Header Image Blue', '<img src="images/yootheme/header_image_blue.jpg" alt="YOOtheme" />', 4, 'header', 0, '0000-00-00 00:00:00', 1, 'mod_custom', 0, 0, 0, 'moduleclass_sfx=\n\n', 0, 0, ''),
(85, 'Header Image Orange', '<img src="images/yootheme/header_image_orange.jpg" border="0" alt="YOOtheme" />', 3, 'header', 0, '0000-00-00 00:00:00', 1, 'mod_custom', 0, 0, 0, 'moduleclass_sfx=\n\n', 0, 0, ''),
(86, 'Header Image White', '<img src="images/yootheme/header_image_white.jpg" alt="YOOtheme" />', 2, 'header', 0, '0000-00-00 00:00:00', 1, 'mod_custom', 0, 0, 0, 'moduleclass_sfx=\n\n', 0, 0, ''),
(87, 'Latest News', '', 16, 'user6', 0, '0000-00-00 00:00:00', 0, 'mod_latestnews', 0, 0, 1, 'count=5\nordering=c_dsc\nuser_id=0\nshow_front=1\nsecid=\ncatid=\nmoduleclass_sfx=-black\ncache=1\ncache_time=900\n\n', 0, 0, ''),
(91, 'YOOslider Horizontal', '', 0, 'left', 0, '0000-00-00 00:00:00', 0, 'mod_yoo_slider', 0, 0, 0, 'catid=1\nstyle=default-v\nitem_size=171\nitem_expanded=310\norder=o_asc\nreadmore=0\nitems=4\nmodule_height=153\nmoduleclass_sfx=-blank\ncache=0\ncache_time=900\n\n', 0, 0, ''),
(90, 'first page left scroller', '', 0, 'right', 0, '0000-00-00 00:00:00', 1, 'mod_yoo_slider', 0, 0, 0, 'catid=33\nstyle=default-v\nitem_size=120\nitem_expanded=250\norder=o_asc\nreadmore=0\nitems=3\nmodule_height=150\nmoduleclass_sfx=-slider\ncache=0\ncache_time=900\n\n', 0, 0, ''),
(92, 'Channels', '<font face="arial,helvetica,sans-serif"><span style="font-family: ''Arial'',''sans-serif''"><font color="#ffffff"><font color="#ffffff"><span style="font-size: 11pt; font-family: ''Arial'',''sans-serif''"> </span><span style="font-size: 11pt; font-family: ''Arial'',''sans-serif''">We work with the Arabic Worlds leading advertisers and their logo''s keeping a healthy mix across industry sectors.</span></font></font></span></font>', 0, 'user1', 0, '0000-00-00 00:00:00', 1, 'mod_custom', 0, 0, 1, 'moduleclass_sfx=\n\n', 0, 0, ''),
(94, 'YOOscroller', '', 0, 'user6', 0, '0000-00-00 00:00:00', 0, 'mod_yoo_scroller', 0, 0, 1, 'catid=31\nstyle=default-h\nmodule_width=600\nmodule_height=200\nslide_size=200\nslide_interval=10000\nautoplay=1\norder=o_asc\nreadmore=0\nitems=4\nmoduleclass_sfx=-blank\ncache=0\ncache_time=900\n\n', 0, 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `jos_modules_menu`
--

CREATE TABLE IF NOT EXISTS `jos_modules_menu` (
  `moduleid` int(11) NOT NULL default '0',
  `menuid` int(11) NOT NULL default '0',
  PRIMARY KEY  (`moduleid`,`menuid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `jos_modules_menu`
--

INSERT INTO `jos_modules_menu` (`moduleid`, `menuid`) VALUES
(1, 0),
(16, 1),
(17, 0),
(18, 1),
(18, 2),
(18, 27),
(18, 34),
(18, 37),
(18, 41),
(18, 48),
(18, 49),
(18, 50),
(18, 51),
(18, 52),
(18, 53),
(18, 54),
(18, 58),
(18, 59),
(18, 60),
(18, 69),
(18, 70),
(18, 71),
(18, 72),
(18, 73),
(18, 74),
(18, 76),
(18, 77),
(18, 78),
(18, 79),
(18, 80),
(18, 81),
(18, 82),
(18, 83),
(18, 84),
(18, 85),
(18, 86),
(18, 87),
(18, 88),
(18, 90),
(18, 91),
(18, 92),
(18, 93),
(18, 94),
(18, 95),
(18, 97),
(18, 98),
(18, 99),
(18, 100),
(18, 101),
(18, 102),
(18, 103),
(18, 104),
(18, 105),
(18, 106),
(18, 107),
(18, 108),
(18, 109),
(18, 110),
(18, 111),
(18, 112),
(18, 113),
(18, 114),
(18, 115),
(18, 116),
(18, 117),
(18, 118),
(18, 119),
(18, 120),
(18, 124),
(18, 125),
(18, 126),
(18, 127),
(18, 128),
(18, 129),
(18, 140),
(19, 50),
(21, 54),
(22, 50),
(25, 0),
(27, 1),
(27, 2),
(27, 27),
(27, 34),
(27, 37),
(27, 41),
(27, 48),
(27, 49),
(27, 50),
(27, 51),
(27, 52),
(27, 53),
(27, 54),
(27, 58),
(27, 59),
(27, 60),
(27, 61),
(27, 62),
(27, 63),
(27, 64),
(27, 65),
(27, 66),
(27, 67),
(27, 68),
(27, 69),
(27, 70),
(27, 71),
(27, 72),
(27, 73),
(27, 74),
(27, 75),
(27, 76),
(27, 77),
(27, 78),
(27, 79),
(27, 80),
(27, 81),
(27, 82),
(27, 83),
(27, 84),
(27, 85),
(27, 86),
(27, 87),
(27, 88),
(27, 90),
(27, 91),
(27, 92),
(27, 93),
(27, 94),
(27, 96),
(27, 97),
(29, 0),
(30, 1),
(30, 2),
(30, 27),
(30, 34),
(30, 37),
(30, 41),
(30, 48),
(30, 49),
(30, 50),
(30, 51),
(30, 52),
(30, 53),
(30, 54),
(30, 58),
(30, 59),
(30, 60),
(30, 69),
(30, 70),
(30, 71),
(30, 72),
(30, 73),
(30, 74),
(30, 76),
(30, 77),
(30, 78),
(30, 79),
(30, 80),
(30, 81),
(30, 82),
(30, 83),
(30, 84),
(30, 85),
(30, 86),
(30, 87),
(30, 88),
(30, 90),
(30, 91),
(30, 92),
(30, 93),
(30, 94),
(30, 95),
(30, 96),
(30, 97),
(30, 98),
(30, 99),
(30, 100),
(30, 101),
(30, 102),
(30, 103),
(30, 104),
(30, 105),
(30, 106),
(30, 107),
(30, 108),
(30, 109),
(30, 110),
(30, 111),
(30, 112),
(30, 113),
(30, 114),
(30, 115),
(30, 116),
(30, 117),
(30, 118),
(30, 119),
(30, 120),
(30, 124),
(30, 125),
(30, 126),
(30, 127),
(30, 128),
(30, 140),
(31, 0),
(32, 0),
(33, 0),
(34, 0),
(35, 0),
(36, 0),
(40, 0),
(42, 1),
(42, 2),
(42, 27),
(42, 34),
(42, 37),
(42, 41),
(42, 48),
(42, 49),
(42, 50),
(42, 51),
(42, 53),
(42, 54),
(42, 58),
(42, 59),
(42, 60),
(42, 69),
(42, 70),
(42, 71),
(42, 72),
(42, 73),
(42, 74),
(42, 76),
(42, 77),
(42, 78),
(42, 79),
(42, 80),
(42, 81),
(42, 82),
(42, 83),
(42, 84),
(42, 85),
(42, 86),
(42, 87),
(42, 88),
(42, 90),
(42, 91),
(42, 92),
(42, 93),
(42, 94),
(42, 95),
(42, 96),
(42, 97),
(42, 98),
(42, 99),
(42, 100),
(42, 101),
(42, 102),
(42, 103),
(42, 104),
(42, 105),
(42, 119),
(42, 124),
(42, 125),
(42, 126),
(42, 127),
(42, 128),
(42, 129),
(42, 140),
(42, 141),
(42, 142),
(43, 0),
(45, 86),
(45, 90),
(45, 127),
(47, 86),
(47, 90),
(47, 127),
(48, 1),
(48, 2),
(48, 27),
(48, 34),
(48, 37),
(48, 41),
(48, 48),
(48, 49),
(48, 50),
(48, 51),
(48, 52),
(48, 53),
(48, 54),
(48, 58),
(48, 59),
(48, 60),
(48, 69),
(48, 70),
(48, 71),
(48, 72),
(48, 73),
(48, 74),
(48, 76),
(48, 77),
(48, 78),
(48, 79),
(48, 80),
(48, 81),
(48, 82),
(48, 83),
(48, 84),
(48, 85),
(48, 86),
(48, 87),
(48, 88),
(48, 90),
(48, 91),
(48, 92),
(48, 93),
(48, 95),
(48, 96),
(48, 97),
(48, 100),
(48, 101),
(48, 102),
(48, 103),
(48, 104),
(48, 105),
(48, 119),
(48, 124),
(48, 125),
(48, 126),
(48, 127),
(48, 128),
(48, 129),
(48, 141),
(49, 0),
(50, 54),
(51, 54),
(52, 54),
(53, 92),
(56, 92),
(57, 92),
(58, 54),
(59, 81),
(59, 82),
(59, 83),
(59, 84),
(59, 85),
(59, 86),
(59, 87),
(59, 88),
(59, 90),
(59, 91),
(59, 92),
(59, 93),
(59, 94),
(59, 95),
(59, 96),
(59, 97),
(60, 0),
(61, 82),
(61, 83),
(62, 54),
(63, 82),
(63, 83),
(64, 54),
(65, 82),
(67, 85),
(68, 87),
(68, 90),
(70, 87),
(70, 90),
(71, 54),
(72, 91),
(73, 54),
(74, 87),
(75, 1),
(75, 2),
(75, 27),
(75, 34),
(75, 37),
(75, 41),
(75, 48),
(75, 49),
(75, 50),
(75, 51),
(75, 52),
(75, 53),
(75, 54),
(75, 58),
(75, 59),
(75, 60),
(75, 61),
(75, 62),
(75, 63),
(75, 64),
(75, 65),
(75, 66),
(75, 67),
(75, 68),
(75, 69),
(75, 70),
(75, 71),
(75, 72),
(75, 73),
(75, 74),
(75, 75),
(75, 76),
(75, 77),
(75, 78),
(75, 79),
(75, 80),
(75, 81),
(75, 82),
(75, 83),
(75, 84),
(75, 85),
(75, 86),
(75, 87),
(75, 88),
(75, 90),
(75, 91),
(75, 92),
(75, 93),
(75, 95),
(75, 96),
(75, 97),
(76, 1),
(76, 2),
(76, 27),
(76, 34),
(76, 37),
(76, 41),
(76, 48),
(76, 49),
(76, 50),
(76, 51),
(76, 52),
(76, 53),
(76, 54),
(76, 58),
(76, 59),
(76, 60),
(76, 61),
(76, 62),
(76, 63),
(76, 64),
(76, 65),
(76, 66),
(76, 67),
(76, 68),
(76, 69),
(76, 70),
(76, 71),
(76, 72),
(76, 73),
(76, 74),
(76, 75),
(76, 76),
(76, 77),
(76, 78),
(76, 79),
(76, 80),
(76, 81),
(76, 82),
(76, 83),
(76, 84),
(76, 85),
(76, 86),
(76, 87),
(76, 88),
(76, 90),
(76, 91),
(76, 92),
(76, 95),
(76, 96),
(76, 97),
(77, 85),
(78, 127),
(79, 127),
(81, 1),
(81, 2),
(81, 27),
(81, 34),
(81, 37),
(81, 41),
(81, 48),
(81, 49),
(81, 50),
(81, 51),
(81, 52),
(81, 53),
(81, 54),
(81, 58),
(81, 59),
(81, 60),
(81, 69),
(81, 70),
(81, 71),
(81, 72),
(81, 73),
(81, 74),
(81, 76),
(81, 77),
(81, 78),
(81, 79),
(81, 80),
(81, 81),
(81, 82),
(81, 83),
(81, 84),
(81, 85),
(81, 86),
(81, 87),
(81, 88),
(81, 90),
(81, 91),
(81, 92),
(81, 93),
(81, 94),
(81, 95),
(81, 96),
(81, 97),
(81, 98),
(81, 99),
(81, 100),
(81, 101),
(81, 102),
(81, 103),
(81, 104),
(81, 105),
(81, 119),
(81, 124),
(81, 125),
(81, 126),
(81, 127),
(81, 128),
(81, 140),
(81, 141),
(81, 142),
(82, 54),
(82, 98),
(82, 99),
(82, 100),
(82, 101),
(82, 102),
(82, 103),
(82, 104),
(82, 105),
(82, 140),
(82, 142),
(83, 53),
(83, 81),
(83, 82),
(83, 83),
(83, 84),
(83, 85),
(83, 86),
(83, 87),
(83, 88),
(83, 90),
(83, 91),
(83, 92),
(83, 93),
(83, 94),
(83, 95),
(83, 96),
(83, 97),
(83, 127),
(83, 128),
(83, 129),
(84, 51),
(84, 58),
(84, 59),
(84, 60),
(84, 69),
(84, 70),
(84, 71),
(84, 72),
(84, 73),
(84, 74),
(84, 76),
(84, 77),
(84, 78),
(84, 79),
(84, 80),
(84, 119),
(84, 124),
(84, 125),
(84, 126),
(84, 141),
(85, 51),
(85, 58),
(85, 59),
(85, 60),
(85, 69),
(85, 70),
(85, 71),
(85, 72),
(85, 73),
(85, 74),
(85, 76),
(85, 77),
(85, 78),
(85, 79),
(85, 80),
(85, 119),
(85, 124),
(85, 125),
(85, 126),
(85, 141),
(86, 1),
(86, 2),
(86, 27),
(86, 34),
(86, 37),
(86, 41),
(86, 48),
(86, 49),
(86, 50),
(87, 0),
(88, 92),
(90, 54),
(90, 100),
(90, 101),
(90, 102),
(90, 103),
(90, 104),
(90, 105),
(90, 141),
(91, 51),
(92, 0),
(93, 54),
(94, 0),
(95, 0),
(96, 1),
(96, 2),
(96, 27),
(96, 34),
(96, 37),
(96, 41),
(96, 48),
(96, 49),
(96, 50),
(96, 51),
(96, 52),
(96, 53),
(96, 54),
(96, 58),
(96, 59),
(96, 60),
(96, 69),
(96, 70),
(96, 71),
(96, 72),
(96, 73),
(96, 74),
(96, 76),
(96, 77),
(96, 78),
(96, 79),
(96, 80),
(96, 81),
(96, 82),
(96, 83),
(96, 84),
(96, 85),
(96, 86),
(96, 87),
(96, 88),
(96, 90),
(96, 91),
(96, 92),
(96, 95),
(96, 96),
(96, 97);

-- --------------------------------------------------------

--
-- Table structure for table `jos_newsfeeds`
--

CREATE TABLE IF NOT EXISTS `jos_newsfeeds` (
  `catid` int(11) NOT NULL default '0',
  `id` int(11) NOT NULL auto_increment,
  `name` text NOT NULL,
  `alias` varchar(255) NOT NULL default '',
  `link` text NOT NULL,
  `filename` varchar(200) default NULL,
  `published` tinyint(1) NOT NULL default '0',
  `numarticles` int(11) unsigned NOT NULL default '1',
  `cache_time` int(11) unsigned NOT NULL default '3600',
  `checked_out` tinyint(3) unsigned NOT NULL default '0',
  `checked_out_time` datetime NOT NULL default '0000-00-00 00:00:00',
  `ordering` int(11) NOT NULL default '0',
  `rtl` tinyint(4) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `published` (`published`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `jos_newsfeeds`
--

INSERT INTO `jos_newsfeeds` (`catid`, `id`, `name`, `alias`, `link`, `filename`, `published`, `numarticles`, `cache_time`, `checked_out`, `checked_out_time`, `ordering`, `rtl`) VALUES
(4, 1, 'Joomla! - Official News', 'joomla-official-news', 'http://www.joomla.org/index.php?option=com_rss_xtd&feed=RSS2.0&type=com_frontpage&Itemid=1', '', 1, 5, 3600, 0, '0000-00-00 00:00:00', 8, 0),
(4, 2, 'Joomla! - Community News', 'joomla-community-news', 'http://www.joomla.org/index.php?option=com_rss_xtd&feed=RSS2.0&type=com_content&task=blogcategory&id=0&Itemid=33', '', 1, 5, 3600, 0, '0000-00-00 00:00:00', 9, 0),
(4, 3, 'OpenSourceMatters', 'opensourcematters', 'http://www.opensourcematters.org/index2.php?option=com_rss&feed=RSS2.0&no_html=1', '', 1, 5, 3600, 0, '0000-00-00 00:00:00', 10, 0),
(6, 4, 'Linux Today', 'linux-today', 'http://linuxtoday.com/backend/my-netscape.rdf', '', 1, 3, 3600, 0, '0000-00-00 00:00:00', 1, 0),
(5, 5, 'Business News', 'business-news', 'http://headlines.internet.com/internetnews/bus-news/news.rss', '', 1, 3, 3600, 0, '0000-00-00 00:00:00', 2, 0),
(7, 6, 'Web Developer News', 'web-developer-news', 'http://headlines.internet.com/internetnews/wd-news/news.rss', '', 1, 3, 3600, 0, '0000-00-00 00:00:00', 3, 0),
(6, 7, 'Linux Central:New Products', 'linux-central-news-products', 'http://linuxcentral.com/backend/lcnew.rdf', '', 1, 3, 3600, 0, '0000-00-00 00:00:00', 4, 0),
(6, 8, 'Linux Central:Best Selling', 'linux-central-best-selling', 'http://linuxcentral.com/backend/lcbestns.rdf', '', 1, 3, 3600, 0, '0000-00-00 00:00:00', 5, 0),
(6, 9, 'Linux Central:Daily Specials', 'linux-central-daily-specials', 'http://linuxcentral.com/backend/lcspecialns.rdf', '', 1, 3, 3600, 0, '0000-00-00 00:00:00', 6, 0);

-- --------------------------------------------------------

--
-- Table structure for table `jos_plugins`
--

CREATE TABLE IF NOT EXISTS `jos_plugins` (
  `id` int(11) NOT NULL auto_increment,
  `name` text NOT NULL,
  `element` text NOT NULL,
  `folder` varchar(100) NOT NULL default '',
  `access` tinyint(3) unsigned NOT NULL default '0',
  `ordering` int(11) NOT NULL default '0',
  `published` tinyint(3) NOT NULL default '0',
  `iscore` tinyint(3) NOT NULL default '0',
  `client_id` tinyint(3) NOT NULL default '0',
  `checked_out` int(11) unsigned NOT NULL default '0',
  `checked_out_time` datetime NOT NULL default '0000-00-00 00:00:00',
  `params` text NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `idx_folder` (`published`,`client_id`,`access`,`folder`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=33 ;

--
-- Dumping data for table `jos_plugins`
--

INSERT INTO `jos_plugins` (`id`, `name`, `element`, `folder`, `access`, `ordering`, `published`, `iscore`, `client_id`, `checked_out`, `checked_out_time`, `params`) VALUES
(1, 'Authentication - Joomla', 'joomla', 'authentication', 0, 1, 1, 1, 0, 0, '0000-00-00 00:00:00', ''),
(2, 'Authentication - LDAP', 'ldap', 'authentication', 0, 2, 0, 1, 0, 0, '0000-00-00 00:00:00', 'host=\nport=389\nuse_ldapV3=0\nnegotiate_tls=0\nno_referrals=0\nauth_method=bind\nbase_dn=\nsearch_string=\nusers_dn=\nusername=\npassword=\nldap_fullname=fullName\nldap_email=mail\nldap_uid=uid\n\n'),
(3, 'Authentication - GMail', 'gmail', 'authentication', 0, 4, 0, 0, 0, 0, '0000-00-00 00:00:00', ''),
(4, 'Authentication - OpenID', 'openid', 'authentication', 0, 3, 0, 0, 0, 0, '0000-00-00 00:00:00', ''),
(5, 'User - Joomla!', 'joomla', 'user', 0, 0, 1, 0, 0, 0, '0000-00-00 00:00:00', 'autoregister=1\n\n'),
(6, 'Search - Content', 'content', 'search', 0, 1, 1, 1, 0, 0, '0000-00-00 00:00:00', 'search_limit=50\nsearch_content=1\nsearch_uncategorised=1\nsearch_archived=1\n\n'),
(7, 'Search - Contacts', 'contacts', 'search', 0, 3, 1, 1, 0, 0, '0000-00-00 00:00:00', 'search_limit=50\n\n'),
(8, 'Search - Categories', 'categories', 'search', 0, 4, 1, 0, 0, 0, '0000-00-00 00:00:00', 'search_limit=50\n\n'),
(9, 'Search - Sections', 'sections', 'search', 0, 5, 1, 0, 0, 0, '0000-00-00 00:00:00', 'search_limit=50\n\n'),
(10, 'Search - Newsfeeds', 'newsfeeds', 'search', 0, 6, 1, 0, 0, 0, '0000-00-00 00:00:00', 'search_limit=50\n\n'),
(11, 'Search - Weblinks', 'weblinks', 'search', 0, 2, 1, 1, 0, 0, '0000-00-00 00:00:00', 'search_limit=50\n\n'),
(12, 'Content - Pagebreak', 'pagebreak', 'content', 0, 10000, 1, 1, 0, 0, '0000-00-00 00:00:00', 'enabled=1\ntitle=1\nmultipage_toc=1\nshowall=1\n\n'),
(13, 'Content - SEF', 'sef', 'content', 0, 3, 1, 0, 0, 0, '0000-00-00 00:00:00', ''),
(14, 'Content - Rating', 'vote', 'content', 0, 4, 1, 1, 0, 0, '0000-00-00 00:00:00', ''),
(15, 'Content - Email Cloaking', 'emailcloak', 'content', 0, 5, 1, 0, 0, 0, '0000-00-00 00:00:00', 'mode=1\n\n'),
(16, 'Content - Code Hightlighter (GeSHi)', 'geshi', 'content', 0, 5, 0, 0, 0, 0, '0000-00-00 00:00:00', ''),
(17, 'Content - Load Module', 'loadmodule', 'content', 0, 6, 1, 0, 0, 0, '0000-00-00 00:00:00', 'enabled=1\nstyle=0\n\n'),
(18, 'Content - Page Navigation', 'pagenavigation', 'content', 0, 2, 1, 1, 0, 0, '0000-00-00 00:00:00', 'position=1\n\n'),
(19, 'Editor - No Editor', 'none', 'editors', 0, 0, 1, 1, 0, 0, '0000-00-00 00:00:00', ''),
(20, 'Editor - TinyMCE 2.0', 'tinymce', 'editors', 0, 0, 1, 1, 0, 0, '0000-00-00 00:00:00', 'theme=advanced\ncleanup=1\ncleanup_startup=0\nautosave=0\ncompressed=0\nrelative_urls=1\ntext_direction=ltr\nlang_mode=0\nlang_code=en\ninvalid_elements=applet\ncontent_css=1\ncontent_css_custom=\nnewlines=0\ntoolbar=top\nhr=1\nsmilies=1\ntable=1\nstyle=1\nlayer=1\nxhtmlxtras=0\ntemplate=0\ndirectionality=1\nfullscreen=1\nhtml_height=550\nhtml_width=750\npreview=1\ninsertdate=1\nformat_date=%Y-%m-%d\ninserttime=1\nformat_time=%H:%M:%S\n\n'),
(21, 'Editor - XStandard Lite 1.7', 'xstandard', 'editors', 0, 0, 1, 1, 0, 0, '0000-00-00 00:00:00', ''),
(22, 'Editor Button - Image', 'image', 'editors-xtd', 0, 0, 1, 0, 0, 0, '0000-00-00 00:00:00', ''),
(23, 'Editor Button - Pagebreak', 'pagebreak', 'editors-xtd', 0, 0, 1, 0, 0, 0, '0000-00-00 00:00:00', ''),
(24, 'Editor Button - Readmore', 'readmore', 'editors-xtd', 0, 0, 1, 0, 0, 0, '0000-00-00 00:00:00', ''),
(25, 'XML-RPC - Joomla', 'joomla', 'xmlrpc', 0, 7, 0, 1, 0, 0, '0000-00-00 00:00:00', ''),
(26, 'XML-RPC - Blogger API', 'blogger', 'xmlrpc', 0, 7, 0, 1, 0, 0, '0000-00-00 00:00:00', 'catid=1\nsectionid=0\n\n'),
(28, 'System - Debug', 'debug', 'system', 0, 1, 1, 0, 0, 0, '0000-00-00 00:00:00', 'queries=1\nmemory=1\nlangauge=1\n\n'),
(29, 'System - Legacy', 'legacy', 'system', 0, 2, 1, 1, 0, 0, '0000-00-00 00:00:00', 'route=0\n\n'),
(30, 'System - Cache', 'cache', 'system', 0, 3, 0, 1, 0, 0, '0000-00-00 00:00:00', 'browsercache=0\ncachetime=15\n\n'),
(31, 'System - Log', 'log', 'system', 0, 4, 0, 1, 0, 0, '0000-00-00 00:00:00', ''),
(32, 'System - Remember Me', 'remember', 'system', 0, 5, 1, 1, 0, 0, '0000-00-00 00:00:00', '');

-- --------------------------------------------------------

--
-- Table structure for table `jos_polls`
--

CREATE TABLE IF NOT EXISTS `jos_polls` (
  `id` int(11) unsigned NOT NULL auto_increment,
  `title` text NOT NULL,
  `alias` varchar(255) NOT NULL default '',
  `voters` int(9) NOT NULL default '0',
  `checked_out` int(11) NOT NULL default '0',
  `checked_out_time` datetime NOT NULL default '0000-00-00 00:00:00',
  `published` tinyint(1) NOT NULL default '0',
  `access` int(11) NOT NULL default '0',
  `lag` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `jos_polls`
--

INSERT INTO `jos_polls` (`id`, `title`, `alias`, `voters`, `checked_out`, `checked_out_time`, `published`, `access`, `lag`) VALUES
(15, 'Which feature do you like the most?', 'which-feature-do-you-like-the-most', 0, 0, '0000-00-00 00:00:00', 1, 0, 86400);

-- --------------------------------------------------------

--
-- Table structure for table `jos_poll_data`
--

CREATE TABLE IF NOT EXISTS `jos_poll_data` (
  `id` int(11) NOT NULL auto_increment,
  `pollid` int(11) NOT NULL default '0',
  `text` text NOT NULL,
  `hits` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `pollid` (`pollid`,`text`(1))
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=25 ;

--
-- Dumping data for table `jos_poll_data`
--

INSERT INTO `jos_poll_data` (`id`, `pollid`, `text`, `hits`) VALUES
(21, 15, '', 0),
(20, 15, '', 0),
(19, 15, '', 0),
(18, 15, '', 0),
(17, 15, 'Tableless CSS Design', 0),
(16, 15, 'Top Panel', 0),
(15, 15, 'Accordion Menu', 0),
(14, 15, 'Drop Down Menu', 0),
(13, 15, 'Tab Menu', 0),
(22, 15, '', 0),
(23, 15, '', 0),
(24, 15, '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `jos_poll_date`
--

CREATE TABLE IF NOT EXISTS `jos_poll_date` (
  `id` bigint(20) NOT NULL auto_increment,
  `date` datetime NOT NULL default '0000-00-00 00:00:00',
  `vote_id` int(11) NOT NULL default '0',
  `poll_id` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `poll_id` (`poll_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `jos_poll_date`
--

INSERT INTO `jos_poll_date` (`id`, `date`, `vote_id`, `poll_id`) VALUES
(1, '2006-10-09 13:01:58', 1, 14),
(2, '2006-10-10 15:19:43', 7, 14),
(3, '2006-10-11 11:08:16', 7, 14),
(4, '2006-10-11 15:02:26', 2, 14),
(5, '2006-10-11 15:43:03', 7, 14),
(6, '2006-10-11 15:43:38', 7, 14),
(7, '2006-10-12 00:51:13', 2, 14);

-- --------------------------------------------------------

--
-- Table structure for table `jos_poll_menu`
--

CREATE TABLE IF NOT EXISTS `jos_poll_menu` (
  `pollid` int(11) NOT NULL default '0',
  `menuid` int(11) NOT NULL default '0',
  PRIMARY KEY  (`pollid`,`menuid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `jos_poll_menu`
--


-- --------------------------------------------------------

--
-- Table structure for table `jos_sections`
--

CREATE TABLE IF NOT EXISTS `jos_sections` (
  `id` int(11) NOT NULL auto_increment,
  `title` text NOT NULL,
  `name` text NOT NULL,
  `alias` varchar(255) NOT NULL default '',
  `image` text NOT NULL,
  `scope` varchar(50) NOT NULL default '',
  `image_position` varchar(90) NOT NULL default '',
  `description` text NOT NULL,
  `published` tinyint(1) NOT NULL default '0',
  `checked_out` int(11) unsigned NOT NULL default '0',
  `checked_out_time` datetime NOT NULL default '0000-00-00 00:00:00',
  `ordering` int(11) NOT NULL default '0',
  `access` tinyint(3) unsigned NOT NULL default '0',
  `count` int(11) NOT NULL default '0',
  `params` text NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `idx_scope` (`scope`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `jos_sections`
--

INSERT INTO `jos_sections` (`id`, `title`, `name`, `alias`, `image`, `scope`, `image_position`, `description`, `published`, `checked_out`, `checked_out_time`, `ordering`, `access`, `count`, `params`) VALUES
(1, 'News', '', 'news', 'articles.jpg', 'content', 'right', 'Select a news topic from the list below, then select a news article to read.', 1, 0, '0000-00-00 00:00:00', 3, 0, 2, ''),
(3, 'FAQs', '', 'faqs', 'key.jpg', 'content', 'left', 'From the list below choose one of our FAQs topics, then select an FAQ to read. If you have a question which is not in this section, please contact us.', 1, 0, '0000-00-00 00:00:00', 5, 0, 22, ''),
(4, 'About Joomla!', '', 'about-joomla', '', 'content', 'left', '', 1, 0, '0000-00-00 00:00:00', 2, 0, 15, ''),
(5, 'YOOslider', '', 'yooslider', '', 'content', 'left', '', 1, 0, '0000-00-00 00:00:00', 6, 0, 2, '');

-- --------------------------------------------------------

--
-- Table structure for table `jos_session`
--

CREATE TABLE IF NOT EXISTS `jos_session` (
  `username` varchar(150) default '',
  `time` varchar(14) default '',
  `session_id` varchar(200) NOT NULL default '0',
  `guest` tinyint(4) default '1',
  `userid` int(11) default '0',
  `usertype` varchar(150) default '',
  `gid` tinyint(3) unsigned NOT NULL default '0',
  `client_id` tinyint(3) unsigned NOT NULL default '0',
  `data` text,
  PRIMARY KEY  (`session_id`),
  KEY `whosonline` (`guest`,`usertype`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `jos_session`
--

INSERT INTO `jos_session` (`username`, `time`, `session_id`, `guest`, `userid`, `usertype`, `gid`, `client_id`, `data`) VALUES
('', '1230638493', 'a4c611677825cd3a3d2095bba060bbae', 1, 0, '', 0, 0, '__default|a:9:{s:15:"session.counter";i:2;s:19:"session.timer.start";i:1230638377;s:18:"session.timer.last";i:1230638377;s:17:"session.timer.now";i:1230638493;s:24:"session.client.forwarded";s:15:"217.164.223.201";s:22:"session.client.browser";s:90:"Mozilla/5.0 (Windows; U; Windows NT 6.0; en-GB; rv:1.9.0.5) Gecko/2008120122 Firefox/3.0.5";s:8:"registry";O:9:"JRegistry":3:{s:17:"_defaultNameSpace";s:7:"session";s:9:"_registry";a:1:{s:7:"session";a:1:{s:4:"data";O:8:"stdClass":0:{}}}s:7:"_errors";a:0:{}}s:4:"user";O:5:"JUser":19:{s:2:"id";i:0;s:4:"name";N;s:8:"username";N;s:5:"email";N;s:8:"password";N;s:14:"password_clear";s:0:"";s:8:"usertype";N;s:5:"block";N;s:9:"sendEmail";i:0;s:3:"gid";i:0;s:12:"registerDate";N;s:13:"lastvisitDate";N;s:10:"activation";N;s:6:"params";N;s:3:"aid";i:0;s:5:"guest";i:1;s:7:"_params";O:10:"JParameter":7:{s:4:"_raw";s:0:"";s:4:"_xml";N;s:9:"_elements";a:0:{}s:12:"_elementPath";a:1:{i:0;s:66:"/home/icode/public_html/em/libraries/joomla/html/parameter/element";}s:17:"_defaultNameSpace";s:8:"_default";s:9:"_registry";a:1:{s:8:"_default";a:1:{s:4:"data";O:8:"stdClass":0:{}}}s:7:"_errors";a:0:{}}s:9:"_errorMsg";N;s:7:"_errors";a:0:{}}s:13:"session.token";s:32:"8fd5270aed9ce01d2ac2daca8865973d";}');

-- --------------------------------------------------------

--
-- Table structure for table `jos_stats_agents`
--

CREATE TABLE IF NOT EXISTS `jos_stats_agents` (
  `agent` varchar(255) NOT NULL default '',
  `type` tinyint(1) unsigned NOT NULL default '0',
  `hits` int(11) unsigned NOT NULL default '1'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `jos_stats_agents`
--


-- --------------------------------------------------------

--
-- Table structure for table `jos_templates_menu`
--

CREATE TABLE IF NOT EXISTS `jos_templates_menu` (
  `template` text NOT NULL,
  `menuid` int(11) NOT NULL default '0',
  `client_id` tinyint(4) NOT NULL default '0',
  PRIMARY KEY  (`template`(255),`menuid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `jos_templates_menu`
--

INSERT INTO `jos_templates_menu` (`template`, `menuid`, `client_id`) VALUES
('yoo_seasons', 0, 0),
('khepri', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `jos_template_positions`
--

CREATE TABLE IF NOT EXISTS `jos_template_positions` (
  `id` int(11) NOT NULL auto_increment,
  `position` varchar(150) NOT NULL default '',
  `description` text NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=35 ;

--
-- Dumping data for table `jos_template_positions`
--

INSERT INTO `jos_template_positions` (`id`, `position`, `description`) VALUES
(1, 'left', ''),
(2, 'right', ''),
(3, 'top', ''),
(4, 'bottom', ''),
(5, 'inset', ''),
(6, 'banner', ''),
(7, 'header', ''),
(8, 'footer', ''),
(9, 'newsflash', ''),
(10, 'legals', ''),
(11, 'pathway', ''),
(12, 'breadcrumb', ''),
(13, 'toolbar', ''),
(14, 'menu', ''),
(15, 'cpanel', ''),
(16, 'user1', ''),
(17, 'user2', ''),
(18, 'user3', ''),
(19, 'user4', ''),
(20, 'user5', ''),
(21, 'user6', ''),
(22, 'user7', ''),
(23, 'user8', ''),
(24, 'user9', ''),
(25, 'advert1', ''),
(26, 'advert2', ''),
(27, 'advert3', ''),
(28, 'icon', ''),
(29, 'debug', ''),
(30, 'submenu', ''),
(31, 'status', ''),
(32, 'title', ''),
(33, 'syndicate', ''),
(34, 'cp_shell', '');

-- --------------------------------------------------------

--
-- Table structure for table `jos_users`
--

CREATE TABLE IF NOT EXISTS `jos_users` (
  `id` int(11) NOT NULL auto_increment,
  `name` text NOT NULL,
  `username` varchar(150) NOT NULL default '',
  `email` varchar(100) NOT NULL default '',
  `password` varchar(100) NOT NULL default '',
  `usertype` varchar(75) NOT NULL default '',
  `block` tinyint(4) NOT NULL default '0',
  `sendEmail` tinyint(4) default '0',
  `gid` tinyint(3) unsigned NOT NULL default '1',
  `registerDate` datetime NOT NULL default '0000-00-00 00:00:00',
  `lastvisitDate` datetime NOT NULL default '0000-00-00 00:00:00',
  `activation` varchar(100) NOT NULL default '',
  `params` text NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `usertype` (`usertype`),
  KEY `idx_name` (`name`(255))
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=63 ;

--
-- Dumping data for table `jos_users`
--

INSERT INTO `jos_users` (`id`, `name`, `username`, `email`, `password`, `usertype`, `block`, `sendEmail`, `gid`, `registerDate`, `lastvisitDate`, `activation`, `params`) VALUES
(62, 'Administrator', 'admin', 'email@0.0.0.0', 'fe01ce2a7fbac8fafaed7c982a04e229', 'Super Administrator', 0, 1, 25, '2007-06-03 14:52:24', '2008-11-24 12:52:06', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `jos_weblinks`
--

CREATE TABLE IF NOT EXISTS `jos_weblinks` (
  `id` int(11) unsigned NOT NULL auto_increment,
  `catid` int(11) NOT NULL default '0',
  `sid` int(11) NOT NULL default '0',
  `title` text NOT NULL,
  `alias` varchar(255) NOT NULL default '',
  `url` varchar(250) NOT NULL default '',
  `description` text NOT NULL,
  `date` datetime NOT NULL default '0000-00-00 00:00:00',
  `hits` int(11) NOT NULL default '0',
  `published` tinyint(1) NOT NULL default '0',
  `checked_out` int(11) NOT NULL default '0',
  `checked_out_time` datetime NOT NULL default '0000-00-00 00:00:00',
  `ordering` int(11) NOT NULL default '0',
  `archived` tinyint(1) NOT NULL default '0',
  `approved` tinyint(1) NOT NULL default '1',
  `params` text NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `catid` (`catid`,`published`,`archived`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `jos_weblinks`
--

INSERT INTO `jos_weblinks` (`id`, `catid`, `sid`, `title`, `alias`, `url`, `description`, `date`, `hits`, `published`, `checked_out`, `checked_out_time`, `ordering`, `archived`, `approved`, `params`) VALUES
(1, 2, 0, 'Joomla!', 'joomla', 'http://www.joomla.org', 'Home of Joomla!', '2005-02-14 15:19:02', 2, 1, 0, '0000-00-00 00:00:00', 1, 0, 1, 'target=0'),
(2, 2, 0, 'php.net', 'php', 'http://www.php.net', 'The language that Joomla! is developed in', '2004-07-07 11:33:24', 5, 1, 0, '0000-00-00 00:00:00', 3, 0, 1, ''),
(3, 2, 0, 'MySQL', 'mysql', 'http://www.mysql.com', 'The database that Joomla! uses', '2004-07-07 10:18:31', 0, 1, 0, '0000-00-00 00:00:00', 5, 0, 1, ''),
(4, 2, 0, 'OpenSourceMatters', 'opensourcematters', 'http://www.opensourcematters.org', 'Home of OSM', '2005-02-14 15:19:02', 10, 1, 0, '0000-00-00 00:00:00', 2, 0, 1, 'target=0'),
(5, 2, 0, 'Joomla! - Forums', 'joomla-forums', 'http://forum.joomla.org', 'Joomla! Forums', '2005-02-14 15:19:02', 3, 1, 0, '0000-00-00 00:00:00', 4, 0, 1, 'target=0');
